# nav.py N  -> prints an mrun script prefix that reaches arcade game N's menu (frame ~ returned on stderr)
import sys
def nav(n):
    L = open('b.txt').read().split('\n')[:19]
    out = [l for l in L if l.strip()]
    f = 112
    for i in range(n):
        out += [f"{f} DOWN", f"{f+2} -"]; f += 6
    out += [f"{f} A", f"{f+2} -", f"{f+30} - menu"]
    return out, f + 32
