# ballgrid.py - Qu33ph-Ball's three machines (the GBA's scoring shapes) rasterised for the Game Boy:
# a lookup grid of which shape each spot is in, and a picture of the machine in tiles.
import math
NOCLIP = (-1, -1, 9)
def RECT(x0, x1, y0, y1, p): return dict(k='r', a=(x0, x1, y0, y1), p=p)
def CHAIR(x0, x1, y0, y1, p, tx, ty): return dict(k='r', a=(x0, x1, y0, y1), p=p, chair=1, to=(tx, ty))
def CLIMB(x0, x1, y0, y1, s): return dict(k='r', a=(x0, x1, y0, y1), p=0, chair=1, side=s)
def CIRC(cx, cy, r, p): return dict(k='c', a=(cx, cy, r), p=p)
def ARC(cx, cy, ri, ro, a0, a1, cy0, cx0, cx1, p): return dict(k='a', a=(cx, cy, ri, ro, a0, a1, cy0, cx0, cx1), p=p)
def POLY(pt, clip, p): return dict(k='p', pts=list(zip(pt[::2], pt[1::2])), clip=clip, p=p)
POLY_C1 = [0.312,0.290, 0.317,0.264, 0.340,0.269, 0.367,0.282, 0.383,0.289, 0.356,0.316, 0.352,0.295, 0.317,0.293]
POLY_C2 = [0.701,0.271, 0.705,0.288, 0.677,0.291, 0.658,0.325, 0.630,0.288, 0.669,0.289, 0.688,0.279]
POLY_T = [0.393,0.370, 0.420,0.357, 0.443,0.357, 0.461,0.365, 0.479,0.388, 0.456,0.408, 0.437,0.415,
    0.418,0.413, 0.395,0.401, 0.413,0.421, 0.462,0.439, 0.469,0.397, 0.491,0.387, 0.544,0.394, 0.556,0.412, 0.550,0.443,
    0.599,0.425, 0.620,0.409, 0.568,0.405, 0.553,0.389, 0.551,0.370, 0.606,0.356, 0.620,0.366, 0.624,0.347, 0.595,0.327,
    0.556,0.310, 0.493,0.304, 0.437,0.322, 0.394,0.356, 0.457,0.351, 0.481,0.313, 0.497,0.310, 0.541,0.317, 0.556,0.328,
    0.566,0.340, 0.555,0.359]
MACH = [
  [RECT(0.473, 0.554, 0.243, 0.270, 50), RECT(0.469, 0.550, 0.270, 0.301, 40), RECT(0.458, 0.564, 0.303, 0.344, 30),
   ARC(0.515, 0.127, 0.257, 0.433, 69, 114, -1, -1, 9, 20), ARC(0.510, 0.290, 0.165, 0.239, 0, 176, -1, -1, 9, 10),
   CIRC(0.374, 0.263, 0.036, 100), CIRC(0.651, 0.260, 0.047, 100), POLY(POLY_C1, -1, 10), POLY(POLY_C2, -1, 10)],
  [CHAIR(0.247, 0.338, 0.462, 0.575, 75, 0.2245, 0.399), CHAIR(0.564, 0.658, 0.462, 0.575, 75, 0.6715, 0.399),
   RECT(0.249, 0.318, 0.295, 0.342, 50), RECT(0.318, 0.409, 0.276, 0.332, 100), RECT(0.426, 0.480, 0.282, 0.312, 333),
   RECT(0.502, 0.588, 0.275, 0.336, 100), RECT(0.593, 0.660, 0.294, 0.343, 50),
   RECT(0.276, 0.369, 0.354, 0.415, 30), RECT(0.404, 0.502, 0.353, 0.416, 40), RECT(0.543, 0.631, 0.357, 0.412, 30),
   RECT(0.192, 0.253, 0.367, 0.473, 75), RECT(0.655, 0.720, 0.368, 0.465, 75)],
  [CLIMB(0.180, 0.370, 0.635, 0.765, -1), CLIMB(0.630, 0.820, 0.635, 0.765, 1),
   CIRC(0.514, 0.352, 0.038, 5000), CIRC(0.429, 0.385, 0.039, 2000), CIRC(0.598, 0.386, 0.036, 2000), CIRC(0.511, 0.418, 0.036, 1000),
   RECT(0.305, 0.445, 0.290, 0.380, 0), RECT(0.581, 0.721, 0.290, 0.380, 0),
   ARC(0.513, 0.381, 0.128, 0.152, 5, 350, 0.300, 0.297, 0.689, 500),
   ARC(0.513, 0.381, 0.170, 0.220, 5, 350, 0.300, 0.341, 0.695, 250),
   ARC(0.513, 0.381, 0.220, 0.270, 5, 350, 0.300, 0.339, 0.691, 100),
   POLY(POLY_T, 0.290, 500)]]
ASPECT = 1.78
def inside(s, x, y):
    k = s['k']
    if k == 'c':
        cx, cy, r = s['a']; dx = x - cx; dy = (y - cy) * ASPECT; return dx * dx + dy * dy <= r * r
    if k == 'a':
        cx, cy, ri, ro, a0, a1, cy0, cx0, cx1 = s['a']
        if y < cy0 or x < cx0 or x > cx1: return False
        dx = x - cx; dy = (y - cy) * ASPECT; d2 = dx * dx + dy * dy
        if d2 < ri * ri or d2 > ro * ro: return False
        ang = math.degrees(math.atan2(dy, dx)) % 360
        return (a0 <= ang <= a1) if a0 <= a1 else (ang >= a0 or ang <= a1)
    if k == 'p':
        if y < s['clip']: return False
        inn = False; p = s['pts']; n = len(p); j = n - 1
        for i in range(n):
            xi, yi = p[i]; xj, yj = p[j]
            if (yi > y) != (yj > y) and x < (xj - xi) * (y - yi) / (yj - yi) + xi: inn = not inn
            j = i
        return inn
    x0, x1, y0, y1 = s['a']; return x0 <= x <= x1 and y0 <= y <= y1
X0, X1, Y0, Y1 = 0.15, 0.85, 0.15, 0.83          # the part of the machine shown (80 x 136 pixels)
GW, GH = 40, 68                                   # the lookup grid: 2 pixels a cell
def zone(m, x, y):
    for i, s in enumerate(MACH[m]):
        if inside(s, x, y): return i + 1
    return 0
def grid(m):
    return [zone(m, X0 + (gx + 0.5) * (X1 - X0) / GW, Y0 + (gy + 0.5) * (Y1 - Y0) / GH) for gy in range(GH) for gx in range(GW)]
def label(p, s):
    if s.get('side'): return 'TWR'
    if s.get('chair'): return 'CH'
    if p == 0: return ''
    if p >= 1000: return f'{p // 1000}K'
    return str(p)
