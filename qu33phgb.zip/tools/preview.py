# preview.py - shows generated tiles as the grey Game Boy and the Color would
from PIL import Image
DMG = [(255, 255, 255), (170, 170, 170), (85, 85, 85), (0, 0, 0)]
def decode(t):
    out = []
    for y in range(8):
        lo, hi = t[y * 2], t[y * 2 + 1]
        out.append([((lo >> (7 - x)) & 1) | (((hi >> (7 - x)) & 1) << 1) for x in range(8)])
    return out
def render(tiles, tmap, attrs, pals, w, h, cgb=True):
    im = Image.new('RGB', (w * 8, h * 8))
    for i, t in enumerate(tmap):
        tx, ty = i % w, i // w
        px = decode(tiles[t])
        for y in range(8):
            for x in range(8):
                v = px[y][x]
                im.putpixel((tx * 8 + x, ty * 8 + y), pals[attrs[i]][v] if cgb else DMG[v])
    return im
