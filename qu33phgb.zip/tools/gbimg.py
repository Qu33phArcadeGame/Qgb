# gbimg.py - pictures to Game Boy tiles: 2 bits a pixel, shades sorted light -> dark so the
# original Game Boy shows them in grey, plus Game Boy Color palettes (4 colours each, chosen
# per 8x8 tile by clustering the tiles' colours).
from PIL import Image
import numpy as np
def lum(c): return 0.299 * c[0] + 0.587 * c[1] + 0.114 * c[2]
def dist(a, b): return (a[0]-b[0])**2*2 + (a[1]-b[1])**2*4 + (a[2]-b[2])**2*3
W3 = np.array([2.0, 4.0, 3.0])
def flatten(im, bg):
    im = im.convert('RGBA'); out = Image.new('RGB', im.size, bg); out.paste(im, (0, 0), im); return out
def kmeans(X, k, iters=20, seed=1):
    """weighted-RGB k-means; returns centres (k x 3)"""
    X = np.asarray(X, float)
    if len(X) == 0: return np.zeros((k, 3))
    rng = np.random.default_rng(seed)
    uniq = np.unique(X, axis=0)
    if len(uniq) <= k:
        C = np.vstack([uniq] + [uniq[-1:]] * (k - len(uniq)))
        return C
    # k-means++ start
    C = [uniq[rng.integers(len(uniq))]]
    for _ in range(1, k):
        d = np.min([((X - c) ** 2 * W3).sum(1) for c in C], axis=0)
        C.append(X[rng.choice(len(X), p=d / d.sum())] if d.sum() > 0 else X[0])
    C = np.array(C)
    for _ in range(iters):
        D = np.stack([((X - c) ** 2 * W3).sum(1) for c in C], 1)
        lab = D.argmin(1)
        for j in range(k):
            if (lab == j).any(): C[j] = X[lab == j].mean(0)
    return C
def to_tiles(im, max_pals=4, bg=(255, 255, 255), ncolors=16, fixed=None, paper=None):
    """im (RGBA/RGB, size multiple of 8) -> (tiles[16-byte], tilemap, attrs (palette per tile), pals [4 RGB each])
    paper: a colour that is always index 0 (the screen's paper: white on the grey Game Boy);
           the other three are sorted light -> dark (the grey Game Boy's shades).
    fixed: palettes to use instead of finding them."""
    if paper is not None: bg = paper
    im = flatten(im, bg) if im.mode == 'RGBA' else im.convert('RGB')
    W, H = im.size; assert W % 8 == 0 and H % 8 == 0, im.size
    A = np.asarray(im, float)
    tw, th = W // 8, H // 8
    tiles_px = [A[ty*8:ty*8+8, tx*8:tx*8+8].reshape(64, 3) for ty in range(th) for tx in range(tw)]
    P = np.array(paper, float) if paper is not None else None
    def ink(t):
        if P is None: return t
        return t[((t - P) ** 2 * W3).sum(1) > 300]
    if fixed is None:
        ncol = 3 if P is not None else 4
        feats, has = [], []
        for t in tiles_px:
            i = ink(t)
            has.append(len(i) > 0)
            feats.append(i.mean(0) if len(i) else np.zeros(3))
        feats = np.array(feats)
        idx = [i for i in range(len(tiles_px)) if has[i]]
        k = min(max_pals, max(1, len(idx)))
        # group the tiles by their colours, then give each group its best 3 (or 4) colours;
        # a few rounds of re-assigning each tile to the palette that draws it best
        if idx:
            Cg = kmeans(feats[idx], k)
            lab = {i: int((((Cg - feats[i]) ** 2) * W3).sum(1).argmin()) for i in idx}
        pals = []
        for rnd in range(4):
            pals = []
            for g in range(k):
                pix = np.vstack([ink(tiles_px[i]) for i in idx if lab[i] == g] or [np.zeros((1, 3))])
                C = kmeans(pix, ncol, seed=g + 3)
                pals.append(sorted([tuple(int(round(v)) for v in c) for c in C], key=lambda c: -lum(c)))
            # re-assign
            for i in idx:
                best = None
                for g, p in enumerate(pals):
                    pp = np.array(([paper] if P is not None else []) + p, float)
                    e = np.min(((tiles_px[i][:, None, :] - pp[None]) ** 2 * W3).sum(2), 1).sum()
                    if best is None or e < best[0]: best = (e, g)
                lab[i] = best[1]
        pals = [([tuple(paper)] if P is not None else []) + p for p in pals]
        for p in pals:
            while len(p) < 4: p.append(p[-1])
        assign = [lab.get(i, 0) for i in range(len(tiles_px))]
    else:
        pals = fixed
        assign = []
        for t in tiles_px:
            errs = [np.min(((t[:, None, :] - np.array(p, float)[None]) ** 2 * W3).sum(2), 1).sum() for p in pals]
            assign.append(int(np.argmin(errs)))
    tiles, tmap, seen = [], [], {}
    for n, t in enumerate(tiles_px):
        p = np.array(pals[assign[n]], float)
        ks = ((t[:, None, :] - p[None]) ** 2 * W3).sum(2).argmin(1)
        data = []
        for y in range(8):
            lo = hi = 0
            for x in range(8):
                kk = int(ks[y * 8 + x])
                if kk & 1: lo |= 0x80 >> x
                if kk & 2: hi |= 0x80 >> x
            data += [lo, hi]
        key = bytes(data)
        if key not in seen: seen[key] = len(tiles); tiles.append(key)
        tmap.append(seen[key])
    return tiles, tmap, assign, pals
def sprite_tiles(im, cols):
    """an RGBA sprite -> 2bpp tiles (8x8, row-major), alpha < 128 = transparent; cols: the
    colours for indices 1-3 (light -> dark): each pixel takes the nearest."""
    im = im.convert('RGBA'); W, H = im.size
    out = []
    for ty in range(H // 8):
        for tx in range(W // 8):
            data = []
            for y in range(8):
                lo = hi = 0
                for x in range(8):
                    r, g, b, a = im.getpixel((tx*8+x, ty*8+y))
                    if a < 128: continue
                    k = 1 + min(range(3), key=lambda i: dist((r, g, b), cols[i]))
                    if k & 1: lo |= 0x80 >> x
                    if k & 2: hi |= 0x80 >> x
                data += [lo, hi]
            out.append(bytes(data))
    return out
def rgb555(c): return (int(c[0]) >> 3) | ((int(c[1]) >> 3) << 5) | ((int(c[2]) >> 3) << 10)
def c_bytes(name, data, per=16):
    s = f"const uint8_t {name}[{len(data)}] = {{\n"
    for i in range(0, len(data), per): s += "    " + ",".join(f"0x{b:02X}" for b in data[i:i+per]) + ",\n"
    return s + "};\n"
def c_words(name, data):
    return f"const uint16_t {name}[{len(data)}] = {{ " + ",".join(f"0x{v:04X}" for v in data) + " };\n"
