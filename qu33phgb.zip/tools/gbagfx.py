# gbagfx.py - reads the GBA port's converted pictures (gfx.c) so the Game Boy port can shrink them.
import re, os
SRC = os.path.join(os.path.dirname(__file__), '..', '..', 'gba', 'source', 'gfx.c')
_cache = None
def arrays():
    global _cache
    if _cache is None:
        txt = open(SRC).read()
        _cache = {}
        for m in re.finditer(r'const\s+(uint8_t|uint16_t)\s+(\w+)(\[[^\]]*\])+[^=]*=\s*\{(.*?)\};', txt, re.S):
            body = re.sub(r'/\*.*?\*/', '', m.group(4), flags=re.S)
            if '{' in body:     # 2-D arrays: flatten
                body = body.replace('{', ' ').replace('}', ' ')
            vals = [int(v, 0) for v in re.findall(r'0x[0-9a-fA-F]+|\d+', body)]
            _cache[m.group(2)] = vals
    return _cache
UI = {0: (0,0,0), 1: (31,31,31), 2: (2,2,3), 3: (31,27,4), 4: (31,24,2), 5: (18,18,18), 6: (31,6,6), 7: (8,31,8)}
def rgb15(v): return ((v & 31) * 255 // 31, ((v >> 5) & 31) * 255 // 31, ((v >> 10) & 31) * 255 // 31)
def image(name, w, h, pal=None, palname=None, offset=0):
    """an 8-bit picture as RGBA rows (index 0 = transparent)"""
    from PIL import Image
    a = arrays()
    px = a[name][offset * w * h:(offset + 1) * w * h]
    P = a[palname] if palname else pal
    im = Image.new('RGBA', (w, h))
    for i, v in enumerate(px):
        if v == 0: c = (0, 0, 0, 0)
        elif v >= 64: c = rgb15(P[v - 64]) + (255,)
        else: c = tuple(x * 255 // 31 for x in UI.get(v, (16,16,16))) + (255,)
        im.putpixel((i % w, i // w), c)
    return im
def tiles4(name, w, h, palname, offset=0):
    """a 4-bit sprite picture (GBA tile order) as RGBA"""
    from PIL import Image
    a = arrays(); d = a[name]; P = a[palname]
    im = Image.new('RGBA', (w, h))
    tw = w // 8
    for ty in range(h // 8):
        for tx in range(tw):
            base = (ty * tw + tx) * 32
            for y in range(8):
                for x in range(8):
                    b = d[base + y * 4 + x // 2]; v = (b >> 4) if x & 1 else (b & 15)
                    im.putpixel((tx * 8 + x, ty * 8 + y), (rgb15(P[v]) + (255,)) if v else (0, 0, 0, 0))
    return im
