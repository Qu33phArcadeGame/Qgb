// dozer.c — QU33PH DOZER (the website's dozer.html), bare bones: a coin pusher.
// The bed seen from above as a grid of places, each empty or holding a coin or a marker. The
// pusher at the back slides in and out; each time it comes forward it shoves the row in front of
// it, and a shove passes down a line of touching pieces (or nudges a piece aside into a gap).
// Pieces shoved over the front ledge are won: coins to keep, markers back to drop again.
// 60 seconds; at 30 the chair drops into the middle; an empty-ish bed gets a COIN DROP.
#pragma bank 255
#include "qu.h"
#include "res_dozer.inc"

#define COLS 10
#define ROWS 13                        // bed rows (0 = the back); the pusher sweeps rows 0-3
#define FACE_MAX 4
#define BX 1                           // the bed's first tile column / row on the screen
#define BY 2
enum { E_EMPTY, E_COIN, E_MK0, E_MK1, E_MK2, E_CHAIR };
static u8 cell[ROWS][COLS];
enum { ST_MENU, ST_PLAY, ST_OVER };
static u8 st, sel, face, faceDir, faceT, aimC, aimT, chairOn, nQ, queue[24], cycleN, dropping, dropT, dropCol, refillT, paidOut;
static u16 framesLeft; static s16 coinsWon;
typedef struct { s16 x, y, vy; u8 kind, life; } Fall;
static Fall fall[6];
static struct { char t[12]; u8 life; s16 x, y; } pop;

static void drawCell(u8 r, u8 c) {
    u8 e = cell[r][c];
    if (e == E_COIN) put(BX + c, BY + r, SCENE_T + 1, PAL_S1);
    else if (e >= E_MK0 && e <= E_MK2) put(BX + c, BY + r, SCENE_T + 2 + (e - E_MK0), PAL_S2);
    else put(BX + c, BY + r, SCENE_T, PAL_S1);                       // (the chair is a sprite over bed tiles)
}
static void drawFace(void) {                    // the pusher: rows 0..face-1 of the bed covered, the face below
    for (u8 r = 0; r <= FACE_MAX; r++) {
        if (r < face) fillBkg(BX, BY + r, COLS, 1, UI_SOLID2, PAL_GREY);
        else for (u8 c = 0; c < COLS; c++) drawCell(r, c);
    }
    fillBkg(BX, BY - 1, COLS, 1, UI_SOLID2, PAL_GREY);                // its back, always there
}
static void popSay(const char *t, s16 x, s16 y) { strncpy(pop.t, t, 11); pop.t[11] = 0; pop.x = x; pop.y = y; pop.life = 50; }
static void grant(u8 n) { for (u8 i = 0; i < n && nQ < 24; i++) queue[nQ++] = cycleN++ % 3; }
static void panel(void) {
    fillWin(1, 0, 7, 18, BLANK, PAL_TEXT);
    wtxt(1, 0, "TIME", PAL_GREY); wnum(1, 1, (framesLeft + 59) / 60, 2, framesLeft < 600 ? PAL_RED : PAL_GOLD);
    wtxt(1, 3, "WON", PAL_GREY); wnum(1, 4, coinsWon, 3, PAL_GOLD);
    wtxt(1, 6, "MARKERS", PAL_GREY); wnum(1, 7, nQ, 2, PAL_TEXT);
    wtxt(1, 12, "A DROP", PAL_GREY);
    if (!nQ) { wtxt(1, 14, "B BUY 3", sv.coins >= 10 ? PAL_GREEN : PAL_GREY); wtxt(1, 15, "FOR 10", PAL_GREY); }
    wtxt(1, 17, lbl("", sv.coins), PAL_GOLD);
}
static void fallOff(u8 c, u8 e) {               // over the front ledge
    for (u8 i = 0; i < 6; i++) if (!fall[i].life) { fall[i].x = (BX + c) * 8 + 4; fall[i].y = (BY + ROWS) * 8 - 4; fall[i].vy = 0; fall[i].kind = e; fall[i].life = 20; break; }
    if (e == E_COIN) { coinsWon++; sfx(SFX_COIN); popSay("+1", (BX + c) * 8, (BY + ROWS) * 8 - 12); }
    else {if (nQ < 24) queue[nQ++] = e - E_MK0; sfx(SFX_GOOD); popSay("MARKER BACK", 4, 64); }
    panel();
}
// shove the piece at (r, c) one row forward, passing the shove down the line of pieces in front
static void shove(u8 r, u8 c) {
    u8 e = r;
    while (e < ROWS && cell[e][c] != E_EMPTY && cell[e][c] != E_CHAIR) e++;
    u8 blocked = e < ROWS && cell[e][c] == E_CHAIR;
    // sometimes the shoved piece slips aside into a gap instead (always, when the line is jammed)
    if (r + 1 < ROWS && (blocked || rnd8() < 60)) {
        s8 d = rnd8() & 1 ? 1 : -1;
        for (u8 k = 0; k < 2; k++, d = -d) {
            s8 nc = (s8)c + d; if (nc < 0 || nc >= COLS) continue;
            if (cell[r + 1][nc] == E_EMPTY) { cell[r + 1][nc] = cell[r][c]; cell[r][c] = E_EMPTY; drawCell(r + 1, nc); drawCell(r, c); return; }
        }
    }
    if (blocked) return;                                             // jammed against the chair
    if (e >= ROWS) { fallOff(c, cell[ROWS - 1][c]); e = ROWS - 1; }    // the line reaches the ledge: the front one goes over
    for (u8 k = e; k > r; k--) { cell[k][c] = cell[k - 1][c]; drawCell(k, c); }
    cell[r][c] = E_EMPTY; drawCell(r, c);
}
static void place(u8 c, u8 e) {                // a dropped piece lands in front of the pusher
    u8 r = face < FACE_MAX ? face : FACE_MAX - 1;                    // (in front of the pusher, where its strokes reach)
    if (cell[r][c] != E_EMPTY) shove(r, c);
    if (cell[r][c] == E_EMPTY) { cell[r][c] = e; drawCell(r, c); }
}
static u8 coinsOnBed(void) { u8 n = 0; for (u8 r = 0; r < ROWS; r++) for (u8 c = 0; c < COLS; c++) n += cell[r][c] == E_COIN; return n; }
static void refill(void) {
    for (u8 i = 0; i < 26; i++) { u8 r = FACE_MAX + rnd8() % 6, c = rnd8() % COLS; if (cell[r][c] == E_EMPTY) { cell[r][c] = E_COIN; drawCell(r, c); } }
    refillT = 240; popSay("COIN DROP!", 12, 64); sfx(SFX_COIN);
}
static void dropChair(void) {
    chairOn = 1;
    for (u8 r = 6; r < 8; r++) for (u8 c = 4; c < 6; c++) { cell[r][c] = E_CHAIR; drawCell(r, c); }
    popSay("CHAIR DROPPED!", 0, 40); sfx(SFX_BAD);
}
static void gameOver(void) {
    if (!paidOut && coinsWon > 0) { addCoins(coinsWon); paidOut = 1; }
    if (coinsWon > sv.arcadeBest[ARC_DOZER]) sv.arcadeBest[ARC_DOZER] = coinsWon;
    sv.arcadePlays[ARC_DOZER]++; saveWrite();
    char l1[20], l2[20]; strcpy(l1, lbl("", coinsWon)); strcat(l1, " COINS WON");
    strcpy(l2, lbl("BEST ", sv.arcadeBest[ARC_DOZER]));
    st = ST_OVER; sfx(SFX_GOOD);
    overDraw("TIME UP", l1, l2, lbl("YOU HAVE ", sv.coins));
}
static void start(void) {
    screenFresh();
    loadBkgTiles(SCENE_T, 5, dozer_bg);
    static const u16 S1[4] = { RGB8(205, 175, 125), RGB8(255, 205, 40), RGB8(170, 140, 95), RGB8(70, 45, 20) };
    static const u16 S2[4] = { RGB8(205, 175, 125), RGB8(225, 50, 50), RGB8(40, 160, 60), RGB8(50, 90, 220) };
    setBkgPal(PAL_S1, S1); setBkgPal(PAL_S2, S2);
    memset(cell, 0, sizeof cell);
    for (u8 r = FACE_MAX; r < ROWS; r++) for (u8 c = 0; c < COLS; c++) if (rnd8() < 195) cell[r][c] = E_COIN;
    for (u8 i = 0; i < 5; i++) cell[FACE_MAX + 1 + rnd8() % 7][rnd8() % COLS] = E_MK0 + rnd8() % 3;
    fillBkg(0, 0, 12, 18, UI_SOLID3, PAL_GREY);
    for (u8 r = 0; r < ROWS; r++) for (u8 c = 0; c < COLS; c++) drawCell(r, c);
    fillBkg(BX, BY + ROWS, COLS, 1, UI_SOLID1, PAL_GREY);              // the ledge
    face = 0; faceDir = 1; faceT = 0; drawFace();
    nQ = 0; cycleN = 0; grant(5); aimC = 5; aimT = 0; chairOn = 0; dropping = 0; refillT = 120; paidOut = 0;
    framesLeft = 60 * 60; coinsWon = 0; pop.life = 0; for (u8 i = 0; i < 6; i++) fall[i].life = 0;
    fillWin(0, 0, 8, 18, BLANK, PAL_TEXT); for (u8 y = 0; y < 18; y++) wput(0, y, UI_L, PAL_GREY);
    panel(); winAt(7 + 96, 0);
    st = ST_PLAY;
    lcdOn();
}
static void step(void) {
    if (framesLeft) framesLeft--;
    if ((framesLeft % 60) == 0) panel();
    if (!framesLeft) { gameOver(); return; }
    if (!chairOn && framesLeft <= 30 * 60) dropChair();
    if (refillT) refillT--; else if (coinsOnBed() < 8) refill();
    if (++faceT >= 12) {                        // the pusher: in, in, out, out
        faceT = 0;
        if (faceDir) {
            for (u8 c = 0; c < COLS; c++) if (cell[face][c] != E_EMPTY) shove(face, c);
            face++;
            if (face >= FACE_MAX) {                     // the end of the stroke nudges the line it meets too
                faceDir = 0;
                for (u8 c = 0; c < COLS; c++) {
                    u8 e = cell[face][c];
                    if (e != E_EMPTY && e != E_CHAIR) shove(face, c);
                    else if (e == E_EMPTY && rnd8() < 8 && cell[face + 1][c] != E_EMPTY && cell[face + 1][c] != E_CHAIR) shove(face + 1, c);   // (the pile leans on it)
                }
            }
        } else { face--; if (!face) faceDir = 1; }
        drawFace();
    }
    if (dropping && ++dropT >= 10) { dropping = 0; place(dropCol, E_MK0 + queue[0]); memmove(queue, queue + 1, --nQ); sfx(SFX_PLOP); panel(); }
    for (u8 i = 0; i < 6; i++) if (fall[i].life) { fall[i].life--; fall[i].vy++; fall[i].y += fall[i].vy >> 1; }
    if (pop.life) pop.life--;
}
static void drawSprites(void) {
    s16 ax = (BX + aimC) * 8 + 4;
    if (dropping) { u8 k = queue[0]; miniMarker(ax, 6 + dropT * ((BY + face) * 8 - 6) / 10, k == 0 ? 1 : k == 1 ? 0 : 3, 0); }
    else if (nQ) { u8 k = queue[0]; miniMarker(ax, 4, k == 0 ? 1 : k == 1 ? 0 : 3, 0); }
    spr(ax - 4, 10, UI_CURSOR, isCGB ? OP_GOLD : 0);
    if (chairOn) spr16((BX + 5) * 8, (BY + 7) * 8, ST_CHAIR, isCGB ? OP_RED : 0);
    for (u8 i = 0; i < 6; i++) if (fall[i].life) {
        if (fall[i].kind == E_COIN) spr(fall[i].x - 4, fall[i].y - 4, UI_COIN, isCGB ? OP_GOLD : 0);
        else miniMarker(fall[i].x, fall[i].y, fall[i].kind == E_MK0 ? 1 : fall[i].kind == E_MK1 ? 0 : 3, fall[i].life * 9);
    }
    if (pop.life) sprText(pop.x, pop.y - (50 - pop.life) / 4, pop.t, isCGB ? OP_WHITE : 0);
}
static const char * const MENU_ITEMS[2] = { "PLAY", "BACK" };
void dozerEnter(void) BANKED { }
void dozerUpdate(void) BANKED {
    if (entering) {
        st = ST_MENU; sel = 0;
        screenFresh(); txtC(0, "QU33PH DOZER", PAL_GOLD);
        static const char * const L[8] = { "A COIN PUSHER. DROP", "MARKERS IN FRONT OF", "THE PUSHER TO SHOVE", "COINS OVER THE EDGE.", "MARKERS THAT FALL", "COME BACK. 60 SECS;", "AT 30 THE CHAIR", "DROPS IN!" };
        for (u8 i = 0; i < 8; i++) txt(0, 2 + i, L[i], i >= 6 ? PAL_RED : PAL_TEXT);
        txtC(16, lbl("BEST ", sv.arcadeBest[ARC_DOZER]), PAL_GOLD);
        lcdOn();
    }
    music(MUS_DOZER);
    if (st == ST_MENU) {
        s8 h = menuList(6, 12, 2, MENU_ITEMS, &sel, 2);
        if (h == 0) start(); else if (h == 1 || h == -2) goScreen(S_ARCADE);
        return;
    }
    if (st == ST_OVER) { s8 h = overInput(); if (h == 0) start(); else if (h == 1) goScreen(S_ARCADE); return; }
    u8 p = pauseCheck(); if (p == 1) return;
    if (p == 2) winAt(7 + 96, 0);
    if (kDown & (J_LEFT | J_RIGHT)) aimT = 0;
    if ((kHeld & J_LEFT) && aimC && aimT == 0) aimC--;
    if ((kHeld & J_RIGHT) && aimC < COLS - 1 && aimT == 0) aimC++;
    if (kHeld & (J_LEFT | J_RIGHT)) { if (++aimT >= 7) aimT = 0; }
    if ((kDown & J_A) && nQ && !dropping) { dropping = 1; dropT = 0; dropCol = aimC; sfx(SFX_THROW); }
    if ((kDown & J_B) && !nQ && !dropping && sv.coins >= 10) { spendCoins(10); grant(3); popSay("+3 MARKERS", 12, 64); sfx(SFX_COIN); panel(); }
    step();
    if (st == ST_OVER) return;
    drawSprites();
}
