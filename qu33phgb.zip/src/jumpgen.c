// jumpgen.c — QU33PH JUMP: building the course (the website's sections and COMBO's zones), at 3/8
#pragma bank 255
#include "jump.h"
// ── building the course (pixels in, tiles stored) ────────────────────────
static Plat *addPlat(s16 x, s16 y, s16 w) {
    if (nPl >= NPL) return 0;
    Plat *q = &pl[nPl++]; memset(q, 0, sizeof *q);
    q->tx = tl(x + 4); q->ty = tl(y + 4); w = (w + 4) >> 3; q->tw = w < 2 ? 2 : w > 24 ? 24 : (u8)w;
    q->col = (u8)(absS(q->tx / 5 + q->ty / 7)) % 3;
    return q;
}
static void addObs(s16 x, s16 groundY) { if (nOb >= NOB) return; Obs *o = &ob[nOb++]; memset(o, 0, sizeof *o); o->x = x; o->y = (tl(groundY + 4)) << 3; o->col = rnd8() % 3; }
static void patrol(s16 lo, s16 hi) { if (!nOb) return; Obs *o = &ob[nOb - 1]; o->patrol = 1; o->minX = lo; o->maxX = hi; o->vx = rnd8() & 1 ? 1 : -1; }
static void addCoin(s16 x, s16 y) { if (nCo >= NCO) return; co[nCo].tx = tl(x); co[nCo].ty = tl(y); nCo++; }
static void addPipe(s16 x, s16 gapY, s16 gapH, u8 col) {
    if (nPi >= NPI) return; Pipe *q = &pi[nPi++];
    q->tx = tl(x); q->tw = 3; q->gapT = tl(gapY - gapH / 2); q->gapB = tl(gapY + gapH / 2); q->passed = 0; q->col = col;
    addCoin(x + 12, gapY);
}

static void goRight(s16 x, s16 y, s16 len, s16 clear) { genMode = 1; genX = x; genY = y; lastPlatX = x; segLeft = (u8)(len >> 3); noObsUntil = clear; }
static void goUp(s16 y) { genMode = 0; genY = y - rr(17, 24); segLeft = 6 + rnd8() % 4; upStart = segLeft; }
// the website's sections, at 3/8
static void gauntlet(s16 x, s16 y) {
    u8 n = 4 + rnd8() % 3;
    for (u8 k = 0; k < n; k++) {
        s16 w = rr(19, 29); addPlat(x, y, w);
        addObs(x + w * 2 / 5 + rr(0, 8), y); if (chance(50)) patrol(x + 4, x + w - 4);
        if (chance(50)) addCoin(x + w / 2, y - rr(19, 31));
        x += w + rr(9, 16); y += rr(-6, 6);
    }
    addPlat(x, y, 38); goRight(x + 38, y, rr(32, 64), x + 30);
}
static void climbStep(void) {
    s16 cx = lastPlatX + rr(-16, 16), w = rr(15, 24);
    Plat *q = addPlat(cx - w / 2, genY, w); (void)q;
    lastPlatX = cx;
    u8 atEnds = segLeft >= upStart - 1 || segLeft <= 2;
    if (progress() > 26 && w > 19 && atEnds && chance(40)) addObs(cx, genY);
    if (chance(50)) addCoin(cx, genY - 10);
    genY -= rr(18, 26);
}
static void genStep(void) {
    if (genMode == 2) {                                         // stairs
        addPlat(genX, genY, 17);
        if (rnd16() % 100 < 35) addCoin(genX + 6, genY - 10);
        genX += 16; genY += stairDir * 11;
        if (--stairLeft == 0) { addPlat(genX - 5, genY, 48); goRight(genX + 40, genY, rr(32, 64), genX + 88); }
    } else if (genMode == 0) {                                  // climbing
        climbStep();
        if (--segLeft == 0) {
            if (jMode == M_JUMP) { genY += 8; addPlat(lastPlatX - 16, genY, 33); goUp(genY); }
            else { genY += 10; addPlat(lastPlatX - 12, genY, 40); goRight(lastPlatX + 28, genY, rr(48, 96), 0); }
        }
    } else {                                                    // running right
        s16 w = rr(48, 96);
        addPlat(genX, genY, w);
        s16 pr = progress(); u8 diff = pr > 75 ? 85 : 40 + (u8)(pr * 3 / 5);
        if (pr > 10 && genX > noObsUntil && chance(diff)) {
            addObs(genX + w * 3 / 10 + rr(0, w * 2 / 5), genY);
            if (pr > 20 && chance(40)) patrol(genX + 4, genX + w - 4);
        }
        if (chance(55)) addCoin(genX + w / 2, genY - rr(20, 34));
        genX += w; segLeft = segLeft > (u8)(w >> 3) ? segLeft - (u8)(w >> 3) : 0;
        if (segLeft > 6 && chance(40)) genX += rr(10, 21);
        if (!segLeft) {
            cycles++;
            if (jMode == M_RUN) {
                if (progress() > 18 && chance(30)) gauntlet(genX + rr(8, 14), genY);
                else { genY += rr(-16, 16); goRight(genX + rr(8, 16), genY, rr(48, 96), 0); }
            } else {                                            // (JUMP never runs right for long)
                u8 roll = rnd16() % 100;
                if (roll < 40) { genMode = 2; stairDir = chance(60) ? -1 : 1; stairLeft = 5 + rnd8() % 4; }
                else { genMode = 0; lastPlatX = genX; genY -= rr(18, 24); segLeft = 6 + rnd8() % 4; upStart = segLeft; }
            }
        }
    }
}
// ── COMBO: zones, each in its own stretch of the world ───────────────────
enum { Z_RUN, Z_GAUNT, Z_STAIRS, Z_CLIMB, Z_BOUNCE, Z_FLAP, Z_MEGA };
static void pad(s16 x, s16 y, s16 w) { addPlat(x, y, w); }
static s16 stepGap(void) { return rr(7, 14); }
static void zRun(void) {
    s16 end = zX + rr(134, 211), x = zX;
    while (x < end && nPl < NPL - 2) {
        s16 w = rr(43, 82); pad(x, zY, w);
        if (zCount > 1 && chance(55)) { addObs(x + w * 2 / 5 + rr(0, w / 4), zY); if (progress() > 20 && chance(40)) patrol(x + 4, x + w - 4); }
        if (chance(55)) addCoin(x + w / 2, zY - rr(19, 31));
        x += w + (chance(50) ? stepGap() : 0);
    }
    zX = x;
}
static void zGauntlet(void) {
    u8 n = 4 + rnd8() % 3; s16 x = zX, y = zY;
    for (u8 k = 0; k < n; k++) {
        s16 w = rr(21, 31); pad(x, y, w); addObs(x + w * 2 / 5 + rr(0, w / 4), y); if (chance(50)) patrol(x + 4, x + w - 4);
        if (chance(50)) addCoin(x + w / 2, y - 23);
        x += w + stepGap(); y += rr(-6, 6);
    }
    pad(x, y, 38); zX = x + 38; zY = y;
}
static void zStairs(void) {
    u8 n = 5 + rnd8() % 4; s8 dir = chance(60) ? -1 : 1; s16 x = zX, y = zY;
    for (u8 k = 0; k < n; k++) { pad(x, y, 18); if (k > 1 && k < n - 1 && k % 3 == 0) addObs(x + 6, y); if (chance(35)) addCoin(x + 6, y - 10); x += 16; y += dir * 11; }
    pad(x, y, 43); zX = x + 43; zY = y;
}
static void zClimb(void) {
    s16 colL = zX + 5, colW = 77, y = zY, cx = colL + 15;
    pad(zX, zY, 29);
    u8 n = 6 + rnd8() % 4;
    for (u8 k = 0; k < n; k++) {
        y -= rr(18, 24); s16 w = rr(16, 23);
        cx += (chance(50) ? -1 : 1) * rr(12, 23); if (cx < colL + 6) cx = colL + 6; if (cx > colL + colW - w - 6) cx = colL + colW - w - 6;
        pad(cx, y, w); if (chance(50)) addCoin(cx + w / 2, y - 10);
    }
    y -= 17; pad(colL + colW - 31, y, 31); zX = colL + colW; zY = y;
}
static void zBounce(void) {
    pad(zX, zY, 38);
    u8 n = 5 + rnd8() % 3; s16 sx = zX + 58, sy = zY - 11;
    for (u8 i = 0; i < n; i++) { Plat *q = addPlat(sx - 11, sy, 23); if (q) { q->chair = 1; q->chain = 1; } if (chance(60)) addCoin(sx, sy - 15); sx += 35; sy -= 6; }
    pad(zX + 38, zY + 43, sx - zX);                                     // a floor under the chain to catch misses
    s16 exitY = sy + 15; pad(sx, exitY, 48); zX = sx + 48; zY = exitY;
}
static void zFlap(void) {
    pad(zX, zY, 38);
    s16 chx = zX + 38; Plat *q = addPlat(chx, zY + 2, 25); if (q) { q->chair = 1; q->flappy = 1; }
    s16 bandY = zY - 49; flapFloor = bandY + 89; flapCeil = bandY - 95;
    u8 n = 3 + rnd8() % 3; s16 x = chx + 77, cy = bandY, lastX = x;
    for (u8 i = 0; i < n; i++) {
        cy += rr(-29, 29); if (cy < bandY - 40) cy = bandY - 40; if (cy > bandY + 40) cy = bandY + 40;
        addPipe(x, cy, 68, i % 3); lastX = x; x += 46;
    }
    flappyEndX = lastX + 25 + 12;
    s16 landX = lastX + 41, landY = cy + 29;
    pad(landX - 34, landY, 86); zX = landX + 53; zY = landY;
}
static void zMega(void) {
    s16 chx = zX + 29, gy = zY;
    pad(zX, zY, 58);
    Plat *q = addPlat(chx - 11, gy - 8, 23); if (q) q->chair = 1;
    s16 mx = chx + 122 + rr(0, 10), my = gy - 89 - rr(0, 3);
    megaX = mx; megaY = my; megaOn = 1; megaHit = 0;
    static const s16 ST[7][3] = { { -27, 18, 56 }, { 0, 0, 0 }, { 0, 0, 0 }, { 19, 36, 25 }, { 0, 0, 0 }, { 36, -17, 19 }, { 67, -42, 19 } };
    for (u8 k = 0; k < 7; k++) { if (!ST[k][2]) continue; Plat *s = addPlat(mx + ST[k][0], my + ST[k][1], ST[k][2]); if (s) s->mz = 1; }
    Plat *s = addPlat(chx + 34, gy - 44, 21); if (s) s->mz = 1;
    s = addPlat(chx + 77, gy - 70, 21); if (s) s->mz = 1;
    s = addPlat(chx + 56, gy - 25, 23); if (s) s->mz = 1;
    pad(chx + 11, gy, (mx + 38) - (chx + 11));
    zX = mx + 38; zY = gy;
}
static void comboZone(void) {
    u8 z;
    if (zCount == 0) z = Z_RUN;
    else if (zCount > 2 && zSinceFlap >= 3) z = Z_FLAP;
    else if (zCount > 3 && zSinceMega >= 5 && !megaOn) z = Z_MEGA;
    else { static const u8 POOL[7] = { Z_RUN, Z_GAUNT, Z_STAIRS, Z_CLIMB, Z_CLIMB, Z_BOUNCE, Z_RUN }; do z = POOL[rnd8() % 7]; while (z == zLast); }
    if (zCount) zX += stepGap() * 3 / 5;
    switch (z) { case Z_RUN: zRun(); break; case Z_GAUNT: zGauntlet(); break; case Z_STAIRS: zStairs(); break; case Z_CLIMB: zClimb(); break;
                 case Z_BOUNCE: zBounce(); break; case Z_FLAP: zFlap(); break; default: zMega(); break; }
    zSinceFlap = z == Z_FLAP ? 0 : zSinceFlap + 1; zSinceMega = z == Z_MEGA ? 0 : zSinceMega + 1;
    zLast = z; zCount++; cycles++;
}
static void cull(void) {                       // forget what's far behind or below (drawn tiles stay until scrolled off)
    s16 farX = camX - 120, farY = camY + (flight || flappy || flappyFreeze ? 400 : 260);
    u8 k = 0; for (u8 i = 0; i < nPl; i++) if (platY(&pl[i]) < farY && platX(&pl[i]) + platW(&pl[i]) > farX) pl[k++] = pl[i]; nPl = k;
    k = 0; for (u8 i = 0; i < nOb; i++) if (ob[i].y < farY && ob[i].x > farX) ob[k++] = ob[i]; nOb = k;
    k = 0; for (u8 i = 0; i < nCo; i++) if ((co[i].ty << 3) < farY && (co[i].tx << 3) > farX) co[k++] = co[i]; nCo = k;
    k = 0; for (u8 i = 0; i < nPi; i++) if (((pi[i].tx + pi[i].tw) << 3) > farX) pi[k++] = pi[i]; nPi = k;
}
static void flapSpawnAhead(void) {
    while (flapLastX < camX + 240 && nPi < NPI) {
        flapBandY += rr(-30, 30);
        if (flapBandY < py() - 79) flapBandY = py() - 79; if (flapBandY > py() + 79) flapBandY = py() + 79;
        flapLastX += 48; addPipe(flapLastX, flapBandY, 69, flapPipeN++ % 3);
    }
}
static void genPath(void) {
    if (flapEndless) { flapSpawnAhead(); if ((frame & 7) == 0) cull(); return; }
    if ((frame & 7) == 0 || nPl >= NPL - 12) cull();
    if (jMode == M_COMBO) {
        if (flappy || flappyFreeze) return;
        if (zX < camX + 260 && nPl < NPL - 26) comboZone();
        return;
    }
    for (u8 g = 0; g < 4; g++) {                                 // a few pieces a frame
        if (genMode == 0) { if (genY <= camY - 200) break; } else if (genX >= camX + 260) break;
        if (nPl >= NPL - 6) break;
        genStep();
    }
}

Plat *jAddPlat(s16 x, s16 y, s16 w) BANKED { return addPlat(x, y, w); }
void jAddCoin(s16 x, s16 y) BANKED { addCoin(x, y); }
void jGoRight(s16 x, s16 y, s16 len, s16 clear) BANKED { goRight(x, y, len, clear); }
void jGenPath(void) BANKED { genPath(); }
