// jump.c — QU33PH JUMP (the platformer inside the website's main page), bare bones.
// Four endless modes, each with its own best:
//   COMBO  the mix: runs, gauntlets, stairs, climbs, bounce chains, flappy corridors, the MEGA
//   JUMP   climb forever      RUN  the endless runner      FLAP  thread the pipes forever
// The website's moves (run, jump, the cat's high jump, the chicken's float and air jump, chair
// bounces and launches, flapping) in Game Boy pixels (3/8 of the DS's). The world is laid on the
// 8-pixel grid: platforms, pipes and coins are background tiles drawn as the view scrolls in
// any direction; the runner, the standing markers, chairs and the MEGA pad are sprites.
#pragma bank 255
#include "jump.h"
#include "res_jump.inc"

Plat pl[NPL]; u8 nPl; Obs ob[NOB]; u8 nOb; Coin co[NCO]; u8 nCo; Pipe pi[NPI]; u8 nPi;
u8 jMode, st, sel, moveDir, jumpQ, flight, bouncing, flappy, flappyFreeze, flapEndless, airUsed, speedAcc, overFirst, bounceCombo, msgT, megaOn, megaHit, cls;
s16 score, coinsGot, megaX, megaY, startX, startY, bestX, bestUp, lastGroundY, flapCeil, flapFloor, flappyEndX, flapLastX, flapBandY;
s16 camX, camY, drawnC, drawnR; u16 frame;
u8 genMode, segLeft, upStart, stairLeft, cycles, zLast, zCount, zSinceFlap, zSinceMega, flapPipeN;
s8 stairDir; s16 genX, genY, lastPlatX, noObsUntil, zX, zY;
Player p;
// ── the picture: the 32x32 background map wraps; rows and columns are drawn as they come into view ──
#define T_SLAB SCENE_T
#define T_PIPE (SCENE_T + 9)
#define T_COIN (SCENE_T + 12)
static u8 lineT[21], lineP[21];
static void slabInto(const Plat *q, s16 wx0, u8 n) {           // a platform's tiles into a row buffer starting at column wx0
    for (u8 k = 0; k < q->tw; k++) { s16 c = q->tx + k - wx0; if (c < 0 || c >= n) continue;
        lineT[c] = T_SLAB + q->col * 3 + (k == 0 ? 0 : k == q->tw - 1 ? 2 : 1); lineP[c] = PAL_S1; }
}
static void drawRowAt(s16 wy) {
    s16 wx0 = drawnC; u8 r = (u8)wy & 31;
    memset(lineT, BLANK, 21); memset(lineP, PAL_S1, 21);
    for (u8 i = 0; i < nPi; i++) { Pipe *q = &pi[i];
        for (u8 k = 0; k < q->tw; k++) { s16 c = q->tx + k - wx0; if (c < 0 || c >= 21) continue;
            if (wy == q->gapT - 1 || wy == q->gapB) lineT[c] = T_SLAB + q->col * 3 + (k == 0 ? 0 : k == q->tw - 1 ? 2 : 1);
            else if (wy < q->gapT || wy > q->gapB) lineT[c] = T_PIPE + q->col; } }
    for (u8 i = 0; i < nPl; i++) if (pl[i].ty == wy && !pl[i].chair) slabInto(&pl[i], wx0, 21);
    for (u8 i = 0; i < nCo; i++) if (co[i].ty == wy) { s16 c = co[i].tx - wx0; if (c >= 0 && c < 21) { lineT[c] = T_COIN; lineP[c] = PAL_S2; } }
    for (u8 c = 0; c < 21; c++) put((u8)(wx0 + c) & 31, r, lineT[c], lineP[c]);
}
static void drawColumn(s16 wx) {
    s16 wy0 = drawnR; u8 bc = (u8)wx & 31;
    memset(lineT, BLANK, 19); memset(lineP, PAL_S1, 19);
    for (u8 i = 0; i < nPi; i++) { Pipe *q = &pi[i]; if (wx < q->tx || wx >= q->tx + q->tw) continue;
        u8 k = (u8)(wx - q->tx);
        for (u8 j = 0; j < 19; j++) { s16 wy = wy0 + j;
            if (wy == q->gapT - 1 || wy == q->gapB) lineT[j] = T_SLAB + q->col * 3 + (k == 0 ? 0 : k == q->tw - 1 ? 2 : 1);
            else if (wy < q->gapT || wy > q->gapB) lineT[j] = T_PIPE + q->col; } }
    for (u8 i = 0; i < nPl; i++) { Plat *q = &pl[i]; if (q->chair || wx < q->tx || wx >= q->tx + q->tw) continue;
        s16 j = q->ty - wy0; if (j < 0 || j >= 19) continue;
        u8 k = (u8)(wx - q->tx); lineT[j] = T_SLAB + q->col * 3 + (k == 0 ? 0 : k == q->tw - 1 ? 2 : 1); lineP[j] = PAL_S1; }
    for (u8 i = 0; i < nCo; i++) if (co[i].tx == wx) { s16 j = co[i].ty - wy0; if (j >= 0 && j < 19) { lineT[j] = T_COIN; lineP[j] = PAL_S2; } }
    for (u8 j = 0; j < 19; j++) put(bc, (u8)(wy0 + j) & 31, lineT[j], lineP[j]);
}
static void drawTile(s16 wx, s16 wy) {                       // one tile (a coin taken)
    u8 t = BLANK, pal = PAL_S1;
    for (u8 i = 0; i < nPl; i++) { Plat *q = &pl[i]; if (q->ty == wy && wx >= q->tx && wx < q->tx + q->tw && !q->chair) { u8 k = (u8)(wx - q->tx); t = T_SLAB + q->col * 3 + (k == 0 ? 0 : k == q->tw - 1 ? 2 : 1); } }
    put((u8)wx & 31, (u8)wy & 31, t, pal);
}
static void redrawAll(void) { drawnC = tl(camX); drawnR = tl(camY); for (s16 wy = drawnR; wy < drawnR + 19; wy++) drawRowAt(wy); }
static void scrollIn(void) {                    // draw what the camera's move brought into view
    s16 c = tl(camX), r = tl(camY);
    if (absS(c - drawnC) > 6 || absS(r - drawnR) > 6) { redrawAll(); return; }
    while (drawnC < c) { drawnC++; drawColumn(drawnC + 20); }
    while (drawnC > c) { drawnC--; drawColumn(drawnC); }
    while (drawnR < r) { drawnR++; drawRowAt(drawnR + 18); }
    while (drawnR > r) { drawnR--; drawRowAt(drawnR); }
}
static void eraseCoin(u8 i) { s16 tx = co[i].tx, ty = co[i].ty; co[i] = co[--nCo]; drawTile(tx, ty); }
static void hudScore(void) { wtxt(0, 0, lbl("", score), PAL_TEXT); }
static void hud(void) {
    fillWin(0, 0, 20, 1, BLANK, PAL_TEXT);
    wtxt(0, 0, lbl("", score), PAL_TEXT);
    strcpy(sbuf, MODE_NAME[jMode]); strcat(sbuf, " BEST "); itoa10(sv.jumpBest[jMode], sbuf + strlen(sbuf));
    wtxt(20 - (u8)strlen(sbuf), 0, sbuf, PAL_GOLD);
}

// ── the run ───────────────────────────────────────────────────────────────
static s16 runV, jumpV, airV, gravV, fallV;
static void startRun(u8 m) {
    jMode = m; nPl = nOb = nCo = nPi = 0; score = 0; st = ST_PLAY; moveDir = 0; jumpQ = 0; frame = 0; coinsGot = 0;
    cls = runnerCls();
    runV = (s16)((326L * R_SPEED[cls]) >> 8); jumpV = (s16)((998L * R_JUMP[cls]) >> 8); airV = (s16)((938L * R_JUMP[cls]) >> 8);
    gravV = (s16)((56L * R_GRAV[cls]) >> 8); fallV = (s16)((1440L * R_GRAV[cls]) >> 8);
    startX = 48; startY = 104;
    p.x = (s32)startX << 8; p.y = (s32)(startY - 6) << 8; p.vx = p.vy = 0; p.onGround = 1; p.face = 1; airUsed = 0;
    bestX = startX; bestUp = startY - 6; lastGroundY = startY - 6;
    megaOn = 0; flight = bouncing = flappy = flappyFreeze = flapEndless = 0; cycles = 0; bounceCombo = 0; msgT = 0; flapPipeN = 0; noObsUntil = 0; upStart = 8;
    camX = startX - 64; camY = startY - 88;
    if (m == M_FLAP) {
        flapEndless = 1; flapBandY = startY - 49; flapLastX = startX + 58;
        p.y = (s32)flapBandY << 8; camY = flapBandY - 72; camX = startX - 64; flappyFreeze = 1; flappyEndX = 32000;
    } else {
        jAddPlat(startX - 27, startY, 54);
        if (m == M_COMBO) { zX = startX + 27; zY = startY; zCount = 0; zLast = 255; zSinceFlap = zSinceMega = 0; }
        else if (m == M_RUN) jGoRight(startX + 27, startY, rr(56, 96), startX + 67);
        else { genMode = 0; genX = startX; lastPlatX = startX; genY = startY - rr(18, 24); segLeft = 6 + rnd8() % 4; upStart = segLeft; }
    }
    screenFresh();
    loadBkgTiles(SCENE_T, JUMP_BG_N, jump_bg); loadSprTiles(ST_GAME, JUMP_SPR_N, jump_spr);
    static const u16 SKY[4] = { RGB8(30, 40, 90), RGB8(235, 70, 70), RGB8(60, 200, 90), RGB8(80, 140, 255) };
    static const u16 GOLDS[4] = { RGB8(30, 40, 90), RGB8(255, 205, 40), RGB8(255, 250, 200), RGB8(110, 70, 10) };
    static const u16 RUNC[3][4] = { { 0, RGB8(255, 230, 200), RGB8(80, 160, 255), RGB8(10, 10, 30) }, { 0, RGB8(255, 240, 220), RGB8(240, 150, 50), RGB8(40, 20, 0) }, { 0, RGB8(255, 80, 60), RGB8(250, 250, 240), RGB8(40, 30, 10) } };
    setBkgPal(PAL_S1, SKY); setBkgPal(PAL_S2, GOLDS); setSprPal(OP_S1, RUNC[cls]);
    for (u8 i = 0; i < 3; i++) jGenPath();
    clearBkg(BLANK, PAL_S1);
    redrawAll();
    hud(); winAt(7, 136);
    scroll((u8)camX, (u8)camY);
    lcdOn();
}
static void gameOver(void) {
    st = ST_DEAD; msgT = 40; flappy = 0; sfx(SFX_BAD);
}
static void finish(void) {
    u8 newBest = score > (s16)sv.jumpBest[jMode]; if (newBest) sv.jumpBest[jMode] = score;
    if (score > sv.arcadeBest[ARC_JUMP]) sv.arcadeBest[ARC_JUMP] = score;
    sv.arcadePlays[ARC_JUMP]++;
    s16 c = score / 25; if (c > 0) addCoins(c); coinsGot += c;
    saveWrite();
    char l1[20], l2[20], l3[20];
    strcpy(l1, MODE_NAME[jMode]); strcat(l1, "  "); itoa10(score, l1 + strlen(l1));
    strcpy(l2, newBest ? "NEW BEST!" : lbl("BEST ", sv.jumpBest[jMode]));
    strcpy(l3, "+"); itoa10(coinsGot, l3 + 1); strcat(l3, " COINS");
    st = ST_OVER; overDraw("GAME OVER", l1, l2, l3); sel = 0; overFirst = 1;
}
static void resumeRight(void) { if (jMode == M_COMBO) return; jGoRight(px() + 8, py() + 6, rr(32, 64), px() + 8 + 67); lastPlatX = px(); }
static void step(void) {
    frame++;
    for (u8 i = 0; i < nOb; i++) { Obs *o = &ob[i]; if (!o->patrol || (frame & 1)) continue; o->x += o->vx;
        if (o->x <= o->minX) { o->x = o->minX; o->vx = 1; } else if (o->x >= o->maxX) { o->x = o->maxX; o->vx = -1; } }
    if (msgT) msgT--;
    if (flappyFreeze) {
        p.vx = p.vy = 0;
        if (jumpQ) { flappyFreeze = 0; flappy = 1; p.vy = -694; p.vx = 310; sfx(SFX_JUMP); msg = "A TO FLAP!"; msgT = 120; }
    } else if (flappy) {
        p.vx = 310; p.face = 1;
        if (jumpQ && px() < flappyEndX) { p.vy = -694; sfx(SFX_JUMP); }
        p.vy += 46; if (p.vy > 933) p.vy = 933;
    } else if (flight) {
        p.vx += moveDir == 1 ? 48 : moveDir == 2 ? -48 : 0; if (!moveDir) p.vx -= p.vx / 50;
        if (p.vx > 864) p.vx = 864; if (p.vx < -864) p.vx = -864;
        if (moveDir) p.face = moveDir == 1 ? 1 : -1;
        p.vy += 48; if (p.vy > 1248) p.vy = 1248;
    } else if (bouncing) {
        p.vx += moveDir == 1 ? 38 : moveDir == 2 ? -38 : 0; if (!moveDir) p.vx += (403 - p.vx) / 20;
        if (p.vx > 864) p.vx = 864; if (p.vx < -576) p.vx = -576;
        if (moveDir) p.face = moveDir == 1 ? 1 : -1;
        p.vy += 56; if (p.vy > 1440) p.vy = 1440;
    } else {
        p.vx = moveDir == 1 ? runV : moveDir == 2 ? -runV : 0;
        if (moveDir) p.face = moveDir == 1 ? 1 : -1;
        if (p.onGround) airUsed = 0;
        if (jumpQ) {
            if (p.onGround) { p.vy = -jumpV; p.onGround = 0; sfx(SFX_JUMP); }
            else if (cls == 2 && !airUsed) { airUsed = 1; p.vy = -airV; sfx(SFX_JUMP); }   // the chicken: one more in the air
        }
        s16 g = gravV, mx = fallV;
        p.vy += g; if (p.vy > mx) p.vy = mx;
    }
    jumpQ = 0;
    s16 prevBottom = py() + 6;
    p.x += p.vx; p.y += p.vy;
    if (!flight && !bouncing && !flappy && !flappyFreeze && px() < camX + 8) p.x = (s32)(camX + 8) << 8;
    p.onGround = 0;
    s16 x = px(), y = py();
    if (p.vy >= 0) { s16 nb = y + 6;
        s16 ptx = x >> 3, pty0 = (prevBottom - 3) >> 3, pty1 = nb >> 3;
        for (u8 i = 0; i < nPl; i++) { Plat *q = &pl[i];
            if (q->ty < pty0 || q->ty > pty1 || q->tx > ptx + 1 || q->tx + q->tw < ptx) continue;     // (quick: tiles)
            s16 qx = platX(q), qy = platY(q);
            if (!(x + 2 > qx && x - 2 < qx + platW(q) && nb >= qy && prevBottom <= qy + 3)) continue;
            if (q->chain) { p.y = (s32)(qy - 7) << 8; p.vy = -1056; if (p.vx < 384) p.vx = 384; bouncing = 1; bounceCombo++; addCoins(3); coinsGot += 3; sfx(SFX_JUMP);
                if (bounceCombo >= 2) { static char b[12]; strcpy(b, "BOUNCE X"); itoa10(bounceCombo, b + 8); msg = b; msgT = 32; } break; }
            if (q->flappy && !flappy && !flappyFreeze) { p.y = (s32)(qy - 6 - 22) << 8; p.vx = p.vy = 0; flappyFreeze = 1; msg = "A TO JUMP"; msgT = 255; break; }
            if (q->chair && !flight && !flappy && !flappyFreeze) { p.y = (s32)(qy - 7) << 8; p.vy = -1536; p.vx = 768; flight = 1; sfx(SFX_GOOD); break; }
            p.y = (s32)(qy - 6) << 8; p.vy = 0; p.onGround = 1;
            if (flappy || flappyFreeze) { flappy = flappyFreeze = 0; resumeRight(); }
            if (flight) { flight = 0; megaOn = 0; resumeRight(); }
            if (bouncing) { bouncing = 0; bounceCombo = 0; resumeRight(); }
            break;
        } }
    x = px(); y = py();
    if (p.onGround) lastGroundY = y;
    if (flight || flappy || flappyFreeze) { camX += ((x - 80) - camX + (((x - 80) - camX) > 0 ? 7 : -7)) / 8; camY += ((y - 72) - camY) / 8; }
    else {                                       // a dead zone: the website's 0.30-0.48 across, 0.36-0.60 down
        s16 sx = x - camX, sy = y - camY;
        if (sy < 52) camY -= (52 - sy + 3) / 4; else if (sy > 86) camY += (sy - 86 + 3) / 4;
        if (sx < 48) camX -= (48 - sx + 3) / 4; else if (sx > 77) camX += (sx - 77 + 3) / 4;
    }
    if (x > bestX) bestX = x;
    if (y < bestUp) bestUp = y;
    s16 sc = flapEndless ? score : progress();
    if (!flapEndless && sc != score) { score = sc; hudScore(); }
    jGenPath();
    s16 ctx = x >> 3, cty = y >> 3;
    for (u8 i = 0; i < nCo; i++) { if (co[i].tx < ctx - 1 || co[i].tx > ctx + 1 || co[i].ty < cty - 1 || co[i].ty > cty + 1) continue;
        s16 cx = (co[i].tx << 3) + 4, cy = (co[i].ty << 3) + 4;
        if (absS(x - cx) < 6 && absS(y - cy) < 7) { eraseCoin(i); addCoins(1); coinsGot++; sfx(SFX_COIN); break; } }
    for (u8 i = 0; i < nOb; i++) { Obs *o = &ob[i];
        if (x + 3 > o->x - 3 && x - 3 < o->x + 3 && y + 6 > o->y - 11 && y - 6 < o->y - 1) { gameOver(); return; } }
    if (megaOn && !megaHit && absS(x - megaX) < 10 && absS(y - megaY) < 8) {
        megaHit = 1; msg = "MEGA!"; msgT = 75; sfx(SFX_GOOD);
        for (u8 k = 0; k < 10; k++) jAddCoin(megaX + rr(-14, 14), megaY + rr(-14, 14));
        redrawAll();
    }
    if (megaOn && (megaX < camX - 80 || megaY > camY + 270)) megaOn = 0;
    if (flappy) {
        if (flapEndless) { flapCeil = camY + 6; flapFloor = camY + 132; }
        for (u8 i = 0; i < nPi; i++) { Pipe *q = &pi[i]; s16 qx = q->tx << 3, qw = (s16)q->tw << 3, gt = q->gapT << 3, gb = q->gapB << 3;
            if (x + 2 > qx && x - 2 < qx + qw && (y - 4 < gt || y + 4 > gb)) { gameOver(); return; }
            if (!q->passed && x > qx + qw) { q->passed = 1; addCoins(2); coinsGot += 2; sfx(SFX_COIN); if (flapEndless) { score++; hudScore(); } } }
        if (y < flapCeil + 6) { p.y = (s32)(flapCeil + 6) << 8; if (p.vy < 0) p.vy = 0; }
        if (y > flapFloor) { gameOver(); return; }
    }
    if (jMode != M_COMBO && !flappy && !flappyFreeze && !flight && !bouncing && p.onGround && (frame & 15) == 0) {   // never a dead end ahead
        s16 pb = y + 6; u8 ahead = 0;
        for (u8 i = 0; i < nPl; i++) { Plat *q = &pl[i]; s16 qx = platX(q), qy = platY(q);
            if (qx + platW(q) > x + 8 && qx < x + 100 && qy - pb > -72 && qy - pb < 158) { ahead = 1; break; } }
        if (!ahead) { jAddPlat(x + 58, pb, 48); if (genMode != 0) { jGoRight(x + 106, pb, rr(48, 80), x + 144); lastPlatX = genX - 19; } redrawAll(); }
    }
    if (!flappy && !flappyFreeze) { s16 pit = (flight || bouncing) ? 245 : 144; if (y - lastGroundY > pit) gameOver(); }
}
static void drawSprites(void) {
    s16 x = px() - camX, y = py() - camY;
    u8 pose = !p.onGround ? 2 : moveDir && ((frame >> 3) & 1) ? 1 : 0;
    if (st != ST_DEAD || (msgT & 4)) spr16(x, y - 2, T_RUN + cls * 12 + pose * 4, (isCGB ? OP_S1 : 0) | (p.face < 0 ? 0x20 : 0));
    for (u8 i = 0; i < nOb; i++) { Obs *o = &ob[i]; s16 ox = o->x - camX, oy = o->y - camY - 7; if (ox < -8 || ox > 168 || oy < -8 || oy > 152) continue;
        marker(ox, oy, o->col, o->patrol ? (u8)(64 + o->x * 4) : 64); }
    static u8 chairIdx[10], nChairs, seenPl = 255, seenFirst; static s16 seenTx;
    if (seenPl != nPl || seenTx != pl[0].tx) { seenPl = nPl; seenTx = pl[0].tx; nChairs = 0; for (u8 i = 0; i < nPl && nChairs < 10; i++) if (pl[i].chair) chairIdx[nChairs++] = i; }
    for (u8 k = 0; k < nChairs; k++) { Plat *q = &pl[chairIdx[k]];
        s16 cx = platX(q) + platW(q) / 2 - camX, cy = platY(q) - camY - 6; if (cx < -8 || cx > 168 || cy < -8 || cy > 152) continue;
        spr16(cx, cy, ST_CHAIR, isCGB ? OP_RED : 0); }
    if (megaOn && !megaHit) spr16(megaX - camX, megaY - camY, T_MEGA, isCGB ? OP_GOLD : 0);
    if (msgT && msg) sprText(80 - (s16)strlen(msg) * 4, 40, msg, isCGB ? OP_WHITE : 0);
}

static void menuScreen(void) {
    screenFresh(); txtC(0, "QU33PH JUMP", PAL_GOLD);
    static const char * const BL[4] = { "THE FULL MIX", "CLIMB FOREVER", "ENDLESS RUNNER", "THREAD THE PIPES" };
    for (u8 i = 0; i < 4; i++) { txt(4, 2 + i * 2, MODE_NAME[i], PAL_TEXT); txt(11, 2 + i * 2, lbl("BEST ", sv.jumpBest[i]), PAL_GREY); txt(4, 3 + i * 2, BL[i], PAL_GREY); }
    txt(4, 11, "RUNNER:", PAL_TEXT); txt(4, 13, "BACK", PAL_TEXT);
    txt(0, 16, "LEFT/RIGHT RUN, A/UP", PAL_GREY); txt(0, 17, "JUMP AND FLAP", PAL_GREY);
    loadSprTiles(ST_GAME, JUMP_SPR_N, jump_spr);
    lcdOn();
}
static const u8 MENU_Y[6] = { 2, 4, 6, 8, 11, 13 };
static void menuCursor(void) {
    for (u8 i = 0; i < 6; i++) put(2, MENU_Y[i], i == sel ? UI_CURSOR : BLANK, PAL_GOLD);
    fillBkg(12, 11, 8, 1, BLANK, PAL_TEXT); txt(12, 11, R_NAME[runnerCls()], PAL_GOLD);
}
void jumpEnter(void) BANKED { }
void jumpUpdate(void) BANKED {
    if (entering) { st = ST_MENU; sel = 0; menuScreen(); menuCursor(); }
    music(MUS_JUMP);
    if (st == ST_MENU) {
        u8 old = sel;
        if (kDown & J_DOWN) sel = (sel + 1) % 6;
        if (kDown & J_UP) sel = (sel + 5) % 6;
        if (sel == 4 && (kDown & (J_LEFT | J_RIGHT | J_A))) { u8 c = runnerCls(); c = (kDown & J_LEFT) ? (c + 2) % 3 : (c + 1) % 3; sv.jumpChar = c * 2; saveWrite(); sfx(SFX_MOVE); menuCursor(); }
        else if (kDown & J_A) { if (sel < 4) { sfx(SFX_SELECT); startRun(sel); return; } if (sel == 5) { goScreen(S_ARCADE); return; } }
        if (kDown & J_B) { goScreen(S_ARCADE); return; }
        if (old != sel) { sfx(SFX_MOVE); menuCursor(); }
        static u8 t; t++;
        u8 c = runnerCls(); spr16(148, 118, T_RUN + c * 12 + ((t >> 3) & 1) * 4, isCGB ? OP_S1 : 0);
        static const u16 RUNC[3][4] = { { 0, RGB8(255, 230, 200), RGB8(80, 160, 255), RGB8(10, 10, 30) }, { 0, RGB8(255, 240, 220), RGB8(240, 150, 50), RGB8(40, 20, 0) }, { 0, RGB8(255, 80, 60), RGB8(250, 250, 240), RGB8(40, 30, 10) } };
        setSprPal(OP_S1, RUNC[c]);
        return;
    }
    if (st == ST_OVER) {
        static const char * const O[2] = { "PLAY AGAIN", "MODES" };
        u8 e = entering; if (overFirst) { entering = 1; overFirst = 0; }
        s8 h = menuList(4, 13, 2, O, &sel, 2);
        entering = e;
        if (h == 0) startRun(jMode); else if (h == 1 || h == -2) goScreen(S_JUMP);
        return;
    }
    if (st == ST_DEAD) { if (msgT) msgT--; drawSprites(); if (!msgT) finish(); return; }
    u8 ps = pauseCheck(); if (ps == 1) return;
    if (ps == 2) winAt(7, 136);
    u8 l = (kHeld & J_LEFT) != 0, r = (kHeld & J_RIGHT) != 0;
    moveDir = l && !r ? 2 : r && !l ? 1 : 0;
    if (kDown & (J_A | J_B | J_UP)) jumpQ = 1;
    step();
    if (st == ST_PLAY && (++speedAcc & 1)) step();                    // 3 steps every 2 frames
    if (st == ST_OVER) return;
    scrollIn();
    scroll((u8)camX, (u8)camY);
    drawSprites();
}
