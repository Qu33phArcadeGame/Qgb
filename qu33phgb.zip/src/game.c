// game.c — the Qu33ph match: the website's rules and physics (in whole numbers: the Game Boy
// has no floating point), on a table seen from above that scrolls to follow the throw, with the
// time, score and markers in a panel on the right.
#pragma bank 255
#include "qu.h"
#include "res_match.h"

// ── the website's world (420 x 900 units); positions are kept in 256ths of a unit ──
#define U(v) ((s32)((v) * 256))
#define LEFT_EDGE    U(77.7)
#define RIGHT_WALL   U(211.9)
#define FIELD_CX     U(144.8)
#define LAUNCH_Y     U(877.5)
#define END_LINE_Y   U(99.0)
#define START_LINE_Y U(820.0)
#define REDDOT_X     U(217.9)
#define REDDOT_Y     U(159.8)
#define TOUCH2       (45L * 45L)          // touching: closer than 45 units
#define FIELD_W 120                       // the field's width on screen; the panel is the rest
#define CAM_REST (720 - 144)              // the camera at rest shows the launch end

typedef struct { s32 x, y; s16 vx, vy, curve, spin; u16 rot; u8 life, stopped, fallen, armed, deducted, mega, col; } Marker;
static Marker mk[3];
static u8 current;
s16 score2[2]; u8 player, p2Round, matchOver, orient;
u16 roundFrames, totalFrames; u8 suddenDeath; static u8 setHoldT, landHoldT; static s8 lastThrown = -1;
static s32 chairX, chairY;
static s16 camY = CAM_REST, camT;          // camera (pixels from the table's top)
static u8 drawnTop = 255;                  // the first table row drawn into the background map
static u16 aim = 192 * 16;                 // straight up the table (in 16ths of a 256th of a turn)
static u8 charging, chargeT, power, ph;
static const char * const ORIENT_SHORT[3] = { "VERT", "ANGLE", "FLAT" };

// ── popups (letters as sprites) and the banner ────────────────────────────
typedef struct { s32 x, y; u8 life; char t[8]; } Pop;
static Pop pops[3];
static char banner[2][10]; static u8 bannerT;
static void popup(s32 x, s32 y, const char *t) {
    for (u8 i = 0; i < 3; i++) if (!pops[i].life) { pops[i].x = x; pops[i].y = y; pops[i].life = 60; strncpy(pops[i].t, t, 7); pops[i].t[7] = 0; return; }
}
static void showBanner(const char *a, const char *b) { strncpy(banner[0], a, 9); banner[0][9] = 0; strncpy(banner[1], b ? b : "", 9); banner[1][9] = 0; bannerT = 75; }

// ── drag in shifts and adds ──
static s16 damp94(s16 v) { if (v < 0) { u16 a = -v; return -(s16)(a - (a >> 4) + (a >> 9)); } { u16 a = v; return a - (a >> 4) + (a >> 9); } }   // x 0.94
static s16 damp96(s16 v) { if (v < 0) { u16 a = -v; return -(s16)(a - (a >> 5) - (a >> 7)); } { u16 a = v; return a - (a >> 5) - (a >> 7); } }  // x 0.96
static s16 frac(s16 v, u8 k) { return v < 0 ? -(s16)(((u16)-v * k) >> 8) : (s16)(((u16)v * k) >> 8); }   // v * k/256 (small v only)

// ── screen positions ──────────────────────────────────────────────────────
// (x 0.8 per unit, as (v * 51) >> 6 in shifts and adds: the Game Boy has no multiply)
static u16 x51(u16 v) { return ((v << 5) + (v << 4) + (v << 1) + v) >> 6; }
static s16 unitsOf(s32 w) { return (s16)((*(((u16 *)&w) + 0) >> 8) | (*(((u16 *)&w) + 1) << 8)); }   // w >> 8
static s16 sxOf(s32 wx) { s16 u = unitsOf(wx) - 72; return u < 0 ? -(s16)x51((u16)-u) : (s16)x51((u16)u); }
static s16 syOf(s32 wy) { s16 u = unitsOf(wy); return (u < 0 ? -(s16)x51((u16)-u) : (s16)x51((u16)u)) - camY; }

// ── the table into the background, a row at a time as the camera scrolls ──
// every kind of table row, ready made (so streaming rows in as the camera moves is quick)
#define RW(a, b) { a, b, b, b, b, b, b, b, b, b, b, b, b, b, 3 }
static const u8 ROWS[14][15] = {
    { 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6 },           // 0 the back wall
    { 9, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 10 },          // 1 the end line
    { 2, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 3 },           // 2 the start line
    { 2, 0, 0, 0, 0, 0, 0, 7, 0, 0, 0, 0, 0, 0, 3 },           // 3 the launch spot
    { 2, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 8 },           // 4 the red dot on the wall
    { 2, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 3 },           // 5.. plain table (a little grain, varied)
    { 2, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 3 },
    { 2, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 3 },
    { 2, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 3 },
    { 2, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 3 },
    { 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 3 },
    { 2, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3 },
    { 2, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 3 },
    { 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3 } };
static const u8 ATTR_S1[15] = { PAL_S1, PAL_S1, PAL_S1, PAL_S1, PAL_S1, PAL_S1, PAL_S1, PAL_S1, PAL_S1, PAL_S1, PAL_S1, PAL_S1, PAL_S1, PAL_S1, PAL_S1 };
static const u8 ATTR_DOT[15] = { PAL_S1, PAL_S1, PAL_S1, PAL_S1, PAL_S1, PAL_S1, PAL_S1, PAL_S1, PAL_S1, PAL_S1, PAL_S1, PAL_S1, PAL_S1, PAL_S1, PAL_S2 };
static void tableRow(u8 r) {                          // table row r (8 pixels = 10 units) -> map row r & 31
    u8 k = (r < 9 || r >= 90) ? 0 : r == 9 ? 1 : r == 82 ? 2 : r == 87 ? 3 : r == 15 ? 4 : 5 + (r & 7);
    setBkgMap(0, r & 31, 15, 1, ROWS[k], k == 4 ? ATTR_DOT : ATTR_S1);
}
static void tableScroll(void) {
    u8 top = (u8)(camY >> 3);
    if (drawnTop == 255) { for (u8 r = 0; r < 19; r++) if (top + r < 90) tableRow(top + r); drawnTop = top; }
    while (drawnTop > top) { drawnTop--; tableRow(drawnTop); }
    while (drawnTop < top) { drawnTop++; if (drawnTop + 18 < 90) tableRow(drawnTop + 18); }
    SCY_REG = (u8)camY; SCX_REG = 0;
}

// ── the panel (the window layer, on the right) ────────────────────────────
static u8 panelLeft = 255, panelCur = 255, panelOri = 255; static s16 panelS0 = -999, panelS1 = -999; static u8 panelSD = 255, panelP = 255;
static char pb[12];
static void panelDraw(u8 all) {
    u16 left = totalFrames > roundFrames ? (totalFrames - roundFrames + 59) / 60 : 0;
    if (all) {
        fillWin(0, 0, 5, 18, BLANK, PAL_TEXT);
        for (u8 y = 0; y < 18; y++) wput(0, y, UI_L, PAL_GREY);
        wtxt(1, 13, "SEL", PAL_GREY); wtxt(1, 16, "UP", PAL_GREY); wtxt(1, 17, "LOOK", PAL_GREY);
        panelLeft = panelCur = panelOri = panelSD = panelP = 255; panelS0 = panelS1 = -999;
    }
    if (panelSD != suddenDeath) { panelSD = suddenDeath; wtxt(1, 0, suddenDeath ? "SUDN" : "TIME", suddenDeath ? PAL_RED : PAL_GREY); panelLeft = 255; }
    if (panelLeft != (u8)left) { panelLeft = (u8)left; wnum(1, 1, left, 3, suddenDeath ? PAL_RED : PAL_TEXT); }
    if (gmode != M_TWO) {
        if (panelS0 != score2[0]) { panelS0 = score2[0]; wtxt(1, 3, "PTS", PAL_GREY); fillWin(1, 4, 4, 1, BLANK, PAL_GOLD); scoreStr(pb, score2[0]); wtxt(1, 4, pb, PAL_GOLD); }
    } else if (panelS0 != score2[0] || panelS1 != score2[1] || panelP != player) {
        panelS0 = score2[0]; panelS1 = score2[1]; panelP = player;
        wtxt(1, 3, "P1", player == 0 ? PAL_GOLD : PAL_GREY); fillWin(1, 4, 4, 1, BLANK, PAL_TEXT); scoreStr(pb, score2[0]); wtxt(1, 4, pb, player == 0 ? PAL_GOLD : PAL_TEXT);
        wtxt(1, 5, "P2", player == 1 ? PAL_GOLD : PAL_GREY); fillWin(1, 6, 4, 1, BLANK, PAL_TEXT); scoreStr(pb, score2[1]); wtxt(1, 6, pb, player == 1 ? PAL_GOLD : PAL_TEXT);
        strcpy(pb, "R"); itoa10(p2Round, pb + 1); wtxt(1, 7, pb, PAL_GREY);
    }
    if (panelCur != current) {                          // the markers left this set
        panelCur = current;
        for (u8 i = 0; i < 3; i++) wput(1 + i, 9, i >= current ? UI_MK0 + i : BLANK, i == 0 ? PAL_GREEN : i == 1 ? PAL_RED : PAL_BLUE);
    }
    if (panelOri != orient) { panelOri = orient; fillWin(1, 14, 4, 1, BLANK, PAL_TEXT); wtxt(1, 14, ORIENT_SHORT[orient], PAL_TEXT); }
}

// ── a set of three ────────────────────────────────────────────────────────
static void resetSet(void) { current = 0; memset(mk, 0, sizeof mk); }
void startMatch(void) BANKED {
    resetSet(); setHoldT = 0; roundFrames = 0; suddenDeath = 0; matchOver = 0;
    u8 rt = gmode == M_TWO ? sv.timer2p : sv.timer1p;
    totalFrames = gmode == M_TWO ? (u16)rt * 60 : (u16)(rt * 3 / 2) * 60;     // 1P & Olympics: sudden death for the last third
    chairX = FIELD_CX; chairY = U(117.0);
    camY = CAM_REST; lastThrown = -1; landHoldT = 0; bannerT = 0; charging = 0; chargeT = 0;
    memset(pops, 0, sizeof pops);
}
static void addScore(s16 d) { score2[player] += d; }
static void throwMarker(u8 pw255) {
    if (current >= 3) return;
    Marker *m = &mk[current];
    memset(m, 0, sizeof *m);
    u8 a = (u8)(aim >> 4);
    s16 c = COSB(a), s = SINB(a);
    s16 pw = 70 + (s16)(((u16)pw255 * 180) >> 8);              // the website's 70-250
    m->x = FIELD_CX; m->y = LAUNCH_Y;
    m->vx = (s16)(((s32)c * pw * 103) >> 8); m->vy = (s16)(((s32)s * pw * 103) >> 8);   // (x 0.2, in 256ths)
    m->curve = (s16)(((s32)c * pw * 159) >> 18);
    m->spin = orient == 0 ? 834 : orient == 1 ? 1251 : 1877;    // 0.08 / 0.12 / 0.18 radians a frame (rot: 65536 a turn)
    m->col = current; lastThrown = current; landHoldT = 0;
    // land in the orientation picked: start turned so the flight's spin ends there
    u16 target = orient == 0 ? 64 * 256 : orient == 1 ? 32 * 256 : 0;
    { s16 sp = m->spin; u16 tot = 0; for (u8 k = 0; k < 59; k++) { tot += (u16)sp; sp = damp96(sp); } m->rot = target - tot; }
    current++;
    sfx(SFX_THROW);
}
static u8 touching(Marker *a, Marker *b) {
    s16 dx = unitsOf(a->x - b->x), dy = unitsOf(a->y - b->y);
    if (dx < 0) dx = -dx;
    if (dy < 0) dy = -dy;
    if (dx >= 45 || dy >= 45) return 0;
    return (u16)((u8)dx * (u8)dx) + (u16)((u8)dy * (u8)dy) < 45 * 45;
}
static void triggerMega(Marker *m) {
    m->x = REDDOT_X; m->y = REDDOT_Y; m->vx = m->vy = 0; m->stopped = 1;
    addScore(20);
    showBanner("MEGA", "+10");
    sfx(SFX_GOOD); sv.megas++;
}
static s16 calcRoundScore(void) {
    Marker *g = &mk[0], *r = &mk[1], *b = &mk[2];
    if (!(g->armed && r->armed && b->armed)) return 0;
    u8 gr = touching(g, r), rb = touching(r, b), gb = touching(g, b);
    if (suddenDeath) { if (gr && rb && gb) return 20; if (rb || gb) return 10; if (gr) return 6; return 0; }
    if (gr && rb && gb) return 6;          // QU33PH = 3
    if (rb || gb) return 4;                // blue touching = 2
    if (gr) return 1;                      // green-red = 0.5
    return 0;
}
static char tb[10], tb2[8];
static void tryAdvanceRound(void) {
    if (setHoldT) { if (--setHoldT == 0) { resetSet(); lastThrown = -1; } return; }
    if (current < 3) return;
    for (u8 i = 0; i < 3; i++) if (!mk[i].stopped && !mk[i].fallen) return;
    Marker *g = &mk[0], *r = &mk[1], *b = &mk[2];
    if (!b->fallen && suddenDeath && b->y > chairY) { addScore(-4); popup(LEFT_EDGE + U(4), chairY + U(60), "PEEF-2"); sfx(SFX_PEEF); sv.peefs++; }
    s16 rs = calcRoundScore();
    addScore(rs);
    scoreStr(tb2, rs); strcpy(tb, "+"); strcat(tb, tb2);
    if (!g->fallen && !r->fallen && !b->fallen && touching(g, r) && touching(r, b) && touching(g, b)) {
        showBanner("QU33PH!", tb); sfx(SFX_GOOD); sv.qu33phs++;
    } else showBanner(tb, 0);
    setHoldT = 45;
}
static s16 absS(s16 v) { return v < 0 ? -v : v; }
static void stepMatch(void) {
    roundFrames++;
    u8 rt = gmode == M_TWO ? sv.timer2p : sv.timer1p;
    if (gmode != M_TWO && roundFrames > (u16)rt * 60 && !suddenDeath) {
        suddenDeath = 1; chairX = FIELD_CX; chairY = END_LINE_Y + U(90);
        showBanner("SUDDEN", "DEATH!"); sfx(SFX_BAD);
    }
    if (roundFrames > totalFrames) { matchOver = 1; return; }
    for (u8 i = 0; i < current; i++) {
        Marker *m = &mk[i];
        if (m->stopped || m->fallen) continue;
        if (++m->life >= 60) { m->stopped = 1; m->vx = m->vy = 0; sfx(SFX_PLOP); }
        m->vx += m->curve;
        m->x += m->vx; m->y += m->vy;
        if (!m->armed && m->y < START_LINE_Y) m->armed = 1;
        m->vx = damp94(m->vx); m->vy = damp94(m->vy);
        m->rot += (u16)m->spin; m->spin = damp96(m->spin);
        if (suddenDeath && !m->mega) {
            s32 dx = (m->x - chairX) >> 8, dy = (m->y - chairY) >> 8;
            if (dx * dx + dy * dy < 35L * 35L) {
                if ((rnd8() & 3) == 0) triggerMega(m);
                else {                                  // the website's gentle chair bounce
                    u8 a = atan2i((s16)dy, (s16)dx);
                    s16 nx = COSB(a), ny = SINB(a);     // *127
                    m->x = chairX + (s32)nx * 106; m->y = chairY + (s32)ny * 106;   // 1.5 x the radius out
                    s32 relv = ((s32)m->vx * nx + (s32)m->vy * ny) >> 7;
                    if (relv < 0) { m->vx -= (s16)((relv * nx * 205) >> 14); m->vy -= (s16)((relv * ny * 205) >> 14); }   // x 1.6
                    s8 side = dx < 0 ? -1 : 1;
                    m->vx += (s16)(-ny * side * 461 / 127); m->vy += (s16)(nx * side * 461 / 127);   // 1.8 sideways
                    if (m->vy > -256) m->vy = -256 - (s16)(rnd8());
                    if (m->vx < -768) m->vx = -768 + (s16)(rnd8() + (rnd8() >> 1));
                    m->spin += nx > 0 ? 11469 : -11469;
                }
                m->mega = 1;
            }
        }
        if (m->x < LEFT_EDGE) {
            if (!m->deducted) {
                u8 ded = suddenDeath ? 5 : 2;
                addScore(-2 * ded); m->deducted = 1;
                popup(LEFT_EDGE + U(4), m->y < END_LINE_Y + U(40) ? END_LINE_Y + U(40) : m->y, suddenDeath ? "PEEF-5" : "PEEF-2");
                sfx(SFX_PEEF); sv.peefs++;
            }
            m->fallen = 1;
        }
        if (m->x > RIGHT_WALL) { m->x = RIGHT_WALL; m->vx = -(m->vx * 2 / 5); sfx(SFX_WALL); }
        if (m->y < END_LINE_Y) { m->y = END_LINE_Y; m->vy = -(m->vy / 5); sfx(SFX_WALL); }
        if (!m->stopped && absS(m->vx) < 13 && absS(m->vy) < 13) { m->stopped = 1; sfx(SFX_PLOP); }
        if ((m->stopped || m->fallen) && (s8)i == lastThrown) landHoldT = 60;
    }
    for (u8 i = 0; i < 3; i++) if (pops[i].life) { pops[i].life--; pops[i].y -= U(1); }
    if (bannerT) bannerT--;
    tryAdvanceRound();
    // the camera: follow the marker furthest up the table; once it stops hold on it a second
    // (or while the set is scored), then come back to the launch end. UP looks up the table.
    s16 target = CAM_REST; s8 lead = -1;
    for (u8 i = 0; i < current; i++) if (!mk[i].stopped && !mk[i].fallen && (lead < 0 || mk[i].y < mk[(u8)lead].y)) lead = (s8)i;
    if (landHoldT) landHoldT--;
    if (lead < 0 && lastThrown >= 0 && (u8)lastThrown < current && !mk[(u8)lastThrown].fallen && (landHoldT || setHoldT)) lead = lastThrown;
    if (lead >= 0) target = syOf(mk[(u8)lead].y) + camY - 79;
    else if (kHeld & J_UP) {
        s32 top = 0x7FFFFFFF;
        for (u8 i = 0; i < current; i++) if (!mk[i].fallen && mk[i].y < top) top = mk[i].y;
        if (top == 0x7FFFFFFF) top = suddenDeath ? chairY : END_LINE_Y + U(60);
        target = syOf(top) + camY - 72;
    }
    if (target < 0) target = 0;
    if (target > CAM_REST) target = CAM_REST;
    s16 d = target - camY;                              // (at most 12 pixels a frame: it streams the table in)
    if (d) { s16 st = d < 0 ? (d >> 3) + (d >> 5) - 1 : (d >> 4) + (d >> 5) + 1; if (absS(st) > absS(d)) st = d; if (st > 12) st = 12; if (st < -12) st = -12; camY += st; }
}

// ── aiming with buttons ───────────────────────────────────────────────────
// left/right aim; hold A to charge (the power swings up and down), let go to throw; B cancels;
// SELECT changes how the marker lands
static void matchInput(void) {
    if (kDown & J_SELECT) { orient = (orient + 1) % 3; sfx(SFX_MOVE); }
    if (kHeld & J_LEFT)  { aim -= 20; chargeT = 90; }
    if (kHeld & J_RIGHT) { aim += 20; chargeT = 90; }
    if (kHeld & (J_LEFT | J_RIGHT | J_A)) landHoldT = 0;
    if (aim < 150 * 16) aim = 150 * 16;
    if (aim > 234 * 16) aim = 234 * 16;
    if (kDown & J_A) { charging = 1; power = 0; ph = 0; }
    if (charging) {
        ph++; u8 t = ph % 30; power = t < 15 ? t * 17 : (30 - t) * 17;    // full in a quarter of a second
        chargeT = 90;
        if (kDown & J_B) charging = 0;
        else if (kUp & J_A) { charging = 0; throwMarker(power); }
    }
    if (chargeT && !charging) chargeT--;
}

// ── drawing (sprites) ─────────────────────────────────────────────────────
static void drawSprites(void) {
    // the banner and the popups first (they matter most if the sprites run short)
    if (bannerT) for (u8 l = 0; l < 2; l++) if (banner[l][0]) { u8 n = (u8)strlen(banner[l]); sprText((FIELD_W - n * 8) / 2, 40 + l * 12, banner[l], isCGB ? OP_WHITE : 0); }
    for (u8 i = 0; i < 3; i++) if (pops[i].life) sprText(sxOf(pops[i].x), syOf(pops[i].y), pops[i].t, isCGB ? OP_RED : 0);
    // the power marker grows out of the launch spot
    u8 ready = current < 3 && !setHoldT;
    if (ready && (charging || chargeT)) {
        u8 len = charging ? 16 + (u8)(((u16)power * 56) >> 8) : 16;
        powerMarker(sxOf(FIELD_CX), syOf(LAUNCH_Y), (u8)(aim >> 4), len, charging ? (power < 10 ? 10 : power) : 0);
        if (isCGB) {                                  // its fill: white through gold to red with the power
            u16 p[4]; u8 r = power >> 3;
            p[0] = 0; p[1] = RGB8(255, 255, 255); p[2] = RGB8(255, 255 - r * 5, r < 16 ? 255 - r * 16 : 0); p[3] = RGB8(15, 15, 15);
            setSprPal(OP_GOLD, p);
        }
    }
    for (u8 i = 0; i < current; i++) {
        Marker *m = &mk[i];
        if (m->fallen && m->x < LEFT_EDGE - U(40)) continue;
        s16 x = sxOf(m->x), y = syOf(m->y);
        u8 touch = 0;
        if (!m->fallen && m->stopped) for (u8 j = 0; j < current; j++) if (j != i && !mk[j].fallen && touching(m, &mk[j])) touch = 1;
        if (touch && ((roundFrames >> 3) & 1)) spr(x - 4, y - 14, UI_SPARK, isCGB ? OP_GOLD : 0);
        marker(x, y, m->col, (u8)(m->rot >> 8));
    }
    // the markers still to throw this set wait above the launch spot (hidden while you charge)
    if (!charging) for (u8 i = current; i < 3; i++)
        marker(sxOf((LEFT_EDGE + RIGHT_WALL) / 2), syOf(LAUNCH_Y - U(30) - (s32)i * U(46)), i, orient == 0 ? 64 : orient == 1 ? 32 : 0);
    if (suddenDeath) spr16(sxOf(chairX), syOf(chairY), ST_CHAIR, isCGB ? OP_RED : 0);
}

// ── the screen ────────────────────────────────────────────────────────────
static const u16 TABLE_PAL[4] = { RGB8(222, 184, 135), RGB8(200, 160, 110), RGB8(120, 80, 40), RGB8(40, 30, 25) };
static const u16 DOT_PAL[4] = { RGB8(40, 30, 25), RGB8(230, 30, 30), RGB8(230, 30, 30), RGB8(40, 30, 25) };
static u8 paused;
static void enterMatch(void) {
    lcdOff(); uiPalettes();
    loadBkgTilesBanked(BANK(res_match), SCENE_T, MATCH_TILE_COUNT, match_tiles);
    setBkgPal(PAL_S1, TABLE_PAL); setBkgPal(PAL_S2, DOT_PAL);
    clearBkg(SCENE_T + 6, PAL_S1);
    drawnTop = 255; tableScroll();
    panelDraw(1); winAt(7 + FIELD_W, 0);
    paused = 0;
    lcdOn();
}
static void pauseShow(u8 on) {
    if (on) {
        winAt(7, 48);
        fillWin(0, 0, 20, 12, BLANK, PAL_TEXT);
        wtxt(7, 1, "PAUSED", PAL_GOLD); wtxt(3, 4, "START  RESUME", PAL_TEXT); wtxt(3, 6, "SELECT  QUIT", PAL_TEXT);
    } else { panelDraw(1); winAt(7 + FIELD_W, 0); }
}
void matchEnter(void) BANKED { }
void matchUpdate(void) BANKED {
    if (entering) enterMatch();
    music(MUS_MAIN);
    if (screen == S_PAUSE) {
        if (!paused) { paused = 1; pauseShow(1); }
        if (kDown & (J_START | J_A)) { paused = 0; pauseShow(0); screen = S_PLAY; }
        else if (kDown & J_SELECT) { sv.forfeits++; saveWrite(); paused = 0; goScreen(S_TITLE); }
        return;
    }
    if (kDown & J_START) { screen = S_PAUSE; return; }
    matchInput();
    stepMatch();
    if (matchOver) { matchFinished(); return; }
    tableScroll();
    panelDraw(0);
    drawSprites();
}
