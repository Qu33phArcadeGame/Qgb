// jump.h — what jump.c (the run, the picture) and jumpgen.c (building the course) share
#ifndef JUMP_H
#define JUMP_H
#include "qu.h"
#define VW 96                           // the website's width W, in Game Boy pixels
#define VH 144
#define Q 256                           // player positions and speeds: 1/256 pixel
#define NPL 72
#define NOB 20
#define NCO 40
#define NPI 10
#define T_RUN ST_GAME                   // 3 runners x 3 poses x 4 tiles
#define T_MEGA (ST_GAME + 36)
typedef struct { s16 tx, ty; u8 tw, col, chair, chain, flappy, mz; } Plat;          // (tiles)
typedef struct { s16 x, y, minX, maxX; s8 vx; u8 col, patrol; } Obs;                  // (pixels; y = the ground it stands on)
typedef struct { s16 tx, ty; } Coin;
typedef struct { s16 tx, gapT, gapB; u8 tw, passed, col; } Pipe;                    // (tiles; the gap is rows gapT..gapB-1)
extern Plat pl[NPL]; extern u8 nPl; extern Obs ob[NOB]; extern u8 nOb; extern Coin co[NCO]; extern u8 nCo; extern Pipe pi[NPI]; extern u8 nPi;
typedef struct { s32 x, y; s16 vx, vy; u8 onGround; s8 face; } Player;
extern Player p;
enum { M_COMBO, M_JUMP, M_RUN, M_FLAP };
static const char * const MODE_NAME[4] = { "COMBO", "JUMP", "RUN", "FLAP" };
enum { ST_MENU, ST_PLAY, ST_DEAD, ST_OVER };
extern u8 jMode, st, sel, moveDir, jumpQ, flight, bouncing, flappy, flappyFreeze, flapEndless, airUsed, speedAcc, overFirst, bounceCombo, msgT, megaOn, megaHit, cls;
extern s16 score, coinsGot, megaX, megaY, startX, startY, bestX, bestUp, lastGroundY, flapCeil, flapFloor, flappyEndX, flapLastX, flapBandY;
extern s16 camX, camY, drawnC, drawnR; extern u16 frame;
static const char *msg;
// the generator
extern u8 genMode, segLeft, upStart, stairLeft, cycles, zLast, zCount, zSinceFlap, zSinceMega, flapPipeN;
extern s8 stairDir; extern s16 genX, genY, lastPlatX, noObsUntil, zX, zY;

// ── the runners: speed, jump, gravity (1/256), air jumps ─────────────────
static const u16 R_SPEED[3] = { 256, 384, 384 }, R_JUMP[3] = { 256, 362, 262 }, R_GRAV[3] = { 256, 256, 179 };
static const char * const R_NAME[3] = { "RUNNER", "CAT", "CHICKEN" };
static u8 runnerCls(void) { u8 c = sv.jumpChar; return c < 2 ? 0 : c < 4 ? 1 : 2; }

static s16 absS(s16 v) { return v < 0 ? -v : v; }
static s16 rr(s16 lo, s16 hi) { return rndr(lo, hi + 1); }
static u8 chance(u8 pct) { return (u8)(rnd16() % 100) < pct; }
static s16 px(void) { return (s16)(p.x >> 8); }
static s16 py(void) { return (s16)(p.y >> 8); }
static s16 progress(void) { s16 a = startY - bestUp, b = bestX - startX; if (a < 0) a = 0; if (b < 0) b = 0; if (a > 16000) a = 16000; if (b > 16000) b = 16000; s16 d = a + b; return (d >> 3) + (d >> 4) + (d >> 6) + (d >> 8); }

static s16 tl(s16 v) { return v >> 3; }
static s16 platX(const Plat *q) { return q->tx << 3; }
static s16 platY(const Plat *q) { return q->ty << 3; }
static s16 platW(const Plat *q) { return (s16)q->tw << 3; }
// jumpgen.c (its own bank)
Plat *jAddPlat(s16 x, s16 y, s16 w) BANKED;
void jAddCoin(s16 x, s16 y) BANKED;
void jGoRight(s16 x, s16 y, s16 len, s16 clear) BANKED;
void jGenPath(void) BANKED;
#endif
