// bowl.c — QU33PH BOWLING (the website's bowling.html): ten frames, marker pins.
// Bare bones: the lane seen from above, the scoresheet in the panel. The physics (hook, carry,
// the capsule-shaped marker, pin chain reactions), washouts, scoring, the 10th-frame chair and
// MEGA QU33PH are the GBA's (the website's), in whole numbers: lane positions in 1/16384 of the
// lane's half width (1/1024 for collisions), speeds per frame.
#pragma bank 255
#include "qu.h"
#include "res_bowl.inc"

#define U 1024                        // 1.0 (collision units)
#define PIN_R 82
#define BALL_R 78
#define BALL_HL 169
#define PIN_D 220
#define ROW_D 333
#define HEAD_Y 6093                   // 5.95
#define CHAIR_Y 5458
#define CHAIR_R 138
#define LANE_LEN 7168                 // 7.0
#define VQ(v) ((s16)((v) * 491.52))   // units a second -> 1/16384 a frame (the website's 0.03 s frames)

typedef struct { s16 X, Y, fx, fy; s16 vx, vy; u8 rot; s8 vrot; u8 sink, col, down, gone; } Pin;
static Pin pins[10];
static const s16 LAYOUT[10][2] = { {0,0}, {-PIN_D,1}, {PIN_D,1}, {-2*PIN_D,2}, {0,2}, {2*PIN_D,2}, {-3*PIN_D,3}, {-PIN_D,3}, {PIN_D,3}, {3*PIN_D,3} };
static const u8 PIN_COL[10] = { 2, 0, 1, 0, 1, 0, 1, 0, 1, 0 };          // red 0, green 1, blue 2
static const u8 QUEUE[10] = { 0, 1, 0, 1, 0, 1, 0, 1, 0, 2 };            // blue always last
static const u8 MK_KIND[3] = { 1, 0, 3 };
static const u8 MK_COL[3] = { 1, 0, 2 };                                 // colour -> marker() colour                                // colour -> little marker kind
static struct { s16 X, Y, fx, fy; s16 vx, vy, spin; u8 rot, col, live, gutter; u16 carry; } ball; static u8 haveBall;
static struct { s16 X, Y, fx, fy; s16 vx, vy; u8 shoved; } chr; static u8 haveChair;
static u8 flying, flyT; static s16 flyX0, flyY0;
enum { ST_MENU, PH_AIM, PH_ROLL, PH_MEGA, PH_OVER };
static u8 phase, frameNo, rollNo, rolls[24], nRolls, megaRight, megaWon, standStart, orientIdx = 1, msgT, sel, newBest;
static s16 aimX, coinsWon; static u8 settleT, power, charging, ph, pinSfxT, panelDirty;
static const char *msg;

typedef struct { const char *label; u8 rot; u8 hook, speed, carry; } Ori;    // hook/speed/carry in 1/64
static const Ori ORI[3] = { { "VERT  ", 0, 106, 60, 54 }, { "ANGLED", 32, 64, 64, 64 }, { "FLAT  ", 64, 27, 68, 76 } };

static s16 absS(s16 v) { return v < 0 ? -v : v; }
#define P(v) (v)                                                        // (positions are kept in 1/1024, with 1/16384 left over in fx, fy)
#define MOVE(o) do { (o).fx += (o).vx; (o).X += (o).fx >> 4; (o).fx &= 15; (o).fy += (o).vy; (o).Y += (o).fy >> 4; (o).fy &= 15; } while (0)
static void say(const char *t) { msg = t; msgT = 95; }
static void pinSfx(void) { if (!pinSfxT) { pinSfxT = 4; sfx(SFX_PIN); } }
static s8 rndS(u8 span) { return (s8)((s16)(rnd8() % (span * 2 + 1)) - span); }

static void rackPins(void) {
    for (u8 i = 0; i < 10; i++) {
        Pin *p = &pins[i];
        p->X = LAYOUT[i][0]; p->Y = HEAD_Y + LAYOUT[i][1] * ROW_D; p->fx = p->fy = 0;
        p->vx = p->vy = 0; p->rot = 64; p->vrot = 0; p->sink = 0; p->col = PIN_COL[i]; p->down = p->gone = 0;
    }
}
static u8 standing(void) { u8 n = 0; for (u8 i = 0; i < 10; i++) if (!pins[i].gone && !pins[i].down) n++; return n; }
// a WASHOUT: after the first ball the head pin's up and the pins left are in separate groups
static const u16 PIN_ADJ[10] = { 0x006, 0x01D, 0x033, 0x0D2, 0x1AE, 0x314, 0x088, 0x158, 0x2B0, 0x120 };
static u8 isWashout(void) {
    if (rollNo != 0 || pins[0].gone || pins[0].down) return 0;
    u16 up = 0; u8 n = 0;
    for (u8 i = 0; i < 10; i++) if (!pins[i].gone && !pins[i].down) { up |= 1 << i; n++; }
    if (n < 2) return 0;
    u16 seen = 1, grow = 1;
    while (grow) { u16 nxt = 0; for (u8 i = 0; i < 10; i++) if (grow & (1 << i)) nxt |= PIN_ADJ[i] & up & ~seen; seen |= nxt; grow = nxt; }
    return seen != up;
}
static s16 scoreTotal(void) {
    s16 s = 0; u8 i = 0;
    for (u8 f = 0; f < 10 && i < nRolls; f++) {
        u8 a = rolls[i], b = i + 1 < nRolls ? rolls[i + 1] : 0, c = i + 2 < nRolls ? rolls[i + 2] : 0;
        if (a == 10) { s += 10 + b + c; i += 1; }
        else if (a + b == 10 && i + 1 < nRolls) { s += 10 + c; i += 2; }
        else { s += a + b; i += 2; }
    }
    return s;
}
static s16 finalScore(void) { return scoreTotal() + (megaWon ? 33 : 0); }
static void setChair(void) {
    haveChair = frameNo == 9 && rollNo == 2 && standing() == 10 && !megaWon;
    if (haveChair) { chr.X = 0; chr.Y = CHAIR_Y; chr.fx = chr.fy = 0; chr.vx = chr.vy = 0; chr.shoved = 0; }
}
static void rackFresh(void) { rackPins(); standStart = 10; setChair(); }
static void sweepAndStand(void) { for (u8 i = 0; i < 10; i++) if (pins[i].down) pins[i].gone = 1; standStart = standing(); }
static void readyNext(void) { haveBall = 0; phase = PH_AIM; panelDirty = 1; }

// ── the scoresheet ───────────────────────────────────────────────────────
static char mk(u8 v) { return v == 0 ? '-' : '0' + v; }
// frame f's marks ("X", "7/", "81", "XX7") and its running total (-1 = not yet)
static s16 frameView(u8 f, char *m) {
    u8 i = 0; s16 run = 0; m[0] = 0;
    for (u8 k = 0; k <= f; k++) {
        if (i >= nRolls) return -1;
        u8 a = rolls[i], hb = i + 1 < nRolls, hc = i + 2 < nRolls, b = hb ? rolls[i + 1] : 0, c = hc ? rolls[i + 2] : 0;
        s16 tot = -1; char t[4] = { 0, 0, 0, 0 };
        if (k < 9) {
            if (a == 10) { t[0] = 'X'; if (hb && hc) { run += 10 + b + c; tot = run; } i += 1; }
            else if (hb && a + b == 10) { t[0] = mk(a); t[1] = '/'; if (hc) { run += 10 + c; tot = run; } i += 2; }
            else if (hb) { t[0] = mk(a); t[1] = mk(b); run += a + b; tot = run; i += 2; }
            else { t[0] = mk(a); i += 1; }
        } else {
            t[0] = a == 10 ? 'X' : mk(a);
            if (hb) t[1] = b == 10 ? 'X' : (a != 10 && a + b == 10 ? '/' : mk(b));
            if (hc) t[2] = c == 10 ? 'X' : (b != 10 && a == 10 && b + c == 10 ? '/' : mk(c));
            u8 bonus = a == 10 || (hb && a + b == 10), done = bonus ? hc : hb;
            if (done) { run += a + b + c; tot = run; }
        }
        if (k == f) { strcpy(m, t); return tot; }
    }
    return -1;
}
static void panel(void) {
    char m[4];
    for (u8 f = 0; f < 10; f++) {
        fillWin(1, f, 7, 1, BLANK, PAL_TEXT);
        u8 cur = f == frameNo && phase != PH_OVER;
        s16 t = frameView(f, m);
        if (cur && !m[0]) wput(1, f, UI_CURSOR, PAL_GOLD); else wtxt(1, f, m, cur ? PAL_GOLD : PAL_TEXT);
        if (t >= 0) wnum(5, f, t, 3, PAL_TEXT);
    }
    fillWin(1, 11, 7, 3, BLANK, PAL_TEXT);
    wtxt(1, 11, "SCORE", PAL_GREY); wnum(4, 12, finalScore(), 4, PAL_GOLD);
    if (megaWon) wtxt(1, 13, "+33MEGA", PAL_RED);
    fillWin(1, 15, 7, 3, BLANK, PAL_TEXT);
    if (phase == PH_AIM) {
        wtxt(1, 15, ORI[orientIdx].label, PAL_BLUE);
        wtxt(1, 16, "UP/DN", PAL_GREY);
        wtxt(1, 17, rollNo ? "SPARE" : "HOLD A", rollNo ? PAL_GOLD : PAL_GREY);
    }
    panelDirty = 0;
}

// ── the game ──────────────────────────────────────────────────────────────
static void endGame(void) {
    phase = PH_OVER;
    s16 s = finalScore();
    newBest = s > sv.arcadeBest[ARC_BOWLING];
    if (newBest) sv.arcadeBest[ARC_BOWLING] = s;
    sv.arcadePlays[ARC_BOWLING]++;
    s16 c = s / 20; if (c > 20) c = 20;
    coinsWon = c; if (c > 0) addCoins(c);
    saveWrite();
    char l1[16], l2[20], l3[20];
    strcpy(l1, lbl("FINAL ", s));
    strcpy(l2, newBest ? "NEW BEST!" : lbl("BEST ", sv.arcadeBest[ARC_BOWLING]));
    strcpy(l3, "+"); itoa10(coinsWon, l3 + 1); strcat(l3, " COINS");
    sfx(newBest ? SFX_GOOD : SFX_COIN);
    overDraw(megaWon ? "MEGA QU33PH!" : "GAME OVER", l1, l2, l3);
}
static void endRoll(u8 fromMega) {
    if (phase == PH_MEGA && !fromMega) return;
    u8 felled = standStart - standing(), cleared = standing() == 0;
    if (nRolls < 24) rolls[nRolls++] = felled;
    u8 strike = felled == 10;
    if (!fromMega) {
        if (rollNo == 0 && strike) { say("QU33PH!"); sfx(SFX_GOOD); }
        else if (rollNo > 0 && cleared) { say("SPARE"); sfx(SFX_PLOP); }
        else if (felled == 0 && haveBall && ball.gutter) { say("PEEF"); sfx(SFX_PEEF); }
        else if (isWashout()) { say("WASHOUT"); sfx(SFX_BAD); }
    }
    if (frameNo < 9) {
        if (rollNo == 0 && !strike) { rollNo = 1; sweepAndStand(); setChair(); readyNext(); }
        else { frameNo++; rollNo = 0; rackFresh(); readyNext(); }
        return;
    }
    if (rollNo == 0) { rollNo = 1; if (strike) rackFresh(); else sweepAndStand(); setChair(); readyNext(); }
    else if (rollNo == 1) {
        u8 openedWithStrike = nRolls >= 2 && rolls[nRolls - 2] == 10;
        if (openedWithStrike || cleared) { rollNo = 2; rackFresh(); readyNext(); }
        else endGame();
    } else endGame();
}
static void throwBall(s8 dir) {                          // dir: -1 / 0 / 1 hook from holding left / right
    const Ori *o = &ORI[orientIdx];
    s16 pw = 90 + power;                                 // 0.35 .. 1.35 in 1/256
    ball.X = aimX; ball.Y = 0; ball.fx = ball.fy = 0;
    ball.vx = dir * VQ(0.204);
    ball.vy = (s16)(((s32)VQ(3.5) * pw * o->speed) >> 14);
    ball.spin = (s16)(((s32)(dir * 184 - 87) * o->hook) >> 6);           // (dx*1.5 - 0.085) * hook, in 1/1024
    ball.rot = o->rot; ball.carry = o->carry;
    ball.col = QUEUE[frameNo]; ball.live = 1; ball.gutter = 0; haveBall = 1;
    phase = PH_ROLL; settleT = 0;
    sfx(SFX_THROW);
}
// the marker is a capsule: is the circle (cx, cy, r) touching it? n = the push direction (1/256)
static s16 hnx, hny;
static u8 capsuleHit(s16 cx, s16 cy, s16 r) {
    s16 bx = P(ball.X), by = P(ball.Y);
    s16 lim = r + BALL_R + BALL_HL;
    if (absS(cx - bx) > lim || absS(cy - by) > lim) return 0;
    s16 ax = SINB(ball.rot), ay = COSB(ball.rot);
    s16 t = ((((cx - bx) >> 2) * ax) + (((cy - by) >> 2) * ay)) >> 5;
    if (t < -BALL_HL) t = -BALL_HL; if (t > BALL_HL) t = BALL_HL;
    s16 dx = cx - (bx + ((ax * t) >> 7)), dy = cy - (by + ((ay * t) >> 7));
    s16 rr = r + BALL_R;
    if (absS(dx) >= rr || absS(dy) >= rr) return 0;
    u16 d2 = (u16)(dx * dx) + (u16)(dy * dy);
    if (d2 >= (u16)(rr * rr) || d2 == 0) return 0;
    s16 d = (s16)isqrt32((u32)d2); if (!d) d = 1;
    hnx = (s16)(((s32)dx << 8) / d); hny = (s16)(((s32)dy << 8) / d);
    return 1;
}
static void knock(Pin *p, s16 nx, s16 ny, s16 f) {
    p->vx += (s16)(((s32)nx * f) >> 8); p->vy += (s16)(((s32)ny * f) >> 8);
    if (!p->down) { p->down = 1; p->rot = 64 + rndS(10); p->vrot = rndS(12); pinSfx(); }
}
static void step(void) {
    if (pinSfxT) pinSfxT--;
    if (msgT) msgT--;
    if (phase == PH_ROLL && haveBall && ball.live) {
        s16 grip = ball.vy <= 0 ? 0 : (s16)(((u16)(ball.vy >> 4) * 237) >> 6); if (grip > 256) grip = 256;          // vy / 2.2 (1/256)
        ball.vx += (((ball.spin * 35) >> 6) * grip) >> 12;
        ball.vy -= ball.vy >> 8;
        MOVE(ball);
        s16 hw = (s16)(((s32)absS(SINB(ball.rot)) * BALL_HL) >> 7) + BALL_R;
        if (absS(P(ball.X)) > U - hw) {                    // PEEF: in the gutter, the roll is dead
            ball.X = ball.X < 0 ? -(U - hw) : (U - hw);
            ball.vx = ball.vy = ball.spin = 0; ball.gutter = 1; ball.live = 0; settleT = 0;
        }
        if (haveChair && !chr.shoved && capsuleHit(P(chr.X), P(chr.Y), CHAIR_R)) {
            if (rnd8() < 108) {                               // 42%: MEGA, the marker flies to the card
                flyX0 = P(ball.X); flyY0 = P(ball.Y); flyT = 0; flying = 1; ball.live = 0; phase = PH_MEGA;
                chr.shoved = 1; chr.vy = VQ(0.7); sfx(SFX_PLOP);
            } else {
                chr.shoved = 1; s16 v = ball.vy - (ball.vy >> 4); chr.vy = v > VQ(2.2) ? v : VQ(2.2); chr.vx = (s16)(((s32)ball.vx * 179) >> 8);
                ball.vy = (s16)(((s32)ball.vy * 141) >> 8); pinSfx();
            }
        }
        for (u8 i = 0; i < 10; i++) { Pin *p = &pins[i]; if (p->gone) continue;
            if (capsuleHit(P(p->X), P(p->Y), PIN_R)) {
                s16 hit = (s16)(((s32)(ball.vy - (ball.vy >> 2) + (ball.vy >> 4) + (absS(ball.vx) >> 1)) * ball.carry) >> 6);
                if (hit < VQ(1.15)) hit = VQ(1.15);
                p->vx += (s16)(((s32)hnx * hit) >> 8); p->vy += (s16)(((s32)hny * hit) >> 8);
                p->down = 1; p->rot = 64 + rndS(10); p->vrot = rndS(12) - (hnx > 0 ? 4 : -4);
                ball.vx -= (s16)(((s32)hnx * hit * 23) >> 16);
                ball.vy = ball.vy - VQ(0.16) > VQ(0.55) ? ball.vy - VQ(0.16) : VQ(0.55);
                pinSfx();
            }
        }
        if (P(ball.Y) > LANE_LEN + 614 || ball.vy < VQ(0.22)) { ball.live = 0; settleT = 0; }
    }
    if (haveChair && chr.shoved && phase != PH_MEGA) {
        MOVE(chr);
        chr.vy -= (chr.vy >> 5) + (chr.vy >> 6); chr.vx -= (chr.vx >> 5) + (chr.vx >> 6);
        for (u8 i = 0; i < 10; i++) { Pin *p = &pins[i]; if (p->gone || p->down) continue;
            s16 dx = P(p->X) - P(chr.X), dy = P(p->Y) - P(chr.Y);
            if (absS(dx) < CHAIR_R + PIN_R && absS(dy) < CHAIR_R + PIN_R) {
                s32 d2 = (s32)dx * dx + (s32)dy * dy;
                if (d2 < (s32)(CHAIR_R + PIN_R) * (CHAIR_R + PIN_R)) {
                    if (!dx) dx = 10;
                    if (!dy) dy = 10;
                    s16 d = (s16)isqrt32((u32)((s32)dx * dx + (s32)dy * dy));
                    s16 f = chr.vy - (chr.vy >> 2) + (chr.vy >> 4); if (f < VQ(1.2)) f = VQ(1.2);
                    knock(p, (s16)(((s32)dx << 8) / d), (s16)(((s32)dy << 8) / d), f);
                }
            } }
        if (P(chr.Y) > LANE_LEN + 1229) haveChair = 0;
    }
    if (phase == PH_MEGA && flying) {
        if (++flyT >= 35) { megaWon = 1; say("MEGA QU33PH"); sfx(SFX_GOOD); flying = 0; haveBall = 0; panelDirty = 1; endRoll(1); }
    }
    for (u8 i = 0; i < 10; i++) { Pin *p = &pins[i]; if (p->gone) continue;
        if (p->vx || p->vy) {
            MOVE(*p);
            p->vx -= (p->vx >> 4) - (p->vx >> 7); p->vy -= (p->vy >> 4) - (p->vy >> 7);
            if (absS(p->vx) < 4) p->vx = 0;
            if (absS(p->vy) < 4) p->vy = 0;
            p->rot += p->vrot >> 1; p->vrot -= p->vrot >> 4;
            if (p->down && p->sink < 255) { p->sink = p->sink > 237 ? 255 : p->sink + 18; }
            s16 px = P(p->X), py = P(p->Y);
            s16 sp = absS(p->vx) + absS(p->vy); sp -= sp >> 2;                  // ~|v| * 0.92
            for (u8 j = 0; j < 10; j++) { Pin *q = &pins[j]; if (q == p || q->gone) continue;
                s16 ddx = P(q->X) - px, ddy = P(q->Y) - py;
                if (absS(ddx) >= PIN_R * 2 || absS(ddy) >= PIN_R * 2) continue;
                s32 d2 = (s32)ddx * ddx + (s32)ddy * ddy;
                if (d2 < (s32)PIN_R * PIN_R * 4 && d2 > 0) {
                    s16 d = (s16)isqrt32((u32)d2); if (!d) d = 1;
                    s16 nx = (s16)(((s32)ddx << 8) / d), ny = (s16)(((s32)ddy << 8) / d), push = (PIN_R * 2 - d) >> 1;
                    s16 ox = ((nx >> 1) * push) >> 7, oy = ((ny >> 1) * push) >> 7;
                    q->X += ox; p->X -= ox; q->Y += oy; p->Y -= oy;
                    if (sp > VQ(0.10)) knock(q, nx, ny, sp);
                } }
            if (absS(P(p->X)) > 1280 || P(p->Y) > LANE_LEN + 1126) p->gone = 1;
        } }
    if (phase == PH_ROLL && haveBall && !ball.live) {
        settleT++;
        u8 moving = 0;
        for (u8 i = 0; i < 10; i++) if (!pins[i].gone && absS(pins[i].vx) + absS(pins[i].vy) > VQ(0.16)) moving = 1;
        if (!moving || settleT > 30) endRoll(0);
    }
}

// ── drawing: the lane from above, x 8..88 across, y 140 (the foul line) .. 14 (the far end) ──
static s16 lx(s16 X) { return 48 + (X >> 5) + (X >> 7) + (X >> 9); }        // X * 40 / 1024 (≈)
static s16 ly(s16 Y) { return 140 - (((Y >> 3) * 9) >> 6); }                // Y * 18 / 1024
static void drawSprites(void) {
    for (u8 i = 0; i < 10; i++) { Pin *p = &pins[i]; if (p->gone) continue;
        if (p->down && p->sink >= 200) continue;                               // fallen into the pit
        miniMarker(lx(P(p->X)), ly(P(p->Y)), MK_KIND[p->col], p->down ? p->rot : 64);
    }
    if (haveChair) spr16(lx(P(chr.X)), ly(P(chr.Y)), ST_CHAIR, isCGB ? OP_RED : 0);
    if (haveBall && phase != PH_MEGA && P(ball.Y) < LANE_LEN + 400) marker(lx(P(ball.X)), ly(P(ball.Y)), MK_COL[ball.col], (u8)(ball.rot - 64));
    if (flying) {                                                               // up to the MEGA card
        s16 tx = megaRight ? 72 : 24, ty = 4, x0 = lx(flyX0), y0 = ly(flyY0);
        s16 k = (s16)(((u16)flyT << 8) / 35);
        miniMarker(x0 + (s16)(((s32)(tx - x0) * k) >> 8), y0 + (s16)(((s32)(ty - y0) * k) >> 8) - ((SINB((u8)(k >> 1)) * 20) >> 7), 3, (u8)(flyT * 20));
    }
    if (phase == PH_AIM) {
        s16 x = lx(aimX), y = 128;
        marker(x, y, MK_COL[QUEUE[frameNo]], (u8)(ORI[orientIdx].rot - 64));
        if (charging) powerMarker(x, y - 10, 192, 10 + (power >> 3), power);
    }
    if (msgT) sprText(48 - (s16)strlen(msg) * 4, 64, msg, isCGB ? OP_WHITE : 0);
}
static void megaCard(void) {
    u8 armed = frameNo == 9 && !megaWon;
    fillBkg(1, 0, 10, 1, SCENE_T + 3, PAL_S1);
    txt(megaRight ? 7 : 1, 0, "MEGA", megaWon ? PAL_RED : armed ? PAL_GOLD : PAL_GREY);
}
static void laneScreen(void) {
    screenFresh();
    loadBkgTiles(SCENE_T, 7, bowl_bg);
    static const u16 WOOD[4] = { RGB8(235, 205, 150), RGB8(200, 160, 105), RGB8(120, 120, 130), RGB8(40, 35, 35) };
    setBkgPal(PAL_S1, WOOD);
    fillBkg(0, 0, 12, 18, SCENE_T + 3, PAL_S1);                                 // the pit and walls
    fillBkg(1, 2, 10, 16, SCENE_T, PAL_S1);                                     // the lane
    fillBkg(0, 2, 1, 16, SCENE_T + 1, PAL_S1); fillBkg(11, 2, 1, 16, SCENE_T + 2, PAL_S1);
    put(3, 13, SCENE_T + 4, PAL_S1); put(5, 12, SCENE_T + 4, PAL_S1); put(6, 12, SCENE_T + 4, PAL_S1); put(8, 13, SCENE_T + 4, PAL_S1);   // the arrows
    fillBkg(1, 17, 10, 1, SCENE_T + 5, PAL_S1);                                 // the foul line
    megaCard();
    txt(1, 1, lbl("HI ", sv.arcadeBest[ARC_BOWLING]), PAL_GREY);
    fillWin(0, 0, 8, 18, BLANK, PAL_TEXT);
    for (u8 y = 0; y < 18; y++) wput(0, y, UI_L, PAL_GREY);
    panel(); winAt(7 + 96, 0);
    lcdOn();
}
static void newGame(void) {
    frameNo = rollNo = nRolls = 0; aimX = 0; megaRight = rnd8() & 1; megaWon = 0; flying = 0; haveChair = 0;
    rackPins(); haveBall = 0; phase = PH_AIM; msgT = 0; standStart = 10; charging = 0;
    laneScreen();
}

static const char * const RULES[9] = { "TEN FRAMES. MARKERS", "ARE THE PINS.", "LEFT/RIGHT: SPOT IT", "HOLD A, LET GO TO",
    "ROLL. HOLD L/R AS", "YOU LET GO TO HOOK.", "UP/DN: VERT HOOKS,", "FLAT CARRIES MOST.", "10TH: HIT THE CHAIR" };
static const char * const MENU_ITEMS[2] = { "BOWL", "BACK" };
void bowlEnter(void) BANKED { }
void bowlUpdate(void) BANKED {
    if (entering) {
        phase = ST_MENU; sel = 0;
        screenFresh(); txtC(0, "BOWLING", PAL_GOLD);
        for (u8 i = 0; i < 9; i++) txt(0, 2 + i, RULES[i], i == 8 ? PAL_GOLD : PAL_TEXT);
        txt(0, 11, "FOR MEGA QU33PH +33", PAL_GOLD);
        txtC(17, lbl("BEST ", sv.arcadeBest[ARC_BOWLING]), PAL_GREY);
        lcdOn();
    }
    music(MUS_BOWL);
    if (phase == ST_MENU) {
        s8 h = menuList(6, 13, 2, MENU_ITEMS, &sel, 2);
        if (h == 0) newGame(); else if (h == 1 || h == -2) goScreen(S_ARCADE);
        return;
    }
    if (phase == PH_OVER) { s8 h = overInput(); if (h == 0) newGame(); else if (h == 1) goScreen(S_ARCADE); return; }
    u8 p = pauseCheck(); if (p == 1) { charging = 0; return; }
    if (p == 2) { panel(); winAt(7 + 96, 0); }
    if (phase == PH_AIM) {
        if (kDown & J_UP) { orientIdx = (orientIdx + 1) % 3; panelDirty = 1; }
        if (kDown & J_DOWN) { orientIdx = (orientIdx + 2) % 3; panelDirty = 1; }
        if (!charging) {
            if (kHeld & J_LEFT) { aimX -= 20; if (aimX < -737) aimX = -737; }
            if (kHeld & J_RIGHT) { aimX += 20; if (aimX > 737) aimX = 737; }
        }
        if (kDown & J_A) { charging = 1; ph = 0; power = 0; }
        if (charging) {
            ph++; u8 t = ph % 44; power = t < 22 ? t * 11 + 14 : (44 - t) * 11 + 14;
            if (kDown & J_B) charging = 0;
            else if (kUp & J_A) { charging = 0; throwBall((kHeld & J_LEFT) ? -1 : (kHeld & J_RIGHT) ? 1 : 0); panelDirty = 1; }
        }
    } else charging = 0;
    u8 f0 = frameNo, n0 = nRolls;
    step();
    if (phase == PH_OVER) return;
    if (f0 != frameNo) megaCard();
    if (panelDirty || n0 != nRolls) panel();
    drawSprites();
}
