// stack.c — QU33PH STACK (the website's stack.html), bare bones: build the tower.
// The Game Boy can't run the website's rigid-body physics, so the tower is built on a grid of
// tiles: the marker swings over the tower, A drops it, UP turns it upright / flat. Each marker
// that lands is checked with simple statics: the weight of everything resting on it (passed
// down through what it touches) must sit over what's holding it up, or the tower goes TIMBER!
// Land beside the plate and it's TIMBER too.
#pragma bank 255
#include "qu.h"
#include "res_stack.inc"

#define COLS 13
#define PLATE_Y 249                    // world tile rows (down the screen); the plate's row
#define FLOOR 250
#define PLATE_X0 4
#define PLATE_X1 9                     // (columns 4..8)
#define MAXB 120
#define ID_PLATE 254
#define ID_NONE 255
#define MASS 8
typedef struct { u8 x0, w, yb, h, col, nsup; u8 sid[4]; } Blk;
static Blk bl[MAXB]; static u8 nb;
static u8 colTop[COLS], colId[COLS];
static u16 ldM[MAXB], ldMom[MAXB];
enum { ST_MENU, ST_HOLD, ST_FALL, ST_TIMBER, ST_OVER };
static u8 st, sel, flat, hx, hdir, swingT, curCol, timberT, newBest, fellOff;
static u16 camY, camTopRow; static s16 fallY, fallV; static u8 heldRow;
static s16 coinsWon;

static u8 topRow(void) { u8 t = PLATE_Y; for (u8 c = 0; c < COLS; c++) if (colTop[c] < t) t = colTop[c]; return t; }
static u8 bw(void) { return flat ? 4 : 1; }
static u8 bh(void) { return flat ? 1 : 4; }
// a block's tiles into the background (rows wrap round the 32-row map)
static void drawBlock(const Blk *b) {
    u8 t = SCENE_T + b->col * 8 + (b->w > 1 ? 4 : 0);
    if (b->w > 1) { u8 r[4] = { t, t + 1, t + 2, t + 3 }; for (u8 i = 0; i < 4; i++) put(b->x0 + i, b->yb & 31, r[i], PAL_S1); }
    else for (u8 i = 0; i < 4; i++) put(b->x0, (u8)(b->yb - 3 + i) & 31, t + i, PAL_S1);
}
static void drawRow(u16 y) {                           // a world row from scratch (sky, the plate, the floor)
    u8 r = (u8)y & 31;
    if (y >= FLOOR) { fillBkg(0, r, COLS, 1, UI_SOLID2, PAL_GREY); return; }
    fillBkg(0, r, COLS, 1, BLANK, PAL_S1);
    if (y == PLATE_Y) fillBkg(PLATE_X0, r, PLATE_X1 - PLATE_X0, 1, UI_SOLID1, PAL_GREY);
    for (u8 i = 0; i < nb; i++) { Blk *b = &bl[i]; if (y <= b->yb && y + b->h > b->yb) drawBlock(b); }
}
// the statics: from the newest marker down, each one's weight (its own plus what's on it) must
// lie over the columns it touches; then it's handed on to the markers under it.
static u8 contact(const Blk *b, u8 id, u8 *lo, u8 *hi) {   // the columns b shares with what's under it
    u8 a0, a1;
    if (id == ID_PLATE) { a0 = PLATE_X0; a1 = PLATE_X1; } else { a0 = bl[id].x0; a1 = bl[id].x0 + bl[id].w; }
    *lo = b->x0 > a0 ? b->x0 : a0; *hi = (b->x0 + b->w < a1 ? b->x0 + b->w : a1);    // [lo, hi)
    return *hi > *lo;
}
static void give(u8 id, u16 m, u16 at2) { if (id < MAXB) { ldM[id] += m; ldMom[id] += m * at2; } }
static u8 stable(void) {
    memset(ldM, 0, sizeof ldM); memset(ldMom, 0, sizeof ldMom);
    for (s16 i = nb - 1; i >= 0; i--) {
        Blk *b = &bl[i];
        u16 M = MASS + ldM[i], mom = MASS * (b->x0 * 2 + b->w) + ldMom[i];
        // the outermost contacts, in half columns
        u8 L = 255, R = 0, li = 0, ri = 0, llo = 0, lhi = 0, rlo = 0, rhi = 0;
        for (u8 k = 0; k < b->nsup; k++) { u8 lo, hi; if (!contact(b, b->sid[k], &lo, &hi)) continue;
            if (lo < L) { L = lo; li = b->sid[k]; llo = lo * 2; lhi = hi * 2; }
            if (hi > R) { R = hi; ri = b->sid[k]; rlo = lo * 2; rhi = hi * 2; } }
        if (L == 255) return 0;
        if (mom < M * (u16)(L * 2) || mom > M * (u16)(R * 2)) return 0;        // tips over
        u16 c = mom / M;
        u16 p1 = (llo + lhi) >> 1, p2 = (rlo + rhi) >> 1;
        if (li == ri || c <= p1) give(li, M, c < llo ? llo : c > lhi ? lhi : c);
        else if (c >= p2) give(ri, M, c < rlo ? rlo : c > rhi ? rhi : c);
        else { u16 f2 = (u16)(((u32)M * (c - p1)) / (p2 - p1)); give(ri, f2, p2); give(li, M - f2, p1); }
    }
    return 1;
}
static void panel(void) {
    fillWin(1, 0, 6, 18, BLANK, PAL_TEXT);
    wnum(1, 1, nb, 3, PAL_GOLD); wtxt(1, 2, "HIGH", PAL_GREY);
    wtxt(1, 4, "BEST", PAL_GREY); wnum(1, 5, sv.arcadeBest[ARC_STACK], 3, PAL_GREEN);
    wtxt(1, 12, "A DROP", PAL_GREY); wtxt(1, 13, "UP", PAL_GREY); wtxt(1, 14, "TURN", PAL_GREY);
}
static void timber(u8 off) {
    st = ST_TIMBER; timberT = 70; fellOff = off; sfx(SFX_BAD);
    newBest = nb > sv.arcadeBest[ARC_STACK];
    if (newBest) sv.arcadeBest[ARC_STACK] = nb;
    sv.arcadePlays[ARC_STACK]++;
    s16 c = nb / 2; if (c > 20) c = 20;
    coinsWon = c; if (c > 0) addCoins(c);
    saveWrite();
}
static void land(void) {
    u8 w = bw(), h = bh(), m = FLOOR;
    for (u8 c = hx; c < hx + w; c++) if (colTop[c] < m) m = colTop[c];
    if (m >= FLOOR || nb >= MAXB) { timber(1); return; }              // nothing under it: off the edge
    Blk *b = &bl[nb];
    b->x0 = hx; b->w = w; b->h = h; b->yb = m - 1; b->col = curCol; b->nsup = 0;
    for (u8 c = hx; c < hx + w; c++) if (colTop[c] == m) {
        u8 id = colId[c], k; for (k = 0; k < b->nsup; k++) if (b->sid[k] == id) break;
        if (k == b->nsup && b->nsup < 4) b->sid[b->nsup++] = id;
    }
    for (u8 c = hx; c < hx + w; c++) { colTop[c] = b->yb - h + 1; colId[c] = nb; }
    nb++;
    drawBlock(b);
    if (!stable()) { timber(0); return; }
    sfx(SFX_PLOP);
    curCol = nb % 3; st = ST_HOLD; panel();
}
static u8 heldRowNow(void) { return topRow() - 7; }
static void start(void) {
    screenFresh();
    loadBkgTiles(SCENE_T, 24, stack_bg); loadSprTiles(ST_GAME, 8, stack_spr);
    static const u16 SKY[4] = { RGB8(20, 24, 44), RGB8(230, 60, 60), RGB8(60, 200, 80), RGB8(80, 130, 255) };
    setBkgPal(PAL_S1, SKY);
    nb = 0; for (u8 c = 0; c < COLS; c++) { colTop[c] = (c >= PLATE_X0 && c < PLATE_X1) ? PLATE_Y : FLOOR; colId[c] = (c >= PLATE_X0 && c < PLATE_X1) ? ID_PLATE : ID_NONE; }
    camY = (PLATE_Y - 15) * 8; camTopRow = camY >> 3;
    for (u16 y = camTopRow; y < camTopRow + 32; y++) drawRow(y);
    fillWin(0, 0, 7, 18, BLANK, PAL_TEXT); for (u8 y = 0; y < 18; y++) wput(0, y, UI_L, PAL_GREY);
    panel(); winAt(7 + 104, 0);
    flat = 0; hx = 6; hdir = 1; swingT = 0; curCol = 0; st = ST_HOLD;
    scroll(0, (u8)camY);
    lcdOn();
}
static void heldSprites(s16 x, s16 y) {                 // the marker you hold / dropped, screen pixels (top-left)
    u8 pal = isCGB ? (curCol == 0 ? OP_RED : curCol == 1 ? OP_GREEN : OP_BLUE) : (curCol == 1 ? 0x10 : 0);
    for (u8 i = 0; i < 4; i++) { if (flat) spr(x + i * 8, y, ST_GAME + 4 + i, pal); else spr(x, y + i * 8, ST_GAME + i, pal); }
}
static void camera(void) {
    u16 target = (u16)(topRow() - 11) * 8; if (target > (PLATE_Y - 15) * 8) target = (PLATE_Y - 15) * 8;
    if (camY > target) camY -= camY - target > 16 ? 2 : 1;
    while ((camY >> 3) < camTopRow) { camTopRow--; drawRow(camTopRow); }   // a new row of sky comes in at the top
}

void stackEnter(void) BANKED { }
static const char * const MENU_ITEMS[2] = { "START", "BACK" };
void stackUpdate(void) BANKED {
    if (entering) {
        st = ST_MENU; sel = 0;
        screenFresh(); txtC(0, "QU33PH STACK", PAL_GOLD);
        static const char * const L[7] = { "BUILD THE TOWER: THE", "MARKER SWINGS OVER", "IT, A DROPS IT, UP", "TURNS IT. IT HAS TO", "BALANCE ON WHAT'S", "UNDER IT, OR IT'S", "TIMBER!" };
        for (u8 i = 0; i < 7; i++) txt(0, 2 + i, L[i], i == 6 ? PAL_GOLD : PAL_TEXT);
        txtC(16, lbl("BEST ", sv.arcadeBest[ARC_STACK]), PAL_GREEN);
        lcdOn();
    }
    music(MUS_STACK);
    if (st == ST_MENU) {
        s8 h = menuList(6, 11, 2, MENU_ITEMS, &sel, 2);
        if (h == 0) start(); else if (h == 1 || h == -2) goScreen(S_ARCADE);
        return;
    }
    if (st == ST_OVER) { s8 h = overInput(); if (h == 0) start(); else if (h == 1) goScreen(S_ARCADE); return; }
    u8 p = pauseCheck(); if (p == 1) return;
    if (p == 2) { winAt(7 + 104, 0); }
    if (st == ST_HOLD) {
        u8 period = nb < 27 ? 14 - nb / 3 : 5;
        if (kDown & J_UP) {                                         // turn it (kept on the field)
            flat = !flat; if (hx + bw() > COLS) hx = COLS - bw(); sfx(SFX_MOVE);
        }
#ifdef STACKTEST
        if (kDown & J_LEFT && hx) hx--;
        if (kDown & J_RIGHT && hx + bw() < COLS) hx++;
        period = 255;
#endif
        if (++swingT >= period) {
            swingT = 0;
            if (hdir) { if (hx + bw() >= COLS) hdir = 0; else hx++; }
            else { if (hx == 0) hdir = 1; else hx--; }
        }
        heldRow = heldRowNow();
        if (kDown & J_A) { st = ST_FALL; fallY = (s16)heldRow * 8 - (flat ? 0 : 24); fallV = 0; sfx(SFX_THROW); }
    }
    if (st == ST_FALL) {
        // fall to the top of whatever's under it
        u8 m = FLOOR; for (u8 c = hx; c < hx + bw(); c++) if (colTop[c] < m) m = colTop[c];
        s16 restY = (s16)(m - bh()) * 8;
        fallV += 1; if (fallV > 12) fallV = 12; fallY += fallV;
        if (m < FLOOR && fallY >= restY) land();
        else if (m >= FLOOR && fallY > (s16)camY + 150) timber(1);
    }
    if (st == ST_TIMBER) {
        scroll((timberT & 2) ? 1 : 0, (u8)camY);
        sprText(12, 40, "TIMBER!", isCGB ? OP_WHITE : 0);
        if (fellOff && fallY < (s16)camY + 160) { fallV += 1; fallY += fallV; heldSprites(hx * 8, fallY - (s16)camY); }
        if (--timberT == 0) {
            char l1[20], l2[20], l3[20];
            strcpy(l1, lbl("", nb)); strcat(l1, " MARKERS HIGH");
            strcpy(l2, newBest ? "NEW BEST!" : lbl("BEST ", sv.arcadeBest[ARC_STACK]));
            strcpy(l3, "+"); itoa10(coinsWon, l3 + 1); strcat(l3, " COINS");
            st = ST_OVER; overDraw("TIMBER!", l1, l2, l3);
        }
        return;
    }
    camera();
    scroll(0, (u8)camY);
    if (st == ST_HOLD) heldSprites(hx * 8, (s16)heldRow * 8 - (flat ? 0 : 24) - (s16)camY);
    else if (st == ST_FALL) heldSprites(hx * 8, fallY - (s16)camY);
}
