// arcade.c — the arcade: pick one of the nine games
#pragma bank 255
#include "qu.h"

static const char * const ARC_NAME[9] = { "MINI QU33PH", "QU33PH-BALL", "FIDGET", "BOWLING", "STACK", "FLIP", "DOZER", "JUMP", "PINBALL" };
static const char * const ARC_BLURB[9] = { "4 MINI MARKERS", "3 MACHINES, 9 ROLLS", "SPINNER AIR HOCKEY", "10 FRAMES, MARKER PINS",
    "BUILD THE TOWER", "FLICK PAD TO PAD", "COIN PUSHER", "CLIMB RUN BOUNCE FLAP", "THE BALL IS A MARKER" };
static const u8 ARC_SCREEN[9] = { S_MINI, S_BALL, S_FIDGET, S_BOWL, S_STACK, S_FLIP, S_DOZER, S_JUMP, S_PIN };
static u8 sel;
static void info(void) {
    fillBkg(0, 15, 20, 3, BLANK, PAL_TEXT);
    txtC(15, ARC_BLURB[sel], PAL_GREY);
    if (sv.arcadePlays[sel]) { strcpy(sbuf, "BEST "); itoa10(sv.arcadeBest[sel], sbuf + 5); txtC(16, sbuf, PAL_GOLD); }
}
void arcadeEnter(void) BANKED { }
void arcadeUpdate(void) BANKED {
    if (entering) {
        screenFresh();
        txt(1, 0, "ARCADE", PAL_GOLD);
        put(13, 0, UI_COIN, PAL_GOLD); txt(15, 0, lbl("", sv.coins), PAL_GOLD);
        lcdOn();
    }
    music(MUS_ARCADE);
    u8 old = sel;
    if (kDown & J_B) { goScreen(S_TITLE); return; }
    s8 h = menuList(3, 2, 9, ARC_NAME, &sel, 1);
    if (entering || old != sel) info();
    if (h >= 0) goScreen(ARC_SCREEN[(u8)h]);
}
