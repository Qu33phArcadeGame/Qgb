// ════════════════════════════════════════════════════════════════════════
//  QU33PH for the Game Boy and Game Boy Color — the original marker throwing game,
//  2 players, the Olympics, the slot, PlinQu33ph and the whole arcade.
//
//  CONTROLS: D-pad + A on the menus, B = back. In a match: left/right aims, hold A and let
//  go to throw (B cancels), SELECT turns how the marker lands, UP (held) looks up the table,
//  START pauses. Progress saves to the cartridge's battery-backed memory.
// ════════════════════════════════════════════════════════════════════════
#include "qu.h"

u32 loops;                                 // (main loop passes: the test runner compares them with screen refreshes)
u8 screen = S_TITLE, prevScreen = 255, entering = 1, gmode = M_SINGLE;

void goScreen(u8 s) { prevScreen = screen; screen = s; entering = 1; saveWrite(); }

// ── toast: a two-line note across the bottom (NEW HIGH SCORE!) ────────────
static u8 toastT; static char toastA[21], toastB[21];
void toast(const char *a, const char *b) {
    strncpy(toastA, a, 20); toastA[20] = 0; strncpy(toastB, b ? b : "", 20); toastB[20] = 0; toastT = 150;
    fillWin(0, 0, 20, 3, BLANK, PAL_GOLD);
    for (u8 x = 0; x < 20; x++) wput(x, 0, UI_T, PAL_GOLD);
    wtxt(0, 1, "                    ", PAL_GOLD);
    { u8 n = (u8)strlen(toastA); wtxt((20 - n) / 2, 1, toastA, PAL_GOLD); }
    { u8 n = (u8)strlen(toastB); if (n) wtxt((20 - n) / 2, 2, toastB, PAL_TEXT); }
    winAt(7, 120);
    sfx(SFX_GOOD);
}
void toastTick(void) {
    if (!toastT) return;
    if (--toastT == 0) winAt(255, 0);
}

void main(void) {
    engineInit();
    soundInit();
    saveInit();
    initrand(DIV_REG);
    while (1) {
        frameBegin(); loops++;
        u8 s = screen;
        if (kDown) initrand(randw() ^ DIV_REG);
        switch (screen) {
            case S_TITLE: case S_HANDOFF: case S_RESULTS: case S_HIGHS: case S_SETTINGS:
            case S_OLY_SELECT: case S_OLY_BRACKET: case S_NAME: menusUpdate(); break;
            case S_PLAY: case S_PAUSE: matchUpdate(); break;
            case S_SLOT: case S_PLINKO: casinoUpdate(); break;
            case S_ARCADE: arcadeUpdate(); break;
            case S_MINI: miniUpdate(); break;
            case S_BALL: ballUpdate(); break;
            case S_FIDGET: fidgetUpdate(); break;
            case S_BOWL: bowlUpdate(); break;
            case S_STACK: stackUpdate(); break;
            case S_FLIP: flipUpdate(); break;
            case S_DOZER: dozerUpdate(); break;
            case S_PIN: pinUpdate(); break;
            case S_JUMP: jumpUpdate(); break;
        }
        if (screen == s) entering = 0;
        toastTick();
        frameEnd();
    }
}
