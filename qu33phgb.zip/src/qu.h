// qu.h — shared by every Qu33ph Game Boy source file
//
// The Game Boy port of the GBA version: every mode and every arcade game, drawn bare bones in
// tiles. One ROM plays on the original Game Boy (in grey) and the Game Boy Color (in colour).
#ifndef QU_H
#define QU_H
#include <gbdk/platform.h>
#include <stdint.h>
#include <string.h>
#include <rand.h>

typedef uint8_t u8; typedef uint16_t u16; typedef uint32_t u32;
typedef int8_t s8; typedef int16_t s16; typedef int32_t s32;

// ── the screen ──────────────────────────────────────────────────────────
// Background tiles use the 0x8800 area (256 of them):
//   0-127   each screen's own pictures (SCENE_T), at 0x9000
//   128-191 the font (ASCII 32-95; lower case prints as capitals): BLANK is the space
//   192-223 the frames, bars and little pictures every screen uses (UI_*)
//   224-255 more of the screen's own pictures (SCENE_T2)
// The font and UI tiles sit where sprites can use them too (sprite tiles 128-223): popups and
// banners over a scrolling field are sprites made of letters.
// Sprite tiles 0-127 (0x8000) are the sprites' own: 0-63 the markers every screen uses, 64-127
// each game's own.
#define SCENE_T 0
#define SCENE_T2 224
#define FONT_T 128
#define BLANK 128
#define CH(c) ((u8)(FONT_T + (c) - 32))               // a letter's tile
enum {
    UI_SOLID1 = 192, UI_SOLID2, UI_SOLID3,               // filled light / dark / black
    UI_TL, UI_T, UI_TR, UI_L, UI_R, UI_BL, UI_B, UI_BR,  // a box's frame
    UI_COIN, UI_CURSOR, UI_DOT, UI_HALF2, UI_CHECK,
    UI_MK0, UI_MK1, UI_MK2,                              // little upright markers: green, red, blue
    UI_BAR0, UI_BAR1, UI_BAR2, UI_BAR3, UI_BAR4,          // a bar 0-4 quarters filled (from the left)
    UI_SPARK,                                            // a little star (touching markers)
    UI_N
};
// sprite tiles
#define ST_MARK 0          // the markers: 5 angles x 4 tiles (slim: green, red), then 5 x 4 (fat: blue)
#define ST_MARK_BLUE 20
#define ST_MINI 40         // 8x8 markers: 5 angles slim, 5 slim (2nd set), 5 fat (tiles 40-54)
#define ST_PWR 56          // the power marker: bead, lit bead, cap
#define ST_CHAIR 60        // the chair, 16x16 (TL, TR, BL, BR)
#define ST_GAME 64         // each game's own sprite tiles from here

// colour: on the Game Boy Color, background palettes 0-7 and sprite palettes 0-7
enum { PAL_TEXT, PAL_GOLD, PAL_RED, PAL_GREEN, PAL_BLUE, PAL_GREY, PAL_S1, PAL_S2 };   // background
enum { OP_GREEN, OP_RED, OP_BLUE, OP_GOLD, OP_WHITE, OP_S1, OP_S2, OP_S3 };          // sprites
extern u8 isCGB;

// ── buttons ───────────────────────────────────────────────────────────────
extern u8 kDown, kHeld, kUp;           // this frame's presses (J_A, J_B, J_SELECT, J_START, J_UP ...)

// ── engine (engine.c, in the always-there bank) ───────────────────────────
void engineInit(void);
void frameBegin(void);                 // wait for the screen's refresh, read the buttons, clear the sprite list
void frameEnd(void);                   // hide the sprites not used this frame
void lcdOff(void);
void lcdOn(void);
void clearBkg(u8 tile, u8 pal);        // the whole 32x32 map
void clearWin(u8 tile, u8 pal);
void fillBkg(u8 x, u8 y, u8 w, u8 h, u8 tile, u8 pal);
void fillWin(u8 x, u8 y, u8 w, u8 h, u8 tile, u8 pal);
void put(u8 x, u8 y, u8 tile, u8 pal); // one background tile
void wput(u8 x, u8 y, u8 tile, u8 pal);
void txt(u8 x, u8 y, const char *s, u8 pal);      // text on the background (tile x,y)
void txtC(u8 y, const char *s, u8 pal);           // centred on the 20-wide screen
void txtCW(u8 x0, u8 w, u8 y, const char *s, u8 pal);
void wtxt(u8 x, u8 y, const char *s, u8 pal);     // text on the window layer
void num(u8 x, u8 y, s32 v, u8 width, u8 pal);    // right-aligned in width tiles
void wnum(u8 x, u8 y, s32 v, u8 width, u8 pal);
char *itoa10(s32 v, char *buf);                   // returns buf
void box(u8 x, u8 y, u8 w, u8 h, u8 pal);         // a framed box, filled with spaces
void loadBkgTiles(u8 first, u8 n, const u8 *data);   // background tile data (0x8800 mode numbering)
void loadSprTiles(u8 first, u8 n, const u8 *data);
void loadBkgTilesBanked(u8 bank, u8 first, u8 n, const u8 *data) NONBANKED;
void loadSprTilesBanked(u8 bank, u8 first, u8 n, const u8 *data) NONBANKED;
void setBkgMap(u8 x, u8 y, u8 w, u8 h, const u8 *tiles, const u8 *attrs);   // attrs may be 0
void setBkgMapBanked(u8 bank, u8 x, u8 y, u8 w, u8 h, const u8 *tiles, const u8 *attrs) NONBANKED;
void setBkgPal(u8 n, const u16 *rgb4);            // Game Boy Color only (does nothing on the grey one)
void setSprPal(u8 n, const u16 *rgb4);
void uiPalettes(void);                            // the standard text / sprite colours
void scroll(u8 x, u8 y);
void winAt(u8 x, u8 y);                           // window's left edge at screen x (7 = whole screen); 255 hides it

// sprites: a list rebuilt every frame (40 at most)
extern u8 nSpr;
void spr(s16 x, s16 y, u8 tile, u8 attr);         // an 8x8 sprite, top-left at screen x,y
void sprText(s16 x, s16 y, const char *s, u8 attr);   // letters as sprites (popups over a moving field)
void spr16(s16 cx, s16 cy, u8 tile0, u8 attr);    // a 16x16 made of tiles tile0..tile0+3 (TL,TR,BL,BR), centred
void marker(s16 cx, s16 cy, u8 col, u8 ang);      // one of the three markers, centred, turned (0-255 = a full turn)
void miniMarker(s16 cx, s16 cy, u8 kind, u8 ang); // an 8x8 marker (kind 0 std/OBP0, 1 std/OBP1, 2 striped, 3 black)
void powerMarker(s16 x0, s16 y0, u8 ang, u8 len, u8 fill);   // the website's power marker from (x0,y0), len px, fill 0-255

// ── maths (no floating point on the Game Boy) ─────────────────────────────
extern const s8 SINT[256];             // sin * 127, 256 steps a turn
#define COSB(a) SINT[(u8)((a) + 64)]
#define SINB(a) SINT[(u8)(a)]
u8 atan2i(s16 y, s16 x);               // 0-255 = a full turn (0 = +x, 64 = +y)
u16 isqrt32(u32 v);
u16 rnd16(void);
u8 rnd8(void);
s16 rndr(s16 lo, s16 hi);              // lo..hi-1

// ── sound (sound.c) ───────────────────────────────────────────────────────
void soundInit(void);
void soundTick(void);                  // once a frame (from the vertical blank)
enum { SFX_THROW, SFX_PLOP, SFX_PEEF, SFX_HIT, SFX_COIN, SFX_SELECT, SFX_MOVE, SFX_WALL, SFX_PIN, SFX_JUMP, SFX_FLIP, SFX_BAD, SFX_GOOD, SFX_N };
void sfx(u8 which);
enum { MUS_MAIN, MUS_ARCADE, MUS_MINI, MUS_BALL, MUS_FIDGET, MUS_BOWL, MUS_STACK, MUS_FLIP, MUS_DOZER, MUS_PIN, MUS_JUMP, MUS_N };
void music(u8 track);                  // switch track (keeps playing if it's the same)
void musicStop(void);

// ── screens ───────────────────────────────────────────────────────────────
enum { S_TITLE, S_PLAY, S_PAUSE, S_HANDOFF, S_RESULTS, S_HIGHS, S_SETTINGS, S_OLY_SELECT, S_OLY_BRACKET, S_NAME,
       S_SLOT, S_PLINKO, S_ARCADE,
       S_MINI, S_BALL, S_FIDGET, S_BOWL, S_STACK, S_FLIP, S_DOZER, S_PIN, S_JUMP, S_COUNT };
extern u8 screen, prevScreen;
extern u8 entering;                    // 1 on a screen's first frame (it draws its background then)
void goScreen(u8 s);
enum { M_SINGLE = 1, M_TWO = 2, M_OLYMPICS = 3 };
extern u8 gmode;                       // 1 player, 2 player or the Olympics

// ── save data (save.c): the cartridge's battery-backed memory ─────────────
typedef struct { char name[9]; s16 score2; } HighEntry;     // scores are doubled (half points exist)
typedef struct {
    u16 magic, version;
    HighEntry high1p[10], highOly[10];
    u16 games, qu33phs, megas, peefs, forfeits;
    u16 gold, silver, bronze;
    u8 musicOn, sfxOn, twoRounds, timer1p, timer2p, orient;
    char name[9];
    s32 coins, coinsEarned, coinsSpent;
    u16 slotSpins, slotWins; s32 slotLost;
    s32 ballBest[3];
    u32 flipTiers[3];
    u16 flipDone, flipBest, flipBestP;
    s32 arcadeBest[9]; u16 arcadePlays[9];
    u16 jumpBest[4]; u8 jumpChar;
    u8 spare[32];
} SaveData;
enum { ARC_MINI, ARC_BALL, ARC_FIDGET, ARC_BOWLING, ARC_STACK, ARC_FLIP, ARC_DOZER, ARC_JUMP, ARC_PINBALL, ARC_COUNT };
extern SaveData sv;
void saveInit(void);
void saveWrite(void);
void resetHighScores(void);
void resetEverything(void);
void addCoins(s32 n);
void spendCoins(s32 n);
u8 highQualifies(HighEntry *list, s16 score2);
void highInsert(HighEntry *list, const char *name, s16 score2);
void scoreStr(char *o, s16 doubled);              // 7 -> "3.5"

// ── what every arcade game shares (engine.c) ──────────────────────────────
void screenFresh(void);                // a blank screen in the standard colours (LCD left off: call lcdOn)
u8 pauseCheck(void);                   // START pauses: 0 playing, 1 paused (skip the game), 2 just resumed
void overDraw(const char *title, const char *l1, const char *l2, const char *l3);
s8 overInput(void);                    // 0 play again, 1 back to the arcade, -1 nothing yet
extern char sbuf[32];
char *lbl(const char *a, s32 v);       // "a" + v, in sbuf

// ── the parts in their own banks ──────────────────────────────────────────
void menusEnter(void) BANKED;  void menusUpdate(void) BANKED;      // title, highs, settings, name, results, hand-off, Olympics
void matchEnter(void) BANKED;  void matchUpdate(void) BANKED;      // the Qu33ph match (S_PLAY, S_PAUSE)
void startMatch(void) BANKED;
void casinoEnter(void) BANKED; void casinoUpdate(void) BANKED;     // slot, PlinQu33ph
void arcadeEnter(void) BANKED; void arcadeUpdate(void) BANKED;     // the arcade menu
void miniEnter(void) BANKED;   void miniUpdate(void) BANKED;
void ballEnter(void) BANKED;   void ballUpdate(void) BANKED;
void fidgetEnter(void) BANKED; void fidgetUpdate(void) BANKED;
void bowlEnter(void) BANKED;   void bowlUpdate(void) BANKED;
void stackEnter(void) BANKED;  void stackUpdate(void) BANKED;
void flipEnter(void) BANKED;   void flipUpdate(void) BANKED;
void dozerEnter(void) BANKED;  void dozerUpdate(void) BANKED;
void pinEnter(void) BANKED;    void pinUpdate(void) BANKED;
void jumpEnter(void) BANKED;   void jumpUpdate(void) BANKED;

// the match's results go back to the menus
extern s16 score2[2];
extern u8 player, p2Round, matchOver, orient;
void matchFinished(void) BANKED;
// a little "NEW HIGH SCORE" note over any screen
void toast(const char *a, const char *b);
void toastTick(void);
void nameEntry(u8 ret, HighEntry *list, s16 s2) BANKED;
// the arcade games' shared menu helper: a list of choices, returns the one picked (or -1; -2 = B)
s8 menuList(u8 x, u8 y, u8 n, const char * const *items, u8 *sel, u8 step);
extern u8 entering;
#endif
