// pin.c — QU33PH PINBALL (the website's arcade pinball): the ball is a Qu33ph marker.
// The website's flat logical table and physics (bumpers +100, slings +25, the chair +250 and a
// ride up to MEGA +1000, its anti-trap nudges), seen flat from above. Whole numbers: the table
// in 1/4096 (positions kept in 1/65536), speeds in 1/65536 a step.
#pragma bank 255
#include "qu.h"
#include "res_pin.inc"

#define GV 39
#define RX 102
#define RY 221
#define DAMPK 159                       // 0.62 in 1/256
#define T_BEAD ST_GAME
typedef struct { s16 x, y, r; u8 hit, sling; } Bump;
static Bump bumps[6] = { {1331,0,430,0,0}, {1987,-410,430,0,0}, {2621,123,430,0,0}, {1987,492,430,0,0}, {901,3768,369,0,1}, {2908,3768,369,0,1} };
static const s16 TRIS[2][7][2] = {
    { {0,3834},{135,3232},{377,3195},{840,3920},{811,4239},{512,4264},{12,3883} },
    { {3748,3650},{3564,4338},{3215,4399},{2929,4252},{3244,3367},{3592,3269},{3736,3588} } };
static const s16 TRI_BOX[2][4] = { { 0, 840, 3195, 4264 }, { 2929, 3748, 3269, 4399 } };
#define FL_Y 4239
#define FL_LX 881
#define FL_RX 2888
static struct { s16 x, y, fx, fy; s16 vx, vy; u16 spin; u8 launched, toMega, inChute, color, upT, megaT, chkT; s16 chkY; } b;
enum { ST_MENU, ST_READY, ST_PLAY, ST_OVER };
static u8 st, sel, balls, seq, megaFlash, chairCD, msgT, tl, tr, acc, flash, newBest; static s16 fl, fr; static s32 score; static s16 coinsWon;
static const char *msg;
static s16 wallL[75], wallR[75];                 // the table's sides below 0.6, every 1/128
static void wallsInit(void) {
    for (u8 k = 0; k < 75; k++) {
        s32 tf = ((s32)k << 17) / 2376; if (tf > 4096) tf = 4096;
        s32 e = (((tf * tf) >> 12) * (12288 - 2 * tf)) >> 12;
        wallL[k] = 164 + (s16)((e * 614) >> 12); wallR[k] = 3850 - (s16)((e * 942) >> 12);
    }
}

#define X() (b.x)
#define Y() (b.y)
#define setX(v) (b.x = (v))
#define setY(v) (b.y = (v))
static s16 absS(s16 v) { return v < 0 ? -v : v; }
static s16 damp(s16 v) { return (v >> 1) + (v >> 3) - (v >> 7); }       // x 0.62
static void say(const char *t, u8 f) { msg = t; msgT = f; }
static void panel(void) {
    fillWin(1, 0, 6, 18, BLANK, PAL_TEXT);
    wtxt(1, 0, "SCORE", PAL_GREY); wnum(1, 1, score, 6, PAL_TEXT);
    wtxt(1, 3, "BALLS", PAL_GREY); for (u8 k = 0; k < balls; k++) wput(1 + k, 4, k & 1 ? UI_MK0 : UI_MK1, k & 1 ? PAL_GREEN : PAL_RED);
    wtxt(1, 6, "HIGH", PAL_GREY); wnum(1, 7, sv.arcadeBest[ARC_PINBALL], 6, PAL_BLUE);
    if (st == ST_READY) { wtxt(1, 9, "A/UP:", PAL_GOLD); wtxt(1, 10, "LAUNCH", PAL_GOLD); }
    wtxt(1, 13, "FLIP L", PAL_GREY); wtxt(1, 14, "B,LEFT", PAL_TEXT);
    wtxt(1, 15, "FLIP R", PAL_GREY); wtxt(1, 16, "A,RGHT", PAL_TEXT);
}
static void newBall(void) {
    memset(&b, 0, sizeof b); setX(4506); setY(4669); b.inChute = 1; b.color = seq++ & 1; b.chkY = -1; st = ST_READY; panel();
}
static void endGame(void) {
    newBest = score > sv.arcadeBest[ARC_PINBALL]; if (newBest) sv.arcadeBest[ARC_PINBALL] = score;
    sv.arcadePlays[ARC_PINBALL]++;
    s16 c = (s16)(score / 100); if (c > 25) c = 25;
    coinsWon = c; if (c > 0) addCoins(c);
    saveWrite();
    char l1[20], l2[20], l3[20];
    strcpy(l1, lbl("SCORE ", score)); strcpy(l2, newBest ? "NEW HIGH!" : lbl("HIGH ", sv.arcadeBest[ARC_PINBALL]));
    strcpy(l3, "+"); itoa10(coinsWon, l3 + 1); strcat(l3, " COINS");
    st = ST_OVER; overDraw("GAME OVER", l1, l2, l3);
}
static void addScore(s16 n) { score += n; wnum(1, 1, score, 6, PAL_TEXT); }
// a flipper: from (px, py), turned a (256ths), 0.2 long; active 0..256
static void flipper(s16 px, s16 py, u8 a, s16 active) {
    s16 bx = X(), by = Y();
    if (absS(bx - px) > 1100 || absS(by - py) > 1100) return;
    s16 dx = (s16)((s16)COSB(a) * 205) >> 5, dy = (s16)((s16)SINB(a) * 205) >> 5;     // (819 long)
    s16 dot = ((bx - px) >> 3) * (dx >> 3) + ((by - py) >> 3) * (dy >> 3);            // (1/64 of it)
    u16 t = dot <= 0 ? 0 : dot >= 2620 ? 256 : ((u16)dot * 25) >> 8;                 // 0..256 along it
    s16 cx = px + (s16)(((dx >> 3) * (s16)t) >> 5), cy = py + (s16)(((dy >> 3) * (s16)t) >> 5);
    s16 ox = bx - cx, oy = by - cy;
    if (absS(ox) >= 254 || absS(oy) >= 254) return;
    s32 d2 = (s32)ox * ox + (s32)oy * oy;
    if (d2 >= 254L * 254) return;
    s16 d = (s16)isqrt32((u32)d2); if (d < 1) d = 1;
    s16 nx = (s16)(((s32)ox << 8) / d), ny = (s16)(((s32)oy << 8) / d);
    setX(cx + (s16)((nx * 254L) >> 8)); setY(cy + (s16)((ny * 254L) >> 8));
    s16 dt = (s16)(((s32)b.vx * nx + (s32)b.vy * ny) >> 8);
    if (dt < 0) { s16 m = active > 90 ? 461 : 128; b.vx -= (s16)(((s32)m * dt * nx) >> 16); b.vy -= (s16)(((s32)m * dt * ny) >> 16); }
    b.vy -= (s16)(((u16)active * 205) >> 4);
    if (active > 102) sfx(SFX_FLIP);
}
static u8 inPoly(s16 px, s16 py, const s16 (*p)[2]) {
    u8 in = 0;
    for (u8 i = 0, j = 6; i < 7; j = i++) { s16 xi = p[i][0], yi = p[i][1], xj = p[j][0], yj = p[j][1];
        if ((yi > py) != (yj > py) && px < (s16)(((s32)(xj - xi) * (py - yi)) / (yj - yi)) + xi) in = !in; }
    return in;
}
static void triCollide(void) {
    s16 bx = X(), by = Y();
    for (u8 t = 0; t < 2; t++) {
        const s16 *bb = TRI_BOX[t]; if (bx < bb[0] || bx > bb[1] || by < bb[2] || by > bb[3]) continue;
        const s16 (*p)[2] = TRIS[t];
        if (!inPoly(bx, by, p)) continue;
        s32 best = 0x7FFFFFFF; s16 bcx = 0, bcy = 0;
        for (u8 i = 0, j = 6; i < 7; j = i++) {
            s16 ax = p[j][0], ay = p[j][1], dx = p[i][0] - ax, dy = p[i][1] - ay;
            s32 L2 = (s32)dx * dx + (s32)dy * dy; if (!L2) continue;
            s32 u = (((s32)(bx - ax) * dx + (s32)(by - ay) * dy)) / (L2 >> 12 ? L2 >> 12 : 1);
            if (u < 0) u = 0; if (u > 4096) u = 4096;
            s16 qx = ax + (s16)(((s32)dx * u) >> 12), qy = ay + (s16)(((s32)dy * u) >> 12);
            s32 dd = (s32)(bx - qx) * (bx - qx) + (s32)(by - qy) * (by - qy);
            if (dd < best) { best = dd; bcx = qx; bcy = qy; }
        }
        s16 nx = bx - bcx, ny = by - bcy; s16 nl = (s16)isqrt32((u32)((s32)nx * nx + (s32)ny * ny));
        if (nl < 1) { nx = bx < 2048 ? -256 : 256; ny = 77; nl = 0; }
        else { nx = (s16)(((s32)nx << 8) / nl); ny = (s16)(((s32)ny << 8) / nl); }
        nx = -nx; ny = -ny;                                       // (out of the shape)
        setX(bcx + (s16)((nx * 311L) >> 8)); setY(bcy + (s16)((ny * 311L) >> 8));
        s16 dot = (s16)(((s32)b.vx * nx + (s32)b.vy * ny) >> 8);
        if (dot < 0) { b.vx -= (s16)(((s32)435 * dot * nx) >> 16); b.vy -= (s16)(((s32)435 * dot * ny) >> 16); }
        s16 out = (s16)(((s32)b.vx * nx + (s32)b.vy * ny) >> 8);
        if (out < 655) { b.vx += (s16)(((s32)nx * (655 - out)) >> 8); b.vy += (s16)(((s32)ny * (655 - out)) >> 8); }
        b.vy += 262; sfx(SFX_WALL); return;
    }
}
static void step(void) {
    fl += ((tl ? 256 : 0) - fl) >> 1; fr += ((tr ? 256 : 0) - fr) >> 1;
    if (msgT) msgT--;
    if (megaFlash) megaFlash--;
    if (st != ST_PLAY) return;
    b.vy += GV; b.fx += b.vx; b.x += b.fx >> 4; b.fx &= 15; b.fy += b.vy; b.y += b.fy >> 4; b.fy &= 15; b.vx -= b.vx >> 7; b.vy -= b.vy >> 8;
    s16 mv = b.inChute ? 3277 : 2753;
    if (b.vx > mv) b.vx = mv; if (b.vx < -mv) b.vx = -mv; if (b.vy > mv) b.vy = mv; if (b.vy < -mv) b.vy = -mv;
    b.spin += (u16)(((u16)(absS(b.vx) + absS(b.vy)) * 98) >> 8);
    s16 x = X(), y = Y();
    if (b.inChute) {
        if (x < 4014 + RX) { setX(4014 + RX); if (b.vx < 0) b.vx = -(b.vx * 77 >> 8); }
        if (x > 4669 - RX) { setX(4669 - RX); b.vx = -(s16)(((s32)b.vx * DAMPK) >> 8); }
        if (y < 1720) { b.inChute = 0; setX(3686); b.vx = -1311; }
    } else {
        s16 lw = 164, rw = 3850;
        if (y >= 2458) { u8 k = (u8)((y - 2458) >> 5); if (k > 74) k = 74; lw = wallL[k]; rw = wallR[k]; }
        if (x < lw + RX) { setX(lw + RX); if (b.vx < 0) b.vx = -damp(b.vx); }
        if (x > rw - RX) { setX(rw - RX); if (b.vx > 0) b.vx = -damp(b.vx); }
    }
    x = X(); y = Y();
    if (y < 82 + RY) { setY(82 + RY); b.vy = -(s16)(((s32)b.vy * DAMPK) >> 8); y = Y(); }
    if (chairCD) chairCD--;
    if (b.toMega) { b.vx += (((3430 - x) >> 3) * 25) >> 5; b.upT = 0; b.megaT++;
        if (b.megaT > 70 || (y > 1720 && b.vy > 393)) { b.toMega = 0; b.megaT = 0; } }
    if (y < 3932 && !b.toMega) { if (b.upT < 255) b.upT++; } else b.upT = 0;
    u8 forceDown = b.upT > 135;                                   // the website's anti-trap
    if (forceDown) { b.vy += 229; b.vx += (((2048 - x) >> 3) * 7) >> 5; b.vx -= b.vx >> 5; }
    s16 spd = absS(b.vx) + absS(b.vy);
    if (!b.toMega && !b.inChute && y > 983 && y < 4055 && spd < 655) { b.vy += 183; b.vx += (((2048 - x) >> 3) * 3) >> 5; }
    if (!b.toMega && !b.inChute && y > 3441 && (x < 1393 || x > 2540)) b.vx += (((2048 - x) >> 3) * 37) >> 5;
    if (++b.chkT >= 16) {
        if (!b.toMega && !b.inChute && y > 983 && y < 3850 && (y - (b.chkY < 0 ? y : b.chkY)) < 82) {
            b.vx = (b.vx >> 1) - (b.vx >> 3) + (b.vx >> 5); if (b.vy < 1049) b.vy = 1049; b.vx += (2048 - x) >> 5; }
        b.chkY = y; b.chkT = 0;
    }
    for (u8 i = 0; i < 6 && !forceDown && !b.toMega; i++) { Bump *p = &bumps[i];
        if (absS(x - p->x) >= p->r + RX || absS(y - p->y) >= p->r + RY) continue;
        s16 qx = x - RX > p->x ? x - RX : x + RX < p->x ? x + RX : p->x, qy = y - RY > p->y ? y - RY : y + RY < p->y ? y + RY : p->y;
        s16 dx = qx - p->x, dy = qy - p->y;
        if (absS(dx) >= p->r || absS(dy) >= p->r) continue;
        s32 d2 = (s32)dx * dx + (s32)dy * dy; if (d2 >= (s32)p->r * p->r) continue;
        s16 d = (s16)isqrt32((u32)d2); if (d < 1) { d = 1; dy = 1; }
        s16 nx = (s16)(((s32)dx << 8) / d), ny = (s16)(((s32)dy << 8) / d), push = p->r - d;
        setX(X() + (s16)(((s32)nx * push) >> 8)); setY(Y() + (s16)(((s32)ny * push) >> 8));
        if (p->sling) { b.vx = (s16)(((s32)(2048 - p->x) * 205) >> 8); b.vy = 1966; }
        else {
            s16 dot = (s16)(((s32)b.vx * nx + (s32)b.vy * ny) >> 8);
            b.vx -= (s16)(((s32)2 * dot * nx) >> 8); b.vy -= (s16)(((s32)2 * dot * ny) >> 8);
            b.vx = (b.vx >> 1) + (s16)((nx * 393L) >> 8); b.vy = (b.vy >> 1) + (s16)((ny * 393L) >> 8);
        }
        p->hit = 8; flash = 6; addScore(p->sling ? 25 : 100); sfx(p->sling ? SFX_WALL : SFX_PIN);
        x = X(); y = Y();
    }
    if (x > 573 - RX && x < 1475 + RX && y > 2253 - RY && y < 2621 + RY && b.vy > -655 && !chairCD) {
        chairCD = 22; setY(2253 - RY); b.vx = 1704; b.vy = -5112; b.toMega = 1; b.megaT = 0; addScore(250); say("TO MEGA!", 45); sfx(SFX_JUMP); }
    if (b.toMega && Y() < 451 && X() > 2662 && X() < 4075) {
        addScore(1000); megaFlash = 50; say("MEGA! +1000", 70); b.toMega = 0; b.megaT = 0; b.vy = 918; b.vx = (s16)(((s32)(2048 - X()) * 82) >> 8); sfx(SFX_GOOD); }
    triCollide();
    flipper(FL_LX, FL_Y, (u8)(20 - ((fl * 41) >> 8)), fl);
    flipper(FL_RX, FL_Y, (u8)(108 + ((fr * 41) >> 8)), fr);
    if (Y() > 4833) { sfx(SFX_BAD); if (--balls == 0) endGame(); else newBall(); }
}
static s16 sx(s16 x) { return ((x >> 2) * 21) >> 8; }
static s16 sy(s16 y) { return (s16)(((u16)((y + 819) >> 2) * 25) >> 8); }
static const u8 BX4[3] = { 7, 30, 52 }, BY4[3] = { 9, 36, 62 };      // the beads along it, in 1/4 screen pixels
static u8 fa[2] = { 1, 1 }; static s8 fbx[2][3], fby[2][3];            // (worked out again only when a flipper moves)
static void drawFlipper(u8 side, s16 px, s16 py, u8 a, u8 pal) {
    if (fa[side] != a) { fa[side] = a; s16 c = COSB(a), sn = SINB(a); for (u8 k = 0; k < 3; k++) { fbx[side][k] = (s8)((c * BX4[k]) >> 9); fby[side][k] = (s8)((sn * BY4[k]) >> 9); } }
    s16 x0 = sx(px) - 4, y0 = sy(py) - 4;
    for (u8 k = 0; k < 3; k++) spr(x0 + fbx[side][k], y0 + fby[side][k], T_BEAD, pal);
}
static void drawSprites(void) {
    if (st == ST_PLAY || st == ST_READY) marker(sx(X()), sy(Y()), b.color ? 0 : 1, 64 + (u8)(b.spin >> 8));
    u8 pal = isCGB ? OP_GOLD : 0;
    drawFlipper(0, FL_LX, FL_Y, (u8)(20 - ((fl * 41) >> 8)), pal);
    drawFlipper(1, FL_RX, FL_Y, (u8)(108 + ((fr * 41) >> 8)), pal);
    if (msgT) sprText(48 - (s16)strlen(msg) * 4, 60, msg, isCGB ? OP_WHITE : 0);
}
static const u16 TABLE[4] = { RGB8(215, 225, 240), RGB8(230, 80, 80), RGB8(60, 60, 95), RGB8(20, 20, 40) };
static const u16 TABLE_LIT[4] = { RGB8(215, 225, 240), RGB8(255, 230, 90), RGB8(60, 60, 95), RGB8(20, 20, 40) };
static void table(void) {
    screenFresh();
    loadBkgTiles(SCENE_T, PIN_TILES, pin_tiles);
    loadSprTiles(T_BEAD, 1, pin_bead);
    setBkgPal(PAL_S1, TABLE);
    fillBkg(0, 0, 13, 18, SCENE_T, PAL_S1);
    fillBkg(12, 0, 1, 18, UI_SOLID3, PAL_GREY);
    for (u8 y = 0; y < 18; y++) { u8 t[12]; for (u8 x = 0; x < 12; x++) t[x] = SCENE_T + pin_map[y * 12 + x]; set_bkg_tiles(0, y, 12, 1, t); }
    fillWin(0, 0, 7, 18, BLANK, PAL_TEXT); for (u8 y = 0; y < 18; y++) wput(0, y, UI_L, PAL_GREY);
    winAt(7 + 104, 0);
    lcdOn();
}
static void start(void) { wallsInit(); score = 0; balls = 3; seq = 0; msgT = 0; flash = 0; fl = fr = 0; table(); newBall(); }

static const char * const MENU_ITEMS[2] = { "PLAY", "BACK" };
void pinEnter(void) BANKED { }
void pinUpdate(void) BANKED {
    if (entering) {
        st = ST_MENU; sel = 0;
        screenFresh(); txtC(0, "QU33PH PINBALL", PAL_GOLD);
        static const char * const L[7] = { "THE BALL IS A MARKER", "3 BALLS. BUMPERS 100", "SLINGS 25. THE CHAIR", "250 SENDS YOU UP TO", "MEGA: +1000!", "LEFT/B: LEFT FLIPPER", "RIGHT/A: RIGHT ONE" };
        for (u8 i = 0; i < 7; i++) txt(0, 2 + i, L[i], i == 4 ? PAL_GOLD : i >= 5 ? PAL_GREY : PAL_TEXT);
        txtC(16, lbl("HIGH ", sv.arcadeBest[ARC_PINBALL]), PAL_BLUE);
        lcdOn();
    }
    music(MUS_PIN);
    if (st == ST_MENU) {
        s8 h = menuList(6, 11, 2, MENU_ITEMS, &sel, 2);
        if (h == 0) start(); else if (h == 1 || h == -2) goScreen(S_ARCADE);
        return;
    }
    if (st == ST_OVER) { s8 h = overInput(); if (h == 0) start(); else if (h == 1) goScreen(S_ARCADE); return; }
    u8 p = pauseCheck(); if (p == 1) return;
    if (p == 2) { winAt(7 + 104, 0); }
    if (st == ST_READY && (kDown & (J_A | J_UP))) { b.vy = -3604; b.vx = -983; b.launched = 1; st = ST_PLAY; sfx(SFX_THROW); panel(); }
    else {
        u8 nl = (kHeld & (J_LEFT | J_B)) != 0, nr = (kHeld & (J_RIGHT | J_A)) != 0;
        if ((nl && !tl) || (nr && !tr)) sfx(SFX_FLIP);
        tl = nl; tr = nr;
    }
    step(); if (st == ST_PLAY && ++acc >= 3) { acc = 0; step(); }        // 4 steps every 3 frames: a livelier table
    if (st == ST_OVER) return;
    if (flash) { if (--flash == 0) { setBkgPal(PAL_S1, TABLE); if (!isCGB) BGP_REG = 0xE4; } else if (flash == 5) { setBkgPal(PAL_S1, TABLE_LIT); if (!isCGB) BGP_REG = 0xE0; } }
    if (megaFlash == 49) flash = 12;
    drawSprites();
}
