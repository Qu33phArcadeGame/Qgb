// menus.c — the title, high scores, settings, name entry, results, the 2-player hand-over and
// the Olympics (nation pick + bracket), as on the GBA, in text.
#pragma bank 255
#include "qu.h"
#include "res_core.h"

static u8 sel, highTab, confirmWhich = 255, confirmT, resultsNewBest;
static s32 lastCoinsGain;

// ── starting and ending matches ───────────────────────────────────────────
static void beginTurn(void) { orient = sv.orient; startMatch(); goScreen(S_PLAY); }
static void startSingle(void) { gmode = M_SINGLE; score2[0] = score2[1] = 0; player = 0; beginTurn(); }
static void startTwo(void) { gmode = M_TWO; score2[0] = score2[1] = 0; player = 0; p2Round = 1; orient = sv.orient; startMatch(); goScreen(S_HANDOFF); }
static void startOlympicMatch(void) { gmode = M_OLYMPICS; score2[0] = 0; player = 0; beginTurn(); }

// name entry → where to go after it, and which table gets the score
static u8 nameReturn = S_TITLE; static s16 nameScore; static HighEntry *nameList; static char nameBuf[9];
void nameEntry(u8 ret, HighEntry *list, s16 s2) BANKED { nameReturn = ret; nameList = list; nameScore = s2; strcpy(nameBuf, sv.name); sel = 0; goScreen(S_NAME); }
static void submitHigh(HighEntry *list, s16 s2, u8 ret) {
    if (!highQualifies(list, s2)) { goScreen(ret); return; }
    if (!sv.name[0]) { nameEntry(ret, list, s2); return; }
    highInsert(list, sv.name, s2);
    goScreen(ret);
    toast("NEW HIGH SCORE!", list == sv.high1p ? "1 PLAYER TOP 10" : "OLYMPICS TOP 10");
}

// ══ OLYMPICS (the GBA's rules) ════════════════════════════════════════════
static const char * const NATION[18] = { "IRELAND", "ISRAEL", "USA", "SOUTH AFRICA", "ENGLAND", "SCOTLAND", "NORWAY", "JAPAN", "GERMANY",
                                          "BRAZIL", "AUSTRALIA", "CANADA", "FRANCE", "NETHERLANDS", "SWEDEN", "RUSSIA", "IRAN", "CHINA" };
static const char * const CODE[18] = { "IRL", "ISR", "USA", "RSA", "ENG", "SCO", "NOR", "JPN", "GER", "BRA", "AUS", "CAN", "FRA", "NED", "SWE", "RUS", "IRN", "CHN" };
static u8 olyNation, olyFinished, olySpecial, olyRound, olyMedal, olySel, olyN[8];
static s16 qf1[2], qf2[2], qf3[2], qf4[2], sf1[2], sf2[2], fin[2], olyTotal; static u8 olyCoins;
static const u8 REWARD[4] = { 0, 5, 10, 15 }, SPECIAL_REWARD[4] = { 0, 1, 2, 3 };
static void olyReward(u8 r) { u8 c = (olySpecial ? SPECIAL_REWARD : REWARD)[r]; addCoins(c); olyCoins += c; }
// rival scores: the website's 85-130 scaled to what a flawless game here reaches (as the GBA)
static s16 simScore(void) { s16 b = 85 + (s16)(rnd16() % 45); if (rnd8() % 10 < 7) b = 90 + (s16)(rnd16() % 30); return b * 2 * 30 / 100; }
static u8 winQ(s16 *m, u8 a, u8 b) { return m[0] > m[1] ? a : b; }
static void freshBracket(void) {
    s16 *qs[3] = { qf1, qf2, qf3 };
    for (u8 k = 0; k < 3; k++) { qs[k][0] = simScore(); do qs[k][1] = simScore(); while (qs[k][1] == qs[k][0]); }
    qf4[0] = qf4[1] = sf1[0] = sf1[1] = sf2[0] = sf2[1] = fin[0] = fin[1] = -1;
    olyRound = 1; olyMedal = 0; olyTotal = 0; olyFinished = 0; olyCoins = 0;
}
static void shuffle(u8 *a, u8 n) { for (u8 i = n - 1; i > 0; i--) { u8 j = rnd8() % (i + 1), t = a[i]; a[i] = a[j]; a[j] = t; } }
static void olyNew(void) {
    u8 pool[18], n = 0;
    olySpecial = 0;
    for (u8 i = 0; i < 18; i++) if (i != olyNation) pool[n++] = i;
    shuffle(pool, n);
    for (u8 i = 0; i < 7; i++) olyN[i] = pool[i];
    olyN[7] = olyNation;
    freshBracket();
}
static void olyAfterMatch(s16 p) {
    s16 opp; do opp = simScore(); while (opp == p);
    olyTotal += p;
    if (olyRound == 1) {
        qf4[0] = opp; qf4[1] = p;
        sf1[0] = simScore(); do sf1[1] = simScore(); while (sf1[1] == sf1[0]);
        if (p <= opp) olyFinished = 1; else { olyReward(1); olyRound = 2; }
    } else if (olyRound == 2) {
        sf2[0] = opp; sf2[1] = p;
        if (p <= opp) { olyMedal = 1; olyFinished = 1; } else { olyReward(2); olyRound = 3; }
    } else {
        fin[0] = opp; fin[1] = p;
        olyMedal = p > opp ? 3 : 2;
        if (olyMedal == 3) olyReward(3);
        olyFinished = 1;
    }
    if (olyFinished && !olySpecial) { if (olyMedal == 3) sv.gold++; else if (olyMedal == 2) sv.silver++; else if (olyMedal == 1) sv.bronze++; }
    saveWrite();
}
// the Special Olympics: a second bracket of the nations knocked out of the first
static void olySpecialNew(void) {
    u8 pool[18], n = 0, used[18], extra[18], ne = 0;
    memset(used, 0, sizeof used);
    u8 w1 = winQ(qf1, olyN[0], olyN[1]), w2 = winQ(qf2, olyN[2], olyN[3]), w3 = winQ(qf3, olyN[4], olyN[5]);
    s16 *ms[6] = { qf1, qf2, qf3, qf4, sf1, sf2 }; u8 A[6] = { olyN[0], olyN[2], olyN[4], olyN[6], w1, w3 }, Bn[6] = { olyN[1], olyN[3], olyN[5], olyN[7], w2, olyNation };
    for (u8 k = 0; k < 6; k++) { if (ms[k][0] < 0) continue; u8 l = ms[k][0] > ms[k][1] ? Bn[k] : A[k]; if (l != olyNation && !used[l]) { used[l] = 1; pool[n++] = l; } }
    for (u8 i = 0; i < 18; i++) if (i != olyNation && !used[i]) extra[ne++] = i;
    shuffle(extra, ne);
    for (u8 i = 0; n < 7 && i < ne; i++) pool[n++] = extra[i];
    shuffle(pool, n);
    for (u8 i = 0; i < 7; i++) olyN[i] = pool[i];
    olyN[7] = olyNation;
    freshBracket(); olySpecial = 1;
}
static void olympicsDone(void) { sv.games++; saveWrite(); submitHigh(sv.highOly, olyTotal, S_TITLE); }

// ── the match finished (called from the match) ────────────────────────────
void matchFinished(void) BANKED {
    if (gmode == M_SINGLE) {
        s16 best = sv.high1p[0].name[0] ? sv.high1p[0].score2 : 0; s32 before = sv.coins;
        sv.games++;
        resultsNewBest = score2[0] > best && score2[0] > 0;
        if (resultsNewBest) addCoins(25);                       // a new personal best: +25 coins (as the website)
        lastCoinsGain = sv.coins - before;
        saveWrite();
        submitHigh(sv.high1p, score2[0], S_RESULTS);
    } else if (gmode == M_OLYMPICS) {
        sv.games++;
        olyAfterMatch(score2[0]);
        goScreen(S_OLY_BRACKET);
    } else {
        if (player == 0) { player = 1; startMatch(); goScreen(S_HANDOFF); return; }
        if (p2Round >= sv.twoRounds) { sv.games++; saveWrite(); goScreen(S_RESULTS); return; }
        p2Round++; player = 0; startMatch(); goScreen(S_HANDOFF);
    }
}

// ══ the screens ═══════════════════════════════════════════════════════════
static char sb[24], sb2[12];
static void fresh(void) {                              // a blank screen in the standard colours
    lcdOff(); uiPalettes(); scroll(0, 0); clearBkg(BLANK, PAL_TEXT); winAt(255, 0);
}
static void coinLine(u8 y) {
    itoa10(sv.coins, sb); u8 n = (u8)strlen(sb), x = (18 - n) / 2;
    put(x, y, UI_COIN, PAL_GOLD); txt(x + 2, y, sb, PAL_GOLD);
}

// ── title ─────────────────────────────────────────────────────────────────
static const char * const TITLE_ITEMS[8] = { "1 PLAYER", "2 PLAYER", "OLYMPICS", "HIGH SCORES", "SETTINGS", "SLOT", "PLINQU33PH", "ARCADE" };
static void drawTitle(void) {
    fresh();
    loadBkgTiles(SCENE_T, LOGO_TILES, logo_tiles);
    { u8 t[LOGO_W], a[LOGO_W];
      for (u8 y = 0; y < LOGO_H; y++) {
          for (u8 x = 0; x < LOGO_W; x++) { t[x] = SCENE_T + logo_map[y * LOGO_W + x]; a[x] = 4 + logo_attr[y * LOGO_W + x]; }
          setBkgMap((20 - LOGO_W) / 2, 1 + y, LOGO_W, 1, t, a);
      } }
    if (isCGB) set_bkg_palette(4, LOGO_PALS, logo_pals); else BGP_REG = 0xF8;   // (the grey Game Boy: darker, for the logo)
    if (sv.high1p[0].name[0]) {
        scoreStr(sb2, sv.high1p[0].score2);
        strcpy(sb, "HIGH "); strcat(sb, sb2); strcat(sb, " "); strcat(sb, sv.high1p[0].name);
        txtC(6, sb, PAL_GREY);
    }
    coinLine(7);
    lcdOn();
}
static void updateTitle(void) {
    if (entering) drawTitle();
    music(MUS_MAIN);
    s8 h = menuList(4, 9, 8, TITLE_ITEMS, &sel, 1);
    switch (h) {
        case 0: startSingle(); break;
        case 1: startTwo(); break;
        case 2: olySel = olyNation; goScreen(S_OLY_SELECT); break;
        case 3: highTab = 0; goScreen(S_HIGHS); break;
        case 4: sel = 0; goScreen(S_SETTINGS); break;
        case 5: goScreen(S_SLOT); break;
        case 6: goScreen(S_PLINKO); break;
        case 7: goScreen(S_ARCADE); break;
    }
}

// ── high scores: 1 PLAYER / OLYMPICS / RECORD (left/right change the page) ─
static const char * const HIGH_TABS[3] = { "1 PLAYER", "OLYMPICS", "RECORD" };
static void drawHighs(void) {
    fresh();
    txtC(0, HIGH_TABS[highTab], PAL_GOLD);
    put(1, 0, CH('<'), PAL_GREY); put(18, 0, CH('>'), PAL_GREY);
    if (highTab < 2) {
        HighEntry *l = highTab ? sv.highOly : sv.high1p;
        for (u8 i = 0; i < 10; i++) {
            u8 y = 2 + i + (i > 2);
            num(0, y, i + 1, 2, i < 3 ? PAL_GOLD : PAL_GREY);
            txt(3, y, l[i].name[0] ? l[i].name : "---", PAL_TEXT);
            if (l[i].name[0]) { scoreStr(sb, l[i].score2); txt(19 - (u8)strlen(sb), y, sb, PAL_GOLD); }
        }
        if (highTab == 1) txtC(15, "TOURNAMENT TOTALS", PAL_GREY);
    } else {
        static const char * const L[12] = { "GAMES PLAYED", "HIGH SCORE", "QU33PHS", "MEGA QU33PHS", "PEEFS", "FORFEITS",
                                            "COINS NOW", "COINS EARNED", "COINS SPENT", "SLOT SPINS", "SLOT WINS", "LOST IN SLOTS" };
        s32 V[12] = { sv.games, 0, sv.qu33phs, sv.megas, sv.peefs, sv.forfeits, sv.coins, sv.coinsEarned, sv.coinsSpent, sv.slotSpins, sv.slotWins, sv.slotLost };
        for (u8 i = 0; i < 12; i++) {
            u8 y = 2 + i;
            txt(0, y, L[i], i < 6 ? PAL_TEXT : PAL_GREY);
            if (i == 1) scoreStr(sb, sv.high1p[0].name[0] ? sv.high1p[0].score2 : 0); else itoa10(V[i], sb);
            txt(20 - (u8)strlen(sb), y, sb, PAL_GOLD);
        }
        txtC(15, "OLYMPIC MEDALS", PAL_GOLD);
        strcpy(sb, "G "); itoa10(sv.gold, sb2); strcat(sb, sb2); strcat(sb, "  S "); itoa10(sv.silver, sb2); strcat(sb, sb2);
        strcat(sb, "  B "); itoa10(sv.bronze, sb2); strcat(sb, sb2);
        txtC(16, sb, PAL_TEXT);
    }
    lcdOn();
}
static void updateHighs(void) {
    if (entering) drawHighs();
    if (kDown & (J_B | J_A)) { goScreen(S_TITLE); return; }
    if (kDown & J_RIGHT) { highTab = (highTab + 1) % 3; sfx(SFX_MOVE); drawHighs(); }
    if (kDown & J_LEFT) { highTab = (highTab + 2) % 3; sfx(SFX_MOVE); drawHighs(); }
}

// ── settings ──────────────────────────────────────────────────────────────
static const char * const ORIENT_NAME[3] = { "VERTICAL", "ANGLED", "FLAT" };
static char setL[10][20];
static const char *SETP[10];
static void setLine(u8 i, const char *a, const char *b) { strcpy(setL[i], a); strcat(setL[i], b); while (strlen(setL[i]) < 17) strcat(setL[i], " "); }
static void settingsText(void) {
    for (u8 i = 0; i < 10; i++) SETP[i] = setL[i];
    setLine(0, "MUSIC      ", sv.musicOn ? "ON" : "OFF");
    setLine(1, "SOUND FX   ", sv.sfxOn ? "ON" : "OFF");
    itoa10(sv.timer1p, sb2); strcat(sb2, "S"); setLine(2, "1P TIMER   ", sb2);
    itoa10(sv.timer2p, sb2); strcat(sb2, "S"); setLine(3, "2P TIMER   ", sb2);
    itoa10(sv.twoRounds, sb2); setLine(4, "2P ROUNDS  ", sb2);
    setLine(5, "START      ", ORIENT_NAME[sv.orient]);
    setLine(6, "NAME       ", sv.name[0] ? sv.name : "---");
    setLine(7, "BACK", "");
    setLine(8, confirmWhich == 8 ? "SURE? PRESS A" : "RESET SCORES", "");
    setLine(9, confirmWhich == 9 ? "SURE? PRESS A" : "RESET ALL", "");
}
static void updateSettings(void) {
    if (entering) { fresh(); txtC(0, "SETTINGS", PAL_GOLD); lcdOn(); confirmWhich = 255; }
    if (confirmT && --confirmT == 0) { confirmWhich = 255; entering = 1; }
    settingsText();
    if (kDown & J_B) { saveWrite(); goScreen(S_TITLE); return; }
    u8 redraw = entering;
    s8 h = menuList(1, 2, 10, SETP, &sel, 1);
    if (h < 0) return;
    switch (h) {
        case 0: sv.musicOn = !sv.musicOn; if (!sv.musicOn) musicStop(); break;
        case 1: sv.sfxOn = !sv.sfxOn; break;
        case 2: sv.timer1p = sv.timer1p == 30 ? 45 : sv.timer1p == 45 ? 60 : 30; break;
        case 3: sv.timer2p = sv.timer2p == 15 ? 30 : sv.timer2p == 30 ? 60 : 15; break;
        case 4: sv.twoRounds = sv.twoRounds == 3 ? 5 : sv.twoRounds == 5 ? 10 : 3; break;
        case 5: sv.orient = (sv.orient + 1) % 3; break;
        case 6: nameEntry(S_SETTINGS, 0, 0); return;
        case 7: saveWrite(); goScreen(S_TITLE); return;
        case 8: case 9:
            if (confirmWhich == (u8)h) {
                if (h == 8) resetHighScores(); else { resetEverything(); }
                toast("DONE", h == 8 ? "HIGH SCORES CLEARED" : "EVERYTHING RESET"); confirmWhich = 255;
            } else { confirmWhich = h; confirmT = 180; }
            break;
    }
    (void)redraw;
    saveWrite();
    settingsText();
    for (u8 i = 0; i < 10; i++) txt(3, 2 + i, setL[i], i == sel ? PAL_GOLD : (i >= 8 ? PAL_RED : PAL_TEXT));
}

// ── name entry: a keyboard (D-pad + A; B deletes; START done) ─────────────
static const char KEYS[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
static void keyAt(u8 i, u8 *x, u8 *y) { if (i < 36) { *x = 1 + (i % 10) * 2; *y = 8 + (i / 10) * 2; } else { *x = i == 36 ? 2 : 9; *y = 15; } }
static void nameKeys(void) {
    for (u8 i = 0; i < 38; i++) {
        u8 x, y; keyAt(i, &x, &y);
        put(x - 1, y, i == sel ? UI_CURSOR : BLANK, PAL_GOLD);
        if (i < 36) put(x, y, CH(KEYS[i]), i == sel ? PAL_GOLD : PAL_TEXT);
        else txt(x, y, i == 36 ? "DEL" : "OK", i == sel ? PAL_GOLD : PAL_GREEN);
    }
}
static void nameShow(void) {
    fillBkg(4, 4, 12, 1, BLANK, PAL_TEXT);
    strcpy(sb, nameBuf); if (strlen(sb) < 8) strcat(sb, "_");
    txt(6, 4, sb, PAL_TEXT);
}
static void updateName(void) {
    if (entering) {
        fresh();
        txt(0, 0, nameList ? "NEW HIGH SCORE!" : "YOUR NAME (UP TO 8)", PAL_GOLD);
        txt(0, 16, "B DELETE  START DONE", PAL_GREY);
        box(4, 3, 12, 3, PAL_TEXT);
        nameShow(); nameKeys();
        lcdOn();
    }
    u8 old = sel, len = (u8)strlen(nameBuf), done = 0;
    if (kDown & J_RIGHT) sel = sel >= 36 ? (sel == 36 ? 37 : 36) : (sel % 10 == 9 ? sel - 9 : sel + 1);
    if (kDown & J_LEFT) sel = sel >= 36 ? (sel == 36 ? 37 : 36) : (sel % 10 == 0 ? sel + 9 : sel - 1);
    if (kDown & J_DOWN) sel = sel >= 36 ? sel - 36 : (sel + 10 >= 36 ? (sel % 10 < 5 ? 36 : 37) : sel + 10);
    if (kDown & J_UP) sel = sel >= 36 ? (sel == 36 ? 30 : 34) : (sel < 10 ? (sel % 10 < 5 ? 36 : 37) : sel - 10);
    if (sel > 37) sel = 0;
    if (sel != old) { sfx(SFX_MOVE); nameKeys(); }
    if (kDown & J_A) {
        if (sel < 36 && len < 8) { nameBuf[len] = KEYS[sel]; nameBuf[len + 1] = 0; sfx(SFX_SELECT); nameShow(); }
        else if (sel == 36 && len) { nameBuf[len - 1] = 0; nameShow(); }
        else if (sel == 37) done = 1;
    }
    if ((kDown & J_B) && len) { nameBuf[len - 1] = 0; nameShow(); }
    if (kDown & J_START) done = 1;
    if (done && nameBuf[0]) {
        strcpy(sv.name, nameBuf);
        HighEntry *l = nameList; nameList = 0;
        if (l) highInsert(l, sv.name, nameScore);
        saveWrite();
        sel = 0; goScreen(nameReturn);
        if (l) toast("NEW HIGH SCORE!", sv.name);
    }
}

// ── results / the hand-over ───────────────────────────────────────────────
static const char * const RES_ITEMS[2] = { "PLAY AGAIN", "MENU" };
static void updateResults(void) {
    if (entering) {
        fresh(); sel = 0;
        txtC(1, gmode == M_SINGLE ? "FINAL SCORE" : "FINAL SCORES", PAL_GOLD);
        if (gmode == M_SINGLE) {
            scoreStr(sb, score2[0]); txtC(4, sb, PAL_TEXT);
            if (resultsNewBest) txtC(7, "NEW PERSONAL BEST!", PAL_GREEN);
            if (lastCoinsGain > 0) { strcpy(sb, "+"); itoa10(lastCoinsGain, sb2); strcat(sb, sb2); strcat(sb, " COINS"); txtC(9, sb, PAL_GOLD); }
        } else {
            scoreStr(sb2, score2[0]); strcpy(sb, "P1  "); strcat(sb, sb2); txtC(4, sb, PAL_TEXT);
            scoreStr(sb2, score2[1]); strcpy(sb, "P2  "); strcat(sb, sb2); txtC(5, sb, PAL_TEXT);
            txtC(8, score2[0] > score2[1] ? "PLAYER 1 WINS!" : score2[1] > score2[0] ? "PLAYER 2 WINS!" : "IT'S A TIE!", PAL_GOLD);
        }
        coinLine(16);
        lcdOn();
    }
    music(MUS_MAIN);
    s8 h = menuList(5, 12, 2, RES_ITEMS, &sel, 2);
    if (h == -2) h = 1;
    if (h == 0) { if (gmode == M_TWO) startTwo(); else startSingle(); }
    if (h == 1) { sel = 0; goScreen(S_TITLE); }
}
static void updateHandoff(void) {
    if (entering) {
        fresh();
        strcpy(sb, "PLAYER "); itoa10(player + 1, sb2); strcat(sb, sb2); txtC(5, sb, PAL_GOLD);
        strcpy(sb, "ROUND "); itoa10(p2Round, sb2); strcat(sb, sb2); strcat(sb, " / "); itoa10(sv.twoRounds, sb2); strcat(sb, sb2); txtC(8, sb, PAL_TEXT);
        scoreStr(sb2, score2[0]); strcpy(sb, "P1 "); strcat(sb, sb2); strcat(sb, "   P2 "); scoreStr(sb2, score2[1]); strcat(sb, sb2); txtC(10, sb, PAL_GREY);
        txtC(12, "PASS THE GAME BOY", PAL_TEXT);
        txtC(15, "A TO START", PAL_GOLD);
        lcdOn();
    }
    if (kDown & (J_A | J_START)) goScreen(S_PLAY);
}

// ── Olympics: pick a nation, then the bracket ─────────────────────────────
static void natCell(u8 i) {
    u8 x = 1 + (i % 3) * 6, y = 4 + (i / 3) * 2;
    put(x, y, i == olySel ? UI_CURSOR : BLANK, PAL_GOLD);
    txt(x + 1, y, CODE[i], i == olySel ? PAL_GOLD : PAL_TEXT);
}
static void updateOlySelect(void) {
    if (entering) {
        fresh();
        txtC(0, "QU33PH OLYMPICS", PAL_GOLD);
        txtC(1, "CHOOSE YOUR NATION", PAL_GREY);
        for (u8 i = 0; i < 18; i++) natCell(i);
        lcdOn();
    }
    u8 old = olySel;
    if (kDown & J_B) { goScreen(S_TITLE); return; }
    if (kDown & J_RIGHT) olySel = (olySel + 1) % 18;
    if (kDown & J_LEFT) olySel = (olySel + 17) % 18;
    if (kDown & J_DOWN) olySel = (olySel + 3) % 18;
    if (kDown & J_UP) olySel = (olySel + 15) % 18;
    if (old != olySel || entering) { natCell(old); natCell(olySel); fillBkg(0, 17, 20, 1, BLANK, PAL_TEXT); txtC(17, NATION[olySel], PAL_TEXT); if (old != olySel) sfx(SFX_MOVE); }
    if (kDown & J_A) { sfx(SFX_SELECT); olyNation = olySel; olyNew(); sel = 0; goScreen(S_OLY_BRACKET); }
}
static void matchRow(u8 y, u8 a, u8 b, s16 *m) {
    txt(0, y, CODE[a], a == olyNation ? PAL_GOLD : PAL_TEXT);
    if (m[0] >= 0) { scoreStr(sb, m[0]); txt(4, y, sb, m[0] > m[1] ? PAL_GREEN : PAL_GREY); }
    txt(9, y, "V", PAL_GREY);
    txt(11, y, CODE[b], b == olyNation ? PAL_GOLD : PAL_TEXT);
    if (m[1] >= 0) { scoreStr(sb, m[1]); txt(15, y, sb, m[1] > m[0] ? PAL_GREEN : PAL_GREY); }
}
static const char * const OLY_PLAY[3] = { "PLAY QUARTER-FINAL", "PLAY SEMI-FINAL", "PLAY THE FINAL" };
static const char * const OLY_AFTER2[2] = { "SPECIAL OLYMPICS", "CONTINUE" };
static const char * const OLY_AFTER1[1] = { "CONTINUE" };
static void updateOlyBracket(void) {
    u8 nb = !olyFinished ? 1 : (olyMedal != 3 && !olySpecial) ? 2 : 1;
    if (entering) {
        fresh();
        txt(0, 0, olySpecial ? "SPECIAL OLYMPICS" : "OLYMPIC BRACKET", olySpecial ? PAL_RED : PAL_GOLD);
        txt(16, 0, "B:X", PAL_GREY);
        txt(0, 1, "QUARTER-FINALS", PAL_GREY);
        matchRow(2, olyN[0], olyN[1], qf1); matchRow(3, olyN[2], olyN[3], qf2);
        matchRow(4, olyN[4], olyN[5], qf3); matchRow(5, olyN[6], olyN[7], qf4);
        u8 w1 = winQ(qf1, olyN[0], olyN[1]), w2 = winQ(qf2, olyN[2], olyN[3]), w3 = winQ(qf3, olyN[4], olyN[5]);
        s16 s1w = sf1[0] >= 0 ? winQ(sf1, w1, w2) : -1;
        txt(0, 6, "SEMI-FINALS", PAL_GREY);
        if (sf1[0] >= 0) matchRow(7, w1, w2, sf1);
        if (olyRound >= 2 || sf2[0] >= 0) matchRow(8, w3, olyNation, sf2);
        txt(0, 9, "FINAL", PAL_GREY);
        if (fin[0] >= 0 || olyRound == 3) matchRow(10, s1w >= 0 ? (u8)s1w : w1, olyNation, fin);
        strcpy(sb, "COINS WON "); itoa10(olyCoins, sb2); strcat(sb, sb2); txt(0, 11, sb, PAL_GOLD);
        if (olyFinished) {
            txtC(12, olyMedal == 3 ? "GOLD MEDAL!" : olyMedal == 2 ? "SILVER MEDAL" : olyMedal == 1 ? "BRONZE MEDAL" : "KNOCKED OUT",
                 olyMedal == 3 ? PAL_GOLD : olyMedal ? PAL_TEXT : PAL_RED);
        }
        lcdOn();
    }
    music(MUS_MAIN);
    if (kDown & J_B) { goScreen(S_TITLE); return; }
    const char * const *items = !olyFinished ? &OLY_PLAY[olyRound - 1] : nb == 2 ? OLY_AFTER2 : OLY_AFTER1;
    s8 h = menuList(1, 14, nb, items, &sel, 2);
    if (h < 0) return;
    if (!olyFinished) startOlympicMatch();
    else if (nb == 2 && h == 0) { sv.games++; saveWrite(); olySpecialNew(); sel = 0; goScreen(S_OLY_BRACKET); }
    else olympicsDone();
}

// ── the dispatcher ────────────────────────────────────────────────────────
void menusEnter(void) BANKED { }
void menusUpdate(void) BANKED {
    switch (screen) {
        case S_TITLE: updateTitle(); break;
        case S_HIGHS: updateHighs(); break;
        case S_SETTINGS: updateSettings(); break;
        case S_NAME: updateName(); break;
        case S_RESULTS: updateResults(); break;
        case S_HANDOFF: updateHandoff(); break;
        case S_OLY_SELECT: updateOlySelect(); break;
        case S_OLY_BRACKET: updateOlyBracket(); break;
    }
}
