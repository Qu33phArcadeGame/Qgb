// save.c — progress in the cartridge's battery-backed memory, high scores, the coin record
#include "qu.h"

SaveData sv;
#define SAVE_MAGIC 0x5133
#define SAVE_VERSION 1
static u16 sum(const u8 *p, u16 n) { u16 h = 0x1D0F; while (n--) { h = (h << 5) + h + *p++; } return h; }
static void defaults(void) {
    memset(&sv, 0, sizeof sv);
    sv.magic = SAVE_MAGIC; sv.version = SAVE_VERSION;
    sv.musicOn = 1; sv.sfxOn = 1; sv.twoRounds = 5; sv.timer1p = 30; sv.timer2p = 15; sv.orient = 0;
}
// the save memory: the data, then its checksum (a blank or scrambled memory starts fresh)
#define SRAM ((u8 *)0xA000)
void saveInit(void) {
    defaults();
    ENABLE_RAM; SWITCH_RAM(0);
    SaveData *t = (SaveData *)SRAM; u16 chk = *(u16 *)(SRAM + sizeof(SaveData));
    if (t->magic == SAVE_MAGIC && t->version == SAVE_VERSION && chk == sum(SRAM, sizeof(SaveData))) {
        memcpy(&sv, SRAM, sizeof sv);
        for (u8 i = 0; i < 10; i++) { sv.high1p[i].name[8] = 0; sv.highOly[i].name[8] = 0; }
        sv.name[8] = 0;
    }
    DISABLE_RAM;
#ifdef TESTCOINS
    if (sv.coins < 500) sv.coins = 500;           // (test builds only)
#endif
    saveWrite();
}
// written straight away (it's quick); only when something changed
void saveWrite(void) {
    ENABLE_RAM; SWITCH_RAM(0);
    u16 chk = sum((const u8 *)&sv, sizeof sv);
    if (memcmp(SRAM, &sv, sizeof sv) || *(u16 *)(SRAM + sizeof(SaveData)) != chk) {
        memcpy(SRAM, &sv, sizeof sv);
        *(u16 *)(SRAM + sizeof(SaveData)) = chk;
    }
    DISABLE_RAM;
}
void resetHighScores(void) { memset(sv.high1p, 0, sizeof sv.high1p); memset(sv.highOly, 0, sizeof sv.highOly); saveWrite(); }
void resetEverything(void) { defaults(); saveWrite(); }
void addCoins(s32 n) { sv.coins += n; if (n > 0) sv.coinsEarned += n; }
void spendCoins(s32 n) { sv.coins -= n; sv.coinsSpent += n; }
u8 highQualifies(HighEntry *l, s16 s2) { return s2 > 0 && (!l[9].name[0] || s2 > l[9].score2); }
void highInsert(HighEntry *l, const char *name, s16 s2) {
    u8 i = 9;
    while (i > 0 && (!l[i - 1].name[0] || s2 > l[i - 1].score2)) { l[i] = l[i - 1]; i--; }
    strncpy(l[i].name, name, 8); l[i].name[8] = 0; l[i].score2 = s2;
    saveWrite();
}
void scoreStr(char *o, s16 d) {
    u8 half = (d & 1) != 0; s16 w = d / 2;
    if (d < 0 && half) { *o++ = '-'; w = -w; }
    itoa10(w, o);
    if (half) strcat(o, ".5");
}
