// ball.c — QU33PH-BALL (the website's qu33phball.html): three skee-ball machines, nine rolls.
// The GBA's roll maths and scoring shapes (shapes looked up in a grid made from them), the
// chairs that lob the marker, and the CHAIR TOWER's climb to 5K, 20K and the 33K MEGA.
#pragma bank 255
#include "qu.h"
#include "res_ball.inc"
#include "res_ballpic.h"

#define Q(v) ((s16)((v) * 4096))
#define TOTAL 9
#define LAND_HOLD 13
#define FEED_DUR 11
#define HOP_T 19
#define MEGA_VAL 33000
typedef struct { const char *name; s16 sx, sy, queueY; u8 dur; s16 topY, cx, aimSpan, aimScat, baseY, powY, jitX, jitY, overFrom; u8 overK, scat; s16 coinDiv; } Machine;
static const Machine MACH[3] = {
    { "CLASSIC", Q(0.490), Q(0.775), Q(0.735), 32, Q(0.218), Q(0.523), Q(0.175), Q(0.95), Q(0.505), Q(0.265), Q(0.059), Q(0.062), 8192, 0, 0, 50 },
    { "ADVANCED", Q(0.490), Q(0.820), Q(0.790), 34, Q(0.232), Q(0.443), Q(0.256), Q(1.15), Q(0.560), Q(0.320), Q(0.043), Q(0.048), Q(0.84), 7, 1, 100 },
    { "CHAIR TOWER", Q(0.500), Q(0.820), Q(0.790), 34, Q(0.340), Q(0.500), Q(0.285), Q(1.08), Q(0.765), Q(0.589), Q(0.040), Q(0.045), Q(0.92), 5, 2, 1000 } };
static const u8 * const GRID[3] = { ball_grid0, ball_grid1, ball_grid2 };
static const u8 * const MAPS[3] = { ball_map0, ball_map1, ball_map2 };
static const int16_t * const PTS[3] = { ball_pts0, ball_pts1, ball_pts2 };
static const u8 * const CHAIRS[3] = { ball_chair0, ball_chair1, ball_chair2 };
static const int8_t * const SIDES[3] = { ball_side0, ball_side1, ball_side2 };
static const int16_t * const TOS[3] = { ball_to0, ball_to1, ball_to2 };
static const u8 * const PICS[3] = { ball_pic0, ball_pic1, ball_pic2 };
static const u8 PICN[3] = { BALL_PIC0_N, BALL_PIC1_N, BALL_PIC2_N };

enum { ST_MENU, ST_READY, ST_ROLL, ST_LANDED, ST_FEED, ST_OVER };
typedef struct { s16 x, y; s16 p; } Stop;
static u8 mach, curIdx, resolved, state, landT, hopN, hopAt, hasChair, sel, newBest;
static s32 score, pendingScore; static s16 coinsWon;
static struct { s16 x0, y0, x1, y1; u8 t, dur, col, caught; u16 spin; } ball;
static struct { s16 x0, y0, x1, y1; u8 t, on; } hop;
static u8 feedT;
static Stop hopQ[5], lastChair;
static u8 charging, chargeT, ph, power; static s8 aim;
static char popT[10]; static u8 popLife; static s16 popX, popY;

static const Machine *M(void) { return &MACH[mach]; }
static u8 colOf(u8 i) { return i % 3; }
static const u8 MKC[3] = { 1, 0, 2 };                                  // red, green, blue -> marker() colours                              // red, green, blue, red ...
// a spot (4096ths of the cabinet) -> the shape it's in (0 = none)
static u8 zoneAt(s16 x, s16 y) {
    if (x < 614 || y < 614) return 0;
    s16 gx = (((x - 614) >> 3) * 57) >> 9, gy = (((y - 614) >> 3) * 25) >> 7;     // (x 40/2867, y 68/2785)
    if (gx < 0 || gx >= 40 || gy < 0 || gy >= 68) return 0;
    u8 b = GRID[mach][gy * 20 + (gx >> 1)];
    return (gx & 1) ? (b & 15) : (b >> 4);
}
static s16 px(s16 x) { return 16 + ((((x - 614) >> 3) * 57) >> 8); }               // (x 80/2867)
static s16 py(s16 y) { return y < 614 ? -(((614 - y) >> 3) * 25 >> 6) : (s16)(((u16)((y - 614) >> 3) * 100) >> 8); }   // (x 136/2785)
static s16 absS(s16 v) { return v < 0 ? -v : v; }
// the website's scatter for each machine, at power p (0..4096)
static s16 scatOf(u8 k, s16 p) {
    if (k == 0) return Q(0.55) + (s16)(((s32)absS(p - Q(0.70)) * 3) / 2);
    if (k == 1) return Q(0.55) + (s16)(((s32)absS(p - Q(0.74)) * 6) / 5) + (p > Q(0.80) ? (s16)(((s32)(p - Q(0.80)) * 9) / 2) : 0);
    return Q(0.52) + (s16)(((s32)absS(p - Q(0.73)) * 5) / 4) + (p > Q(0.84) ? (s16)(((s32)(p - Q(0.84)) * 18) / 5) : 0);
}
static s16 rndq(void) { return (s16)(rnd16() & 4095) - 2048; }           // (rand - 0.5), in 4096ths
static void roll(void) {
    const Machine *f = M();
    s16 p = (s16)power * 16, a = (s16)aim * 41;                          // 0..4080, -4096..4096
    s16 sc = scatOf(f->scat, p) + (s16)(((s32)absS(a) * f->aimScat) >> 12);
    s16 lx = f->cx + (s16)(((s32)a * f->aimSpan) >> 12) + (s16)((((s32)rndq() * f->jitX) >> 12) * sc >> 12);
    s16 ly = f->baseY - (s16)(((s32)p * f->powY) >> 12) + (s16)((((s32)rndq() * f->jitY) >> 12) * sc >> 12);
    if (p > f->overFrom) { s32 ch = ((s32)(p - f->overFrom) * f->overK); if (ch > Q(0.85)) ch = Q(0.85); if ((s32)(rnd16() & 4095) < ch) ly = f->topY + 25; }
    if (ly < f->topY) ly = f->topY;
    ball.x0 = f->sx; ball.y0 = f->sy; ball.x1 = lx; ball.y1 = ly; ball.t = 0; ball.dur = f->dur;
    ball.col = colOf(curIdx); ball.spin = 0; ball.caught = 0;
    state = ST_ROLL; charging = 0;
    sfx(SFX_THROW);
}
static void stopAt(Stop *s, s16 x, s16 y, s16 p) { s->x = x; s->y = y; s->p = p; }
static s32 scoreLanding(s16 lx, s16 ly) {
    hasChair = 0; hopN = hopAt = 0;
    u8 z = zoneAt(lx, ly); if (!z) return 0;
    u8 i = z - 1, ch = CHAIRS[mach][i];
    if (ch == 2) {                                                       // the chair tower climb
        u8 L = SIDES[mach][i] < 0; s32 fin = 1000;
        stopAt(&hopQ[hopN++], L ? Q(0.220) : Q(0.780), Q(0.585), 1000);
        if ((rnd8() & 3) != 0) {                                         // 75% climb on
            stopAt(&hopQ[hopN++], L ? Q(0.260) : Q(0.740), Q(0.445), 5000); fin = 5000;
            if (rnd8() < 115) {                                          // 45% reach the top chair
                stopAt(&hopQ[hopN++], L ? Q(0.255) : Q(0.745), Q(0.250), 0);
                if (rnd8() & 1) { stopAt(&hopQ[hopN++], L ? Q(0.245) : Q(0.755), Q(0.175), 20000); fin = 20000; }
                else { stopAt(&hopQ[hopN++], Q(0.510), Q(0.174), 0); fin = MEGA_VAL; }
            }
        }
        lastChair = hopQ[hopAt++]; hasChair = 1;
        return fin;
    }
    if (ch == 1) { stopAt(&lastChair, TOS[mach][i * 2], TOS[mach][i * 2 + 1], PTS[mach][i]); hasChair = 1; }
    return PTS[mach][i];
}
static void fmtK(char *o, s32 n) {                                       // 12400 -> "12.4K"
    if (n < 1000) { itoa10(n, o); return; }
    s32 t = (n + 50) / 100; itoa10(t / 10, o);
    if (t % 10) { u8 l = (u8)strlen(o); o[l] = '.'; o[l + 1] = '0' + (u8)(t % 10); o[l + 2] = 0; }
    strcat(o, "K");
}
static void pop(s16 x, s16 y, s32 pts) { if (pts > 0) { strcpy(popT, "+"); fmtK(popT + 1, pts); } else strcpy(popT, "MISS"); popX = x; popY = y; popLife = 60; }
static s32 bestOf(void) { return sv.ballBest[mach]; }
static void panel(void) {
    char b[12];
    fillWin(0, 0, 7, 18, BLANK, PAL_TEXT);
    for (u8 y = 0; y < 18; y++) wput(0, y, UI_L, PAL_GREY);
    wtxt(mach == 0 ? 0 : 1, 0, mach == 0 ? "CLASSIC" : mach == 1 ? "ADVNCD" : "TOWER", PAL_GOLD);
    wtxt(1, 2, "SCORE", PAL_GREY); fmtK(b, score); wtxt(1, 3, b, PAL_GOLD);
    wtxt(1, 5, "LEFT", PAL_GREY); wnum(1, 6, TOTAL - resolved, 2, PAL_TEXT);
    wtxt(1, 8, "BEST", PAL_GREY); fmtK(b, bestOf()); wtxt(1, 9, b, PAL_TEXT);
    wtxt(1, 11, "HOLD A", PAL_GREY);
    if (!resolved) { wtxt(1, 13, "SELECT", PAL_GREY); wtxt(1, 14, "=SWAP", PAL_GREY); }
}
static void gameOver(void) {
    state = ST_OVER;
    newBest = score > bestOf();
    if (newBest) sv.ballBest[mach] = score;
    if (score > sv.arcadeBest[ARC_BALL]) sv.arcadeBest[ARC_BALL] = score;
    sv.arcadePlays[ARC_BALL]++;
    s32 c = score / M()->coinDiv; if (c > 40) c = 40;
    coinsWon = (s16)c; if (c > 0) addCoins(c);
    saveWrite();
    char b[12]; fmtK(b, score); strcpy(sbuf, "SCORE "); strcat(sbuf, b);
    char l2[20]; fmtK(b, bestOf()); strcpy(l2, newBest ? "NEW BEST! " : "BEST "); strcat(l2, b);
    char l3[20]; strcpy(l3, "+"); itoa10(coinsWon, l3 + 1); strcat(l3, " COINS");
    char l1[20]; strcpy(l1, sbuf);
    overDraw("GAME OVER", l1, l2, l3);
}
static void machineScreen(void) {
    screenFresh();
    u8 n = PICN[mach];                                                   // up to 128 at the start, the rest at SCENE_T2
    loadBkgTilesBanked(BANK(res_ballpic), SCENE_T, n > 128 ? 128 : n, PICS[mach]);
    if (n > 128) loadBkgTilesBanked(BANK(res_ballpic), SCENE_T2, n - 128, PICS[mach] + 128 * 16);
    static const u16 MP[4] = { RGB8(240, 220, 170), RGB8(200, 120, 60), RGB8(100, 50, 30), RGB8(30, 20, 15) };
    setBkgPal(PAL_S1, MP);
    fillBkg(0, 0, 20, 18, UI_SOLID3, PAL_S1);
    const u8 *m = MAPS[mach];
    fillBkg(2, 0, 10, 17, SCENE_T, PAL_S1);                              // (sets the colours on the Color)
    set_bkg_tiles(2, 0, 10, 17, m);
    panel(); winAt(7 + 104, 0);
    lcdOn();
}
static void startBall(u8 m) {
    mach = m; curIdx = resolved = 0; score = pendingScore = 0; state = ST_READY; landT = 0; hop.on = 0; hopN = hopAt = 0; hasChair = 0;
    popLife = 0; charging = chargeT = 0; aim = 0;
    machineScreen();
}
static s16 lerp(s16 d, s16 k) { return ((d >> 4) * (k >> 5)) >> 3; }     // d * k / 4096, in 16 bits
static s16 ease(u8 t, u8 dur) { u16 k = ((u16)t << 8) / dur; if (k >= 256) return 4096; u16 r = 256 - k; return (s16)(4096 - ((r * r) >> 4)); }   // 1 - (1-t)^2, in 4096ths
static void step(void) {
    if (state == ST_ROLL) {
        ball.t++; ball.spin += 26 << 4;
        if (!ball.caught) {                                              // chairs catch the marker as it passes
            s16 k = ease(ball.t >= ball.dur ? ball.dur : ball.t, ball.dur);
            s16 cx = ball.x0 + lerp(ball.x1 - ball.x0, k), cy = ball.y0 + lerp(ball.y1 - ball.y0, k);
            u8 z = zoneAt(cx, cy);
            if (z && CHAIRS[mach][z - 1]) { ball.x1 = cx; ball.y1 = cy; ball.t = ball.dur; ball.caught = 1; }
        }
        if (ball.t >= ball.dur) {
            ball.t = ball.dur;
            s32 pts = scoreLanding(ball.x1, ball.y1); resolved++;
            sfx(pts > 0 || hasChair ? SFX_PLOP : SFX_BAD);
            if (hasChair) pendingScore = pts; else score += pts;
            u8 left = hopN - hopAt;
            if (hasChair) {
                const Stop *e = left ? &hopQ[hopN - 1] : &lastChair;
                pop(e->x, e->y, pts);
                hop.x0 = ball.x1; hop.y0 = ball.y1; hop.x1 = lastChair.x; hop.y1 = lastChair.y; hop.t = 0; hop.on = 1;
            } else pop(ball.x1, ball.y1, pts);
            state = ST_LANDED; landT = 0;
            panel();
        }
    } else if (state == ST_LANDED) {
        landT++;
        if (hop.on) {
            ball.spin += 35 << 4;
            if (++hop.t >= HOP_T) {
                ball.x1 = hop.x1; ball.y1 = hop.y1; sfx(SFX_PLOP);
                if (hopAt < hopN) { Stop *n = &hopQ[hopAt++]; hop.x0 = ball.x1; hop.y0 = ball.y1; hop.x1 = n->x; hop.y1 = n->y; hop.t = 0; }
                else { hop.on = 0; landT = 0; score += pendingScore; pendingScore = 0; if (score >= MEGA_VAL) sfx(SFX_GOOD); panel(); }
            }
        }
        if (landT >= LAND_HOLD && !hop.on) {
            if (resolved >= TOTAL) gameOver();
            else { curIdx++; feedT = 0; state = ST_FEED; }
        }
    } else if (state == ST_FEED) { if (++feedT >= FEED_DUR) state = ST_READY; }
    if (popLife) popLife--;
}
static void drawSprites(void) {
    const Machine *f = M();
    if (state == ST_READY || state == ST_FEED) {
        marker(px(f->sx), py(f->sy), MKC[colOf(curIdx)], 64);
        if (state == ST_READY && (charging || chargeT)) {
            s16 p = charging ? (s16)power * 16 : 2048;
            s16 tx = f->cx + (s16)(((s32)aim * 41 * f->aimSpan) >> 12), ty = f->baseY - (s16)(((s32)p * f->powY) >> 12); if (ty < f->topY) ty = f->topY;
            s16 x0 = px(f->sx), y0 = py(f->sy), x1 = px(tx), y1 = py(ty);
            if (charging) powerMarker(x0, y0, atan2i(y1 - y0, x1 - x0), 10 + (power >> 2), power);
            spr(x1 - 4, y1 - 4, UI_SPARK, isCGB ? OP_GOLD : 0);
        }
    }
    if (state == ST_ROLL || state == ST_LANDED) {
        s16 cx, cy, lift = 0;
        if (hop.on) {
            s16 k = (s16)(((u16)hop.t << 12) / HOP_T);
            cx = hop.x0 + lerp(hop.x1 - hop.x0, k); cy = hop.y0 + lerp(hop.y1 - hop.y0, k);
            lift = (SINB((u8)(k >> 5)) * 12) >> 7;
        } else {
            s16 k = ease(ball.t, ball.dur);
            cx = ball.x0 + lerp(ball.x1 - ball.x0, k); cy = ball.y0 + lerp(ball.y1 - ball.y0, k);
        }
        u8 small = hop.on || state == ST_LANDED || ball.t > ball.dur / 2;
        if (!(state == ST_LANDED && !hop.on && landT > 8 && (landT & 2))) {
            if (small) miniMarker(px(cx), py(cy) - lift, ball.col == 0 ? 1 : ball.col == 1 ? 0 : 3, (u8)(ball.spin >> 4));
            else marker(px(cx), py(cy), MKC[ball.col], (u8)(ball.spin >> 4));
        }
    }
    { static const u8 MK[3] = { 1, 0, 3 }; u8 c = (curIdx + 1) % 3, col = 0, row = 0;
      for (u8 k = curIdx + 1; k < TOTAL; k++) { miniMarker(114 + col * 10, 124 + row * 10, MK[c], 64); if (++c == 3) c = 0; if (++col == 4) { col = 0; row++; } } }
    if (popLife) sprText(px(popX) - 8, py(popY) - 16, popT, isCGB ? OP_WHITE : 0);
}
static const char * const MENU_ITEMS[4] = { "CLASSIC", "ADVANCED", "CHAIR TOWER", "BACK" };
void ballEnter(void) BANKED { }
void ballUpdate(void) BANKED {
    if (entering) {
        state = ST_MENU; sel = 0;
        screenFresh(); txtC(0, "QU33PH-BALL", PAL_GOLD);
        static const char * const L[6] = { "9 MARKERS A GAME.", "ROLL IT UP THE LANE;", "SOFT AND WIDE FOR", "THE POCKETS. CHAIRS", "LOB IT. THE TOWER", "CLIMBS TO 33K MEGA!" };
        for (u8 i = 0; i < 6; i++) txt(0, 2 + i, L[i], i == 5 ? PAL_GOLD : PAL_TEXT);
        for (u8 i = 0; i < 3; i++) { char b[10]; fmtK(b, sv.ballBest[i]); strcpy(sbuf, "BEST "); strcat(sbuf, b); if (sv.ballBest[i]) txt(16, 10 + i * 2, b, PAL_GREY); }
        lcdOn();
    }
    music(MUS_BALL);
    if (state == ST_MENU) {
        if (kDown & J_B) { goScreen(S_ARCADE); return; }
        s8 h = menuList(3, 10, 4, MENU_ITEMS, &sel, 2);
        if (h == 3) goScreen(S_ARCADE); else if (h >= 0) startBall((u8)h);
        return;
    }
    if (state == ST_OVER) { s8 h = overInput(); if (h == 0) startBall(mach); else if (h == 1) goScreen(S_ARCADE); return; }
    u8 p = pauseCheck(); if (p == 1) return;
    if (p == 2) { panel(); winAt(7 + 104, 0); }
    if ((kDown & J_SELECT) && state == ST_READY && !resolved) { startBall((mach + 1) % 3); return; }
    if (state == ST_READY) {
        if ((kHeld & J_LEFT) && aim > -100) { aim -= 2; chargeT = 90; }
        if ((kHeld & J_RIGHT) && aim < 100) { aim += 2; chargeT = 90; }
        if (kDown & J_A) { charging = 1; ph = 0; power = 0; }
    }
    if (charging) {
        ph++; u8 t = ph % 44; power = t < 22 ? t * 11 : (44 - t) * 11;
        chargeT = 90;
        if (kDown & J_B) charging = 0;
        else if (kUp & J_A) { charging = 0; if (state == ST_READY) roll(); }
    }
    if (chargeT && !charging) chargeT--;
    step();
    if (state == ST_OVER) return;
    drawSprites();
}
