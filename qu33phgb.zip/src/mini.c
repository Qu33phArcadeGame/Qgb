// mini.c — MINI QU33PH (the website's mini.html): four mini markers slid up a lane of three
// tables, blue always last. The lane is seen from above; the website's physics and scoring, in
// whole numbers (u across the lane and v up it in 4096ths, speeds in 65536ths a frame).
#pragma bank 255
#include "qu.h"
#include "res_match.h"

#define ONE 4096
#define V_DESTINY 2048               // the seam between the first two tables
#define RAD 198                      // the marker's radius (0.048)
#define TOUCH_R 514
#define BOXV 3031                    // the MEGA case
#define BOXU 2048
#define BOXW 614
#define BOXH 184
enum { MC_GREEN, MC_PINK, MC_YELLOW, MC_BLUE };
typedef struct { s16 u, v, du, dv; u16 rot; s16 spin; u8 col, off, cap, hitByBlue, sndCd; } MM;
static MM mk[4];
static u8 nmk, order[4], idx, scored, st, sel; static s8 live = -1;
static u16 framesLeft, suddenAt; static u8 sudden, turnPause; static s16 score, turnPts; static u8 turn, newBest; static s16 coinsWon;
static s16 aimU = 2048; static s8 aimA; static u8 charging, chargeT, power, ph;
static char msg[4][19]; static u8 msgN, msgT;
enum { ST_MENU, ST_PLAY, ST_OVER };

static void say(const char *t) { if (msgN == 4) { for (u8 i = 0; i < 3; i++) strcpy(msg[i], msg[i + 1]); msgN = 3; } strncpy(msg[msgN], t, 18); msg[msgN][18] = 0; msgN++; msgT = 150; }
static void newTurn(void) {
    memset(mk, 0, sizeof mk); nmk = 0; live = -1; idx = 0; turnPts = 0; scored = 0;
    u8 three[3] = { MC_GREEN, MC_PINK, MC_YELLOW };
    for (u8 i = 2; i > 0; i--) { u8 j = rnd8() % (i + 1), t = three[i]; three[i] = three[j]; three[j] = t; }
    order[0] = three[0]; order[1] = three[1]; order[2] = three[2]; order[3] = MC_BLUE;
}
static s8 nextColor(void) { return idx < 4 ? (s8)order[idx] : -1; }
static void launch(void) {
    s8 col = nextColor(); if (col < 0 || live >= 0) return;
    MM *m = &mk[nmk]; memset(m, 0, sizeof *m);
    u8 p = power < 15 ? 15 : power;                                    // 0.06..1 as 15..255
    m->col = (u8)col; m->u = aimU; m->v = 82;
    // du = a * 0.52 * (0.5 + p) (+ a little scatter), dv = 0.55 + 1.52 p   (per second -> 65536ths a frame)
    m->du = (s16)(((s32)aimA * (128 + p) * 729) >> 15) + rndr(-27, 27);
    m->dv = 601 + (s16)(((u16)p * 1660) >> 8);
    m->rot = (u16)rndr(-1000, 1000); m->spin = rndr(-600, 600) * (1 + (p >> 7));
    m->cap = 1;
    live = (s8)nmk; nmk++; idx++;
    sfx(SFX_THROW);
}
static void fellOff(MM *m) {
    m->off = 1;
    s8 d;
    if (sudden) d = m->v > V_DESTINY ? 10 : 6;
    else if (m->col == MC_BLUE) d = m->v < V_DESTINY ? 10 : 0;
    else d = m->v < V_DESTINY ? 50 : 0;
    if (m->hitByBlue) d += 6;
    sfx(SFX_PEEF); say("PEEF");
    if (d) { turnPts -= d; strcpy(sbuf, "-"); itoa10(d, sbuf + 1); if (m->hitByBlue) strcat(sbuf, " KNOCKED"); say(sbuf); }
}
static void popCap(MM *m) {
    if (!m->cap) return;
    m->cap = 0; u8 d = m->col == MC_BLUE ? 6 : 3;
    turnPts -= d; say(m->col == MC_BLUE ? "-6 CAP OFF" : "-3 CAP OFF"); sfx(SFX_HIT);
}
static s16 absS(s16 v) { return v < 0 ? -v : v; }
static u8 touchingM(MM *a, MM *b) {
    s16 dx = absS(a->u - b->u), dy = absS(a->v - b->v);
    if (dx >= TOUCH_R || dy >= 161) return 0;                      // (dy x 3.2 against the radius)
    dy = (s16)(((u16)dy * 205) >> 6);                               // x 3.2
    return (u32)dx * dx + (u32)dy * dy < (u32)TOUCH_R * TOUCH_R;
}
static s16 scoreTable(void) {
    MM *on[4]; u8 n = 0;
    for (u8 i = 0; i < nmk; i++) if (!mk[i].off) on[n++] = &mk[i];
    u8 par[4] = { 0, 1, 2, 3 }, pairs = 0, bluePairs = 0;
    for (u8 i = 0; i < n; i++) for (u8 j = i + 1; j < n; j++) {
        if (!touchingM(on[i], on[j])) continue;
        pairs++;
        if (on[i]->col == MC_BLUE || on[j]->col == MC_BLUE) bluePairs++;
        u8 a = i, b = j; while (par[a] != a) a = par[a]; while (par[b] != b) b = par[b];
        if (a != b) par[a] = b;
    }
    u8 sizes[4] = { 0, 0, 0, 0 };
    for (u8 i = 0; i < n; i++) { u8 r = i; while (par[r] != r) r = par[r]; sizes[r]++; }
    s16 pts = 0;
    u8 k1 = sudden ? 6 : 1, k2 = sudden ? 10 : 3, k3 = sudden ? 15 : 5, k4 = sudden ? 20 : 10;
    if (pairs) { pts += pairs * k1; strcpy(sbuf, "TOUCHING X"); itoa10(pairs, sbuf + 10); say(sbuf); }
    if (bluePairs) { pts += bluePairs * k2; say(lbl("BLUE TOUCHING +", bluePairs * k2)); }
    for (u8 i = 0; i < 4; i++) { if (sizes[i] == 3) { pts += k3; say(lbl("THREE TOUCH +", k3)); } if (sizes[i] == 4) { pts += k4; say(sudden ? "ALL FOUR +20" : "QU33PH! +10"); sfx(SFX_GOOD); } }
    u8 mega = 0;
    for (u8 i = 0; i < n; i++) if (absS(on[i]->u - BOXU) < BOXW / 2 && absS(on[i]->v - BOXV) < BOXH / 2) mega++;
    if (mega) { pts += mega * 30; say(lbl("MEGA QU33PH +", mega * 30)); sfx(SFX_GOOD); }
    return pts;
}
static void endTurn(void) {
    turnPts += scoreTable();
    u8 extra = 0;
    if (turnPts >= 33) { turnPts += 10; extra = 1; }
    score += turnPts;
    if (turnPts == 0 && !msgN) say("NOTHING TOUCHING");
    strcpy(sbuf, turnPts >= 0 ? "+" : ""); itoa10(turnPts, sbuf + strlen(sbuf)); strcat(sbuf, " TURN "); itoa10(turn, sbuf + strlen(sbuf)); say(sbuf);
    if (extra) say("33+ EXTRA TURN +10"); else turn++;
    turnPause = 27;
}
static void gameOver(void) {
    live = -1; charging = 0; chargeT = 0;
    sv.arcadePlays[ARC_MINI]++;
    newBest = score > sv.arcadeBest[ARC_MINI];
    if (newBest) sv.arcadeBest[ARC_MINI] = score;
    coinsWon = score > 0 ? score / 10 : 0;
    if (coinsWon > 0) addCoins(coinsWon);
    saveWrite();
    st = ST_OVER;
    overDraw("TIME UP", lbl("POINTS ", score), newBest ? "NEW BEST!" : lbl("BEST ", sv.arcadeBest[ARC_MINI]), 0);
    txtC(9, lbl("+", coinsWon), PAL_GOLD); txt(12, 9, "COINS", PAL_GOLD);
}

// ── physics: the website's step(), at 60 a second ─────────────────────────
static s16 drag(s16 v) { if (v < 0) { u16 a = -v; return -(s16)(a - (a >> 5) - (a >> 8)); } { u16 a = v; return a - (a >> 5) - (a >> 8); } }   // x 0.9648
static void step(void) {
    if (framesLeft) framesLeft--;
    if (!sudden && framesLeft <= suddenAt) { sudden = 1; say("SUDDEN DEATH"); sfx(SFX_BAD); }
    if (!framesLeft) { gameOver(); return; }
    u8 moving = 0;
    for (u8 i = 0; i < nmk; i++) {
        MM *m = &mk[i];
        if (m->off) continue;
        if (m->sndCd) m->sndCd--;
        m->u += m->du >> 4; m->v += m->dv >> 4;
        m->rot += (u16)m->spin; m->spin -= m->spin >> 5;
        m->du = drag(m->du); m->dv = drag(m->dv);
        if (absS(m->du) + absS(m->dv) < 49) { m->du = m->dv = 0; m->spin -= m->spin >> 2; } else moving = 1;
        if (sudden) for (u8 c = 0; c < 2; c++) {                       // the chairs are solid
            s16 cv = c ? 3523 : 2540;
            if (absS(m->u - 2048) < 348 + RAD && absS(m->v - cv) < 92 + RAD) {
                s8 push = m->u < 2048 ? -1 : 1; s16 pre = m->dv;
                m->u = 2048 + push * (348 + RAD); m->du = (s16)((absS(m->du) * 9) >> 4) * push; m->spin += push * 400;
                if (!m->sndCd) { sfx(SFX_HIT); m->sndCd = 5; }
                if (absS(pre) > 1201) popCap(m);
            }
        }
        if (m->v > ONE - RAD) {                                        // the far end is a wall
            m->v = ONE - RAD;
            if (m->dv > 0) {
                s16 pre = m->dv;
                m->dv = -(s16)(((u16)m->dv * 108) >> 8);
                m->spin += rndr(-300, 300);
                if (!m->sndCd) { sfx(SFX_WALL); m->sndCd = 5; }
                if (pre > 1474) popCap(m);
            }
        }
        if (m->u < -82 || m->u > ONE + 82) { fellOff(m); if ((s8)i == live) live = -1; }
    }
    for (u8 i = 0; i < nmk; i++) for (u8 j = i + 1; j < nmk; j++) {    // marker on marker
        MM *a = &mk[i], *b = &mk[j]; if (a->off || b->off) continue;
        s16 dx = a->u - b->u, dy = (a->v - b->v) * 4;
        if (absS(dx) >= RAD * 2 || absS(dy) >= RAD * 2) continue;
        u16 d = isqrt32((u32)((s32)dx * dx) + (u32)((s32)dy * dy));
        if (d >= RAD * 2 || !d) continue;
        s16 nx = (s16)(((s32)dx << 8) / d), ny = (s16)(((s32)dy << 8) / d);   // unit x 256
        s16 ov = (RAD * 2 - (s16)d) / 2;
        a->u += (nx * ov) >> 8; a->v += ((ny * ov) >> 8) / 4; b->u -= (nx * ov) >> 8; b->v -= ((ny * ov) >> 8) / 4;
        s32 sep = ((s32)(a->du - b->du) * nx + (s32)(a->dv - b->dv) * 4 * ny) >> 8;
        if (sep < 0) {
            s32 imp = (sep * 220) >> 8;                                   // x 0.86
            a->du -= (s16)((imp * nx) >> 8); a->dv -= (s16)(((imp * ny) >> 8) / 4); b->du += (s16)((imp * nx) >> 8); b->dv += (s16)(((imp * ny) >> 8) / 4);
            a->spin += rndr(-800, 800); b->spin += rndr(-800, 800);
            if (!a->sndCd && !b->sndCd) { sfx(SFX_HIT); a->sndCd = b->sndCd = 5; }
            if (sep < -98) { if ((rnd8() & 7) < 3) popCap(a); if ((rnd8() & 7) < 3) popCap(b); }
            if (a->col == MC_BLUE) b->hitByBlue = 1;
            if (b->col == MC_BLUE) a->hitByBlue = 1;
            moving = 1;
        }
    }
    if (live >= 0 && !moving) live = -1;
    if (turnPause) { if (--turnPause == 0) newTurn(); }
    else if (live < 0 && idx >= 4 && !moving && nmk && !scored) { scored = 1; endTurn(); }
    if (msgT && --msgT == 0) msgN = 0;
}

// ── the screen ────────────────────────────────────────────────────────────
#define LX 16
static s16 sx(s16 u) { return LX + (u >> 6); }
static s16 sy(s16 v) { return 144 - (s16)(((s32)v * 17) >> 9); }
static u8 panelSecs = 255, panelMsgs = 255; static s16 panelScore = -9999; static u8 panelTurn = 255, panelSD = 255;
static void panel(u8 all) {
    if (all) { fillWin(0, 0, 9, 18, BLANK, PAL_TEXT); for (u8 y = 0; y < 18; y++) wput(0, y, UI_L, PAL_GREY); panelSecs = panelMsgs = panelTurn = panelSD = 255; panelScore = -9999;
               wtxt(1, 16, "UP/DN:AIM", PAL_GREY); wtxt(1, 17, "HOLD A", PAL_GREY); }
    u8 secs = (u8)((framesLeft + 59) / 60);
    if (secs != panelSecs || sudden != panelSD) { panelSecs = secs; panelSD = sudden; fillWin(1, 0, 8, 1, BLANK, PAL_TEXT); wnum(1, 0, secs, 3, sudden ? PAL_RED : PAL_GOLD); wtxt(5, 0, sudden ? "SD" : "S", sudden ? PAL_RED : PAL_GREY); }
    if (score != panelScore) { panelScore = score; fillWin(1, 1, 8, 1, BLANK, PAL_TEXT); wtxt(1, 1, lbl("PTS ", score), score < 0 ? PAL_RED : PAL_TEXT); }
    if (turn != panelTurn) { panelTurn = turn; wtxt(1, 2, lbl("TURN ", turn), PAL_BLUE); wtxt(1, 3, lbl("BEST ", sv.arcadeBest[ARC_MINI]), PAL_GREY); }
    u8 m = msgT ? msgN : 0;
    if (m != panelMsgs) {
        panelMsgs = m;
        fillWin(1, 5, 8, 8, BLANK, PAL_TEXT);
        for (u8 i = 0; i < m; i++) {                               // each message over two short lines
            char a[9]; strncpy(a, msg[i], 8); a[8] = 0; wtxt(1, 5 + i * 2, a, PAL_TEXT);
            if (strlen(msg[i]) > 8) wtxt(1, 6 + i * 2, msg[i] + 8, PAL_TEXT);
        }
    }
}
static void playScreen(void) {
    screenFresh();
    loadBkgTilesBanked(BANK(res_match), SCENE_T, MATCH_TILE_COUNT, match_tiles);
    static const u16 LANE_PAL[4] = { RGB8(222, 184, 135), RGB8(200, 160, 110), RGB8(120, 80, 40), RGB8(40, 30, 25) };
    setBkgPal(PAL_S1, LANE_PAL);
    fillBkg(0, 0, 11, 18, SCENE_T + 6, PAL_S1);                       // the floor
    fillBkg(2, 1, 8, 17, SCENE_T, PAL_S1);                            // the lane
    fillBkg(1, 1, 1, 17, SCENE_T + 2, PAL_S1); fillBkg(10, 1, 1, 17, SCENE_T + 11, PAL_S1);
    fillBkg(2, 9, 8, 1, SCENE_T + 4, PAL_S1);                         // the seam between the first tables
    fillBkg(2, 5, 8, 1, SCENE_T + 4, PAL_S1);                         // and the second and third
    fillBkg(5, 4, 2, 1, UI_SOLID2, PAL_GOLD);                         // the MEGA case
    panel(1); winAt(7 + 88, 0);
    lcdOn();
}
static void start(void) {
    framesLeft = 60 * 60; suddenAt = framesLeft / 5;
    sudden = 0; score = 0; turn = 1; coinsWon = 0; newBest = 0; turnPause = 0; msgN = 0; msgT = 0;
    newTurn(); charging = 0; chargeT = 0; st = ST_PLAY;
    playScreen();
}
static const u8 MKIND[4] = { 0, 1, 2, 3 };    // green, pink, yellow, blue
static void drawSprites(void) {
    u8 ready = live < 0 && nextColor() >= 0 && !turnPause;
    if (ready && (charging || chargeT)) {                               // where it would slide
        s16 u = aimU, v = 82; u8 p = charging ? power : 128;
        s16 du = (s16)(((s32)aimA * (128 + p) * 729) >> 15), dv = 601 + (s16)(((u16)p * 1660) >> 8);
        for (u8 f = 1; f <= 36; f++) {
            u += du >> 4; v += dv >> 4; du = drag(du); dv = drag(dv);
            if (f % 6 == 0) spr(sx(u) - 4, sy(v) - 4, UI_DOT, 0);
        }
        if (charging) { u8 a = atan2i(-(s16)dv, du); powerMarker(sx(aimU), sy(82), a, 12 + (power >> 3), power); }
    }
    if (ready) miniMarker(sx(aimU), sy(82), MKIND[order[idx]], 64);
    for (u8 i = 0; i < nmk; i++) if (!mk[i].off) miniMarker(sx(mk[i].u), sy(mk[i].v), MKIND[mk[i].col], (u8)(mk[i].rot >> 8));
    if (sudden) { spr16(LX + 32, sy(2540), ST_CHAIR, isCGB ? OP_RED : 0); spr16(LX + 32, sy(3523), ST_CHAIR, isCGB ? OP_RED : 0); }
    for (u8 i = idx + ready, k = 0; i < 4; i++, k++) miniMarker(108 + k * 10, 108, MKIND[order[i]], 64);   // still to throw
}

static const char * const MENU_ITEMS[4] = { "60 SECONDS", "90 SECONDS", "120 SECONDS", "BACK" };
static const char * const RULES[8] = { "4 MINI MARKERS,", "BLUE ALWAYS LAST.", "ALL 4 TOUCH: QU33PH", "ON THE CASE: MEGA+30",
    "OFF A SIDE COSTS,", "BLUE OFF EARLY MOST.", "LAST FIFTH: SUDDEN", "DEATH (CHAIRS!)" };
void miniEnter(void) BANKED { }
void miniUpdate(void) BANKED {
    if (entering) {
        st = ST_MENU; sel = 0;
        screenFresh(); txtC(0, "MINI QU33PH", PAL_GOLD);
        for (u8 i = 0; i < 8; i++) txt(0, 2 + i, RULES[i], i == 1 ? PAL_BLUE : i >= 6 ? PAL_RED : PAL_TEXT);
        if (sv.arcadePlays[ARC_MINI]) txtC(17, lbl("BEST ", sv.arcadeBest[ARC_MINI]), PAL_GOLD);
        lcdOn();
    }
    music(MUS_MINI);
    if (st == ST_MENU) {
        if (kDown & J_B) { goScreen(S_ARCADE); return; }
        s8 h = menuList(3, 11, 4, MENU_ITEMS, &sel, 1);
        if (h == 3) goScreen(S_ARCADE);
        else if (h >= 0) { start(); framesLeft = (u16)(60 + h * 30) * 60; suddenAt = framesLeft / 5; }
        return;
    }
    if (st == ST_OVER) { s8 h = overInput(); if (h == 0) { entering = 1; miniUpdate(); } else if (h == 1) goScreen(S_ARCADE); return; }
    u8 p = pauseCheck();
    if (p == 1) return;
    if (p == 2) { panel(1); winAt(7 + 88, 0); }
    // walk the throw spot along the near edge, angle it (up/down), hold A for power
    u8 canThrow = live < 0 && nextColor() >= 0 && !turnPause;
    if (canThrow) {
        if (kHeld & J_LEFT) { aimU -= 31; if (aimU < 246) aimU = 246; chargeT = 90; }
        if (kHeld & J_RIGHT) { aimU += 31; if (aimU > 3850) aimU = 3850; chargeT = 90; }
        if ((kHeld & J_UP) && aimA < 100) { aimA += 2; chargeT = 90; }
        if ((kHeld & J_DOWN) && aimA > -100) { aimA -= 2; chargeT = 90; }
        if (kDown & J_A) { charging = 1; ph = 0; power = 0; }
    }
    if (charging) {
        ph++; u8 t = ph % 44; power = t < 22 ? t * 11 : (44 - t) * 11;
        chargeT = 90;
        if (kDown & J_B) charging = 0;
        else if (kUp & J_A) { charging = 0; if (canThrow) launch(); }
    }
    if (chargeT && !charging) chargeT--;
    step();
    if (st != ST_PLAY) return;
    panel(0);
    drawSprites();
}
