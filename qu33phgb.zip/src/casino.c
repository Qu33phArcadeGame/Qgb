// casino.c — the slot machine and PlinQu33ph (the GBA's rules and odds)
#pragma bank 255
#include "qu.h"
#include "res_casino.inc"

// ══ SLOT MACHINE ══════════════════════════════════════════════════════════
enum { Y_LOGO, Y_MEGA, Y_COIN, Y_CHAIR, Y_RED, Y_GREEN, Y_BLUE };
static const u8 WEIGHT[7] = { 1, 2, 4, 5, 8, 8, 8 };
typedef struct { s8 s[3]; u8 win; const char *label; } Pay;   // -1 = any symbol
static const Pay PAYS[] = {
    { { Y_LOGO, Y_LOGO, Y_LOGO }, 200, "JACKPOT" }, { { Y_MEGA, Y_MEGA, Y_MEGA }, 50, "MEGA QU33PH" },
    { { Y_COIN, Y_COIN, Y_COIN }, 30, "TRIPLE COIN" }, { { Y_CHAIR, Y_CHAIR, Y_CHAIR }, 20, "CHAIR SPIN" },
    { { Y_LOGO, Y_LOGO, -1 }, 15, "DOUBLE LOGO" }, { { Y_MEGA, Y_MEGA, -1 }, 8, "DOUBLE MEGA" },
    { { Y_CHAIR, Y_CHAIR, -1 }, 6, "DOUBLE CHAIR" }, { { Y_COIN, Y_COIN, -1 }, 5, "DOUBLE COIN" },
    { { Y_RED, Y_RED, Y_RED }, 4, "RED TRIPLE" }, { { Y_GREEN, Y_GREEN, Y_GREEN }, 4, "GREEN TRIPLE" },
    { { Y_BLUE, Y_BLUE, Y_BLUE }, 4, "BLUE TRIPLE" }, { { -1, Y_LOGO, -1 }, 3, "ANY LOGO" },
    { { Y_RED, Y_RED, -1 }, 2, "DOUBLE RED" }, { { Y_GREEN, Y_GREEN, -1 }, 2, "DOUBLE GREEN" },
    { { Y_BLUE, Y_BLUE, -1 }, 2, "DOUBLE BLUE" }, { { -1, Y_COIN, -1 }, 2, "ANY COIN" }, { { -1, Y_CHAIR, -1 }, 1, "ANY CHAIR" } };
static u8 reel[3] = { Y_LOGO, Y_MEGA, Y_COIN }, result[3], spinT, spinBet, sel, payShow; static s16 lastWin; static const char *lastLabel = "";
static u8 pickSym(void) { u8 r = rnd8() % 36; for (u8 i = 0; i < 7; i++) { if (r < WEIGHT[i]) return i; r -= WEIGHT[i]; } return Y_BLUE; }
static u8 checkWin(const u8 *r, const char **label) {
    u8 m0 = r[0] >= Y_RED, m1 = r[1] >= Y_RED, m2 = r[2] >= Y_RED;
    if (m0 && m1 && m2 && r[0] != r[1] && r[1] != r[2] && r[0] != r[2]) {
        if (r[2] == Y_BLUE) { *label = "TRIO BLUE 3RD"; return 10; }
        *label = "TRIO ANY ORDER"; return 6;
    }
    for (u8 k = 0; k < sizeof PAYS / sizeof PAYS[0]; k++) {
        u8 ok = 1; for (u8 i = 0; i < 3; i++) if (PAYS[k].s[i] >= 0 && (u8)PAYS[k].s[i] != r[i]) ok = 0;
        if (ok) { *label = PAYS[k].label; return PAYS[k].win; }
    }
    *label = ""; return 0;
}
static void drawReel(u8 i) {
    u8 t[4], a[4], s = reel[i];
    for (u8 k = 0; k < 4; k++) { t[k] = SCENE_T + sym_map[s * 4 + k]; a[k] = 5 + sym_attr[s * 4 + k]; }
    u8 x = 5 + i * 4;
    setBkgMap(x, 4, 2, 1, t, a); setBkgMap(x, 5, 2, 1, t + 2, a + 2);
}
static void slotStatus(void) {
    fillBkg(1, 9, 18, 1, BLANK, PAL_TEXT);
    if (lastWin) { strcpy(sbuf, lastLabel); txtC(9, sbuf, PAL_GREEN); fillBkg(1, 10, 18, 1, BLANK, PAL_TEXT); txtC(10, lbl("+", lastWin), PAL_GREEN); }
    else { fillBkg(1, 10, 18, 1, BLANK, PAL_TEXT); if (lastLabel[0]) txtC(9, lastLabel, PAL_TEXT); }
    fillBkg(0, 1, 20, 1, BLANK, PAL_TEXT);
    put(6, 1, UI_COIN, PAL_GOLD); txt(8, 1, lbl("", sv.coins), PAL_GOLD);
}
static void spin(u8 bet) {
    if (spinT) return;
    if (sv.coins < bet) { lastLabel = "NOT ENOUGH COINS"; lastWin = 0; slotStatus(); sfx(SFX_BAD); return; }
    spendCoins(bet); spinBet = bet; spinT = 26; lastWin = 0; lastLabel = "";
    for (u8 i = 0; i < 3; i++) result[i] = pickSym();
    sv.slotSpins++; sfx(SFX_THROW);
    slotStatus();
}
static const char * const SLOT_ITEMS[4] = { "SPIN 1", "SPIN 3", "PAYS", "BACK" };
static const char * const PAYTXT[13] = { "LOGO X3        200", "MEGA X3         50", "COIN X3         30", "CHAIR X3        20",
    "2 LOGOS         15", "R G B,BLUE LAST 10", "2 MEGA           8", "OTHER TRIO       6", "2 CHAIRS         6", "2 COINS          5",
    "ONE COLOUR X3    4", "LOGO MIDDLE      3", "PAIR/COIN MID 2/1" };
static void slotScreen(void) {
    screenFresh();
    loadBkgTiles(SCENE_T, SYM_TILES, sym_tiles);
    if (isCGB) set_bkg_palette(5, SYM_PALS, sym_pals);
    txtC(0, "QU33PH SLOTS", PAL_GOLD);
    box(2, 3, 16, 4, PAL_GOLD);
    for (u8 i = 0; i < 3; i++) drawReel(i);
    slotStatus();
    txt(1, 17, "PAYS X YOUR BET", PAL_GREY);
    lcdOn();
}
static void updateSlot(void) {
    if (entering) { slotScreen(); sel = 0; payShow = 0; }
    music(MUS_ARCADE);
    if (payShow) {
        if (kDown & (J_A | J_B)) { payShow = 0; slotScreen(); entering = 1; }
        return;
    }
    if (spinT) {
        spinT--;
        for (u8 i = 0; i < 3; i++) { u8 stopAt = 18 - i * 8; u8 r = spinT > stopAt ? rnd8() % 7 : result[i]; if (r != reel[i] || spinT == stopAt) { reel[i] = r; drawReel(i); if (spinT == stopAt) sfx(SFX_HIT); } }
        if (!spinT) {
            u8 w = checkWin(result, &lastLabel);
            if (w) { lastWin = (s16)w * spinBet; addCoins(lastWin); sv.slotWins++; sfx(w >= 15 ? SFX_GOOD : SFX_COIN); }
            else sv.slotLost += spinBet;
            saveWrite(); slotStatus();
        }
    }
    if (kDown & J_B) { goScreen(S_TITLE); return; }
    s8 h = menuList(6, 12, 4, SLOT_ITEMS, &sel, 1);
    if (h == 0) spin(1);
    if (h == 1) spin(3);
    if (h == 2 && !spinT) {
        payShow = 1; screenFresh(); txtC(0, "PAYS X YOUR BET", PAL_GOLD);
        for (u8 i = 0; i < 13; i++) txt(1, 2 + i, PAYTXT[i], i ? PAL_TEXT : PAL_GOLD);
        txtC(16, "A BACK", PAL_GREY); lcdOn();
    }
    if (h == 3) goScreen(S_TITLE);
}

// ══ PLINQU33PH ════════════════════════════════════════════════════════════
// The GBA's board in its own units (256 x 192), on screen at half width; pegs land on the tiles.
static const u8 BINS[7] = { 1, 2, 5, 10, 5, 2, 1 };
#define PEG_ROWS 7
typedef struct { s16 x, y, vx, vy; u16 rot; s16 spin; u8 live, done, bin; } Ball;   // x, y in 1/16 units; v in 1/256
static Ball balls[3]; static u8 dropIdx, paid, plWin, plMsgT; static s16 aimX = 128; static const char *plMsg = "";
static s16 pegX(u8 r, u8 c) { return 18 + c * 32 + (r & 1 ? 16 : 0); }
static s16 pegY(u8 r) { return 34 + r * 18; }
static u8 pegCount(u8 r) { return r & 1 ? 7 : 8; }
static s16 scrX(s16 x16) { return x16 >> 5; }                                        // x / 2
static s16 scrY(s16 y16) { s16 y = y16 >> 4; return 12 + (((y - 34) * 4) / 9); }       // pegs 8 px apart
static void plinkoNew(void) { dropIdx = 0; paid = 0; plWin = 0; memset(balls, 0, sizeof balls); }
static void plinkoPanel(void) {
    fillBkg(16, 0, 4, 18, BLANK, PAL_TEXT);
    put(16, 1, UI_COIN, PAL_GOLD); num(16, 2, sv.coins, 4, PAL_GOLD);
    txt(16, 4, "WON", PAL_GREY); num(16, 5, plWin, 4, PAL_GREEN);
    txt(16, 8, "5 A", PAL_GREY); txt(16, 9, "SET", PAL_GREY);
    txt(16, 12, "A", PAL_GOLD); txt(16, 13, "DROP", PAL_GREY);
    txt(16, 15, "B", PAL_GOLD); txt(16, 16, "BACK", PAL_GREY);
}
static void plinkoScreen(void) {
    screenFresh();
    loadBkgTiles(SCENE_T, 1, peg_tile);
    for (u8 r = 0; r < PEG_ROWS; r++) for (u8 c = 0; c < pegCount(r); c++) put((u8)(pegX(r, c) / 16), 1 + r, SCENE_T, PAL_TEXT);
    static const u8 BX[7] = { 1, 3, 5, 8, 10, 12, 14 };
    for (u8 i = 0; i < 7; i++) { num(BX[i] - (BINS[i] == 10), 10, BINS[i], BINS[i] == 10 ? 2 : 1, BINS[i] == 10 ? PAL_GOLD : PAL_TEXT); }
    for (u8 x = 0; x < 16; x++) put(x, 11, UI_T, PAL_GREY);
    plinkoPanel();
    lcdOn();
}
static void drop(void) {
    if (dropIdx >= 3) { for (u8 i = 0; i < 3; i++) if (balls[i].live) return; plinkoNew(); return; }
    if (!paid) { if (sv.coins < 5) { plMsg = "NEED 5 COINS"; plMsgT = 90; sfx(SFX_BAD); return; } spendCoins(5); paid = 1; plinkoPanel(); }
    Ball *b = &balls[dropIdx++];
    b->x = aimX * 16; b->y = 10 * 16; b->vx = rndr(-77, 77); b->vy = 0; b->live = 1; b->done = 0;
    b->rot = 64 << 8; b->spin = rndr(-1000, 1000);
    sfx(SFX_THROW);
}
static void updatePlinko(void) {
    for (u8 i = 0; i < 3; i++) {
        Ball *b = &balls[i]; if (!b->live) continue;
        b->vy += 41;                                         // 0.16 a frame
        b->x += b->vx >> 4; b->y += b->vy >> 4;
        b->vx -= b->vx >> 7;
        b->rot += (u16)b->spin; b->spin -= b->spin >> 6;
        s16 by = b->y >> 4, bx = b->x >> 4;
        s8 rn = (s8)((by - 34 + 9) / 18);
        for (s8 r = rn - 1; r <= rn; r++) { if (r < 0 || r >= PEG_ROWS) continue;
            s16 pdy = by - pegY(r); if (pdy > 9 || pdy < -9) continue;
            s8 c0 = (s8)((bx - 18 - (r & 1 ? 16 : 0)) / 32);
            for (s8 c = c0; c <= c0 + 1; c++) { if (c < 0 || c >= pegCount(r)) continue;
                s16 dx = b->x - pegX(r, c) * 16, dy = b->y - pegY(r) * 16;     // 1/16 units: within 144
                if (dx > 144 || dx < -144 || dy > 144 || dy < -144) continue;
                u16 d2 = (u16)(dx * dx) + (u16)(dy * dy);
                if (d2 < 144 * 144 && d2 > 4) {                                 // ball radius 6 + peg 3
                    u16 d = isqrt32(d2); if (!d) d = 1;
                    s16 nx = (dx * 64) / (s16)d, ny = (dy * 64) / (s16)d;        // unit normal x 64
                    b->x = pegX(r, c) * 16 + nx * 9 / 4; b->y = pegY(r) * 16 + ny * 9 / 4;
                    s16 rel = (s16)(((s32)b->vx * nx + (s32)b->vy * ny) >> 6);
                    if (rel < 0) { b->vx -= (s16)(((s32)rel * nx * 3) >> 7); b->vy -= (s16)(((s32)rel * ny * 3) >> 7); }   // x 1.5
                    b->vx += rndr(-64, 64);
                    b->spin += (s16)(((s32)b->vx * ny - (s32)b->vy * nx) >> 3);
                    if (b->spin > 4000) b->spin = 4000;
                    if (b->spin < -4000) b->spin = -4000;
                    sfx(SFX_PIN);
                }
            } }
        if (b->x < 6 * 16) { b->x = 6 * 16; b->vx = -b->vx / 2; }
        if (b->x > 250 * 16) { b->x = 250 * 16; b->vx = -b->vx / 2; }
        if (b->y > 172 * 16) {
            u8 bin = (u8)((u16)(b->x >> 4) * 7 / 256); if (bin > 6) bin = 6;
            u8 under = 0; for (u8 k = 0; k < 3; k++) if (k != i && balls[k].done && balls[k].bin == bin) under++;
            b->live = 0; b->done = 1; b->bin = bin; b->y = (178 - under * 7) * 16;
            addCoins(BINS[bin]); plWin += BINS[bin]; sfx(SFX_COIN);
            if (balls[0].done && balls[1].done && balls[2].done) {
                u8 pairs = (balls[0].bin == balls[1].bin) + (balls[0].bin == balls[2].bin) + (balls[1].bin == balls[2].bin);
                u8 bonus = pairs >= 3 ? 25 : pairs ? 10 : 0;
                if (bonus) { addCoins(bonus); plWin += bonus; plMsg = pairs >= 3 ? "ALL 3 TOUCH +25" : "TOUCH +10"; plMsgT = 150; sfx(SFX_GOOD); }
                saveWrite();
            }
            plinkoPanel();
        }
    }
}
static const u8 PL_KIND[3] = { 1, 0, 3 };   // red, green, blue
static void plinkoUpdate(void) {
    if (entering) { plinkoScreen(); plinkoNew(); }
    music(MUS_ARCADE);
    if (kDown & J_B) { goScreen(S_TITLE); return; }
    if (kHeld & J_LEFT) aimX -= 3;
    if (kHeld & J_RIGHT) aimX += 3;
    if (aimX < 10) aimX = 10;
    if (aimX > 246) aimX = 246;
    if (kDown & J_A) drop();
    updatePlinko();
    for (u8 i = 0; i < 3; i++) if (balls[i].live || balls[i].done) miniMarker(scrX(balls[i].x), scrY(balls[i].y), PL_KIND[i], (u8)(balls[i].rot >> 8));
    if (dropIdx < 3) { miniMarker(aimX >> 1, 4, PL_KIND[dropIdx], 64); spr((aimX >> 1) - 4, 10, UI_CURSOR, 0); }
    else { u8 live = 0; for (u8 i = 0; i < 3; i++) live |= balls[i].live; if (!live) sprText(8, 104, "A:AGAIN", isCGB ? OP_WHITE : 0); }
    if (plMsgT) { plMsgT--; sprText(8, 120, plMsg, isCGB ? OP_WHITE : 0); }
}

void casinoEnter(void) BANKED { }
void casinoUpdate(void) BANKED { if (screen == S_SLOT) updateSlot(); else plinkoUpdate(); }
