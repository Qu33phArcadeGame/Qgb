// engine.c — the screen, buttons, text, sprites and maths every part of the game uses.
// (In the always-there bank: any bank's code can call it.)
#include "qu.h"
#include "res_core.h"

u8 isCGB, kDown, kHeld, kUp, nSpr;
static u8 prevKeys;

// ── the vertical blank: sound runs here so it never stutters ──────────────
static void vblankIsr(void) { soundTick(); }

void engineInit(void) {
    isCGB = (_cpu == CGB_TYPE);
    if (isCGB) cpu_fast();                       // the Color's double speed: the same game, more headroom
    DISPLAY_OFF;
    // background + window tiles from 0x8800 (256 of them), background map 0x9800, window map 0x9C00,
    // 8x8 sprites: LCD on | window map 9C00 | window on | BG tiles 8800 | BG map 9800 | 8x8 | sprites | BG
    LCDC_REG = 0x80 | 0x40 | 0x20 | 0x02 | 0x01;
    BGP_REG = 0xE4;                              // 0 white, 1 light, 2 dark, 3 black
    OBP0_REG = 0xD0;                             // sprites: 1 white, 2 light grey, 3 black
    OBP1_REG = 0xE0;                             //          1 white, 2 dark grey,  3 black
    loadBkgTiles(FONT_T, 64, font_tiles);
    loadBkgTiles(UI_SOLID1, UI_TILE_COUNT, ui_tiles);
    loadSprTiles(ST_MARK, 40, mark_tiles);
    loadSprTiles(ST_MINI, MINI_TILE_COUNT, mini_tiles);
    loadSprTiles(ST_PWR, 3, pwr_tiles);
    loadSprTiles(ST_CHAIR, 4, chair_tiles);
    uiPalettes();
    winAt(255, 0);
    for (u8 i = 0; i < 40; i++) shadow_OAM[i].y = 0;
    CRITICAL { add_VBL(vblankIsr); }
    set_interrupts(VBL_IFLAG);
    enable_interrupts();
    DISPLAY_ON;
}
void lcdOff(void) { DISPLAY_OFF; }
void lcdOn(void) { DISPLAY_ON; }

void frameBegin(void) {
    vsync();
    u8 k = joypad();
    kDown = k & ~prevKeys; kUp = ~k & prevKeys; kHeld = k; prevKeys = k;
    nSpr = 0;
}
static u8 lastSpr = 40;
void frameEnd(void) {
    // hide the sprites used last frame but not this one
    u8 *p = &shadow_OAM[nSpr].y;
    for (u8 i = nSpr; i < lastSpr; i++, p += 4) *p = 0;
    lastSpr = nSpr;
}

// ── tiles into video memory ───────────────────────────────────────────────
// (background tile t lives at 0x9000 + t*16 for t < 128, else at 0x8800 + (t-128)*16)
void loadBkgTiles(u8 first, u8 n, const u8 *data) {
    while (n) {
        u8 *dst = first < 128 ? (u8 *)0x9000 + (u16)first * 16 : (u8 *)0x8800 + (u16)(first - 128) * 16;
        u8 run = first < 128 ? (u8)(128 - first) : (u8)(256 - first); if (run > n || run == 0) run = n;
        set_data(dst, data, (u16)run * 16);
        data += (u16)run * 16; first += run; n -= run;
    }
}
void loadSprTiles(u8 first, u8 n, const u8 *data) { set_data((u8 *)0x8000 + (u16)first * 16, data, (u16)n * 16); }
void loadBkgTilesBanked(u8 bank, u8 first, u8 n, const u8 *data) NONBANKED {
    u8 save = CURRENT_BANK; SWITCH_ROM(bank); loadBkgTiles(first, n, data); SWITCH_ROM(save);
}
void loadSprTilesBanked(u8 bank, u8 first, u8 n, const u8 *data) NONBANKED {
    u8 save = CURRENT_BANK; SWITCH_ROM(bank); loadSprTiles(first, n, data); SWITCH_ROM(save);
}

// ── maps ──────────────────────────────────────────────────────────────────
static u8 row[32];
static void attrs(u8 x, u8 y, u8 w, u8 h, u8 pal, u8 win) {
    if (!isCGB) return;
    memset(row, pal, 32);
    VBK_REG = VBK_ATTRIBUTES;
    for (u8 j = 0; j < h; j++) { if (win) set_win_tiles(x, y + j, w, 1, row); else set_bkg_tiles(x, y + j, w, 1, row); }
    VBK_REG = VBK_TILES;
}
void fillBkg(u8 x, u8 y, u8 w, u8 h, u8 tile, u8 pal) {
    memset(row, tile, 32);
    for (u8 j = 0; j < h; j++) set_bkg_tiles(x, y + j, w, 1, row);
    attrs(x, y, w, h, pal, 0);
}
void fillWin(u8 x, u8 y, u8 w, u8 h, u8 tile, u8 pal) {
    memset(row, tile, 32);
    for (u8 j = 0; j < h; j++) set_win_tiles(x, y + j, w, 1, row);
    attrs(x, y, w, h, pal, 1);
}
void clearBkg(u8 tile, u8 pal) { fillBkg(0, 0, 32, 32, tile, pal); }
void clearWin(u8 tile, u8 pal) { fillWin(0, 0, 32, 18, tile, pal); }
void put(u8 x, u8 y, u8 tile, u8 pal) {
    set_bkg_tile_xy(x, y, tile);
    if (isCGB) { VBK_REG = VBK_ATTRIBUTES; set_bkg_tile_xy(x, y, pal); VBK_REG = VBK_TILES; }
}
void wput(u8 x, u8 y, u8 tile, u8 pal) {
    set_win_tile_xy(x, y, tile);
    if (isCGB) { VBK_REG = VBK_ATTRIBUTES; set_win_tile_xy(x, y, pal); VBK_REG = VBK_TILES; }
}
void setBkgMap(u8 x, u8 y, u8 w, u8 h, const u8 *tiles, const u8 *at) {
    set_bkg_tiles(x, y, w, h, tiles);
    if (isCGB && at) { VBK_REG = VBK_ATTRIBUTES; set_bkg_tiles(x, y, w, h, at); VBK_REG = VBK_TILES; }
}
void setBkgMapBanked(u8 bank, u8 x, u8 y, u8 w, u8 h, const u8 *tiles, const u8 *at) NONBANKED {
    u8 save = CURRENT_BANK; SWITCH_ROM(bank); setBkgMap(x, y, w, h, tiles, at); SWITCH_ROM(save);
}
void scroll(u8 x, u8 y) { SCX_REG = x; SCY_REG = y; }
void winAt(u8 x, u8 y) { if (x == 255) { WX_REG = 166; WY_REG = 145; HIDE_WIN; return; } WX_REG = x; WY_REG = y; SHOW_WIN; }

// ── text ──────────────────────────────────────────────────────────────────
static u8 tbuf[32];
static u8 toTiles(const char *s) {
    u8 n = 0;
    while (*s && n < 32) {
        u8 c = (u8)*s++;
        if (c >= 'a' && c <= 'z') c -= 32;
        if (c < 32 || c > 95) c = '?';
        tbuf[n++] = CH(c);
    }
    return n;
}
void txt(u8 x, u8 y, const char *s, u8 pal) {
    u8 n = toTiles(s); if (!n) return;
    set_bkg_tiles(x, y, n, 1, tbuf);
    attrs(x, y, n, 1, pal, 0);
}
void wtxt(u8 x, u8 y, const char *s, u8 pal) {
    u8 n = toTiles(s); if (!n) return;
    set_win_tiles(x, y, n, 1, tbuf);
    attrs(x, y, n, 1, pal, 1);
}
void txtCW(u8 x0, u8 w, u8 y, const char *s, u8 pal) { u8 n = (u8)strlen(s); txt(n < w ? x0 + (w - n) / 2 : x0, y, s, pal); }
void txtC(u8 y, const char *s, u8 pal) { txtCW(0, 20, y, s, pal); }
char *itoa10(s32 v, char *buf) {
    char t[12]; u8 n = 0, neg = v < 0; u32 u = neg ? (u32)(-v) : (u32)v;
    while (u > 65535UL) { t[n++] = '0' + (u8)(u % 10); u /= 10; }      // (the long way only for big numbers)
    u16 w = (u16)u;
    do { u16 q = w / 10; t[n++] = '0' + (u8)(w - q * 10); w = q; } while (w);
    char *p = buf; if (neg) *p++ = '-';
    while (n) *p++ = t[--n];
    *p = 0; return buf;
}
static char nbuf[16];
static void numStr(s32 v, u8 width) {
    char t[12]; itoa10(v, t); u8 n = (u8)strlen(t), k = 0;
    while (n + k < width && k < 15) nbuf[k++] = ' ';
    strcpy(nbuf + k, t);
}
void num(u8 x, u8 y, s32 v, u8 width, u8 pal) { numStr(v, width); txt(x, y, nbuf, pal); }
void wnum(u8 x, u8 y, s32 v, u8 width, u8 pal) { numStr(v, width); wtxt(x, y, nbuf, pal); }
void box(u8 x, u8 y, u8 w, u8 h, u8 pal) {
    fillBkg(x + 1, y + 1, w - 2, h - 2, BLANK, pal);
    put(x, y, UI_TL, pal); put(x + w - 1, y, UI_TR, pal); put(x, y + h - 1, UI_BL, pal); put(x + w - 1, y + h - 1, UI_BR, pal);
    fillBkg(x + 1, y, w - 2, 1, UI_T, pal); fillBkg(x + 1, y + h - 1, w - 2, 1, UI_B, pal);
    fillBkg(x, y + 1, 1, h - 2, UI_L, pal); fillBkg(x + w - 1, y + 1, 1, h - 2, UI_R, pal);
}

// ── colours (Game Boy Color) ──────────────────────────────────────────────
#define C(r, g, b) RGB8(r, g, b)
void setBkgPal(u8 n, const u16 *p) { if (isCGB) set_bkg_palette(n, 1, p); }
void setSprPal(u8 n, const u16 *p) { if (isCGB) set_sprite_palette(n, 1, p); }
static const u16 BGP[8][4] = {
    { C(24, 24, 32), C(120, 120, 140), C(190, 190, 200), C(255, 255, 255) },    // TEXT: white on dark (index 0 = paper)
    { C(24, 24, 32), C(120, 90, 20), C(200, 150, 30), C(255, 210, 40) },        // GOLD
    { C(24, 24, 32), C(120, 20, 20), C(200, 40, 40), C(255, 70, 70) },          // RED
    { C(24, 24, 32), C(20, 100, 30), C(40, 170, 60), C(90, 240, 90) },          // GREEN
    { C(24, 24, 32), C(30, 60, 140), C(60, 110, 220), C(140, 190, 255) },       // BLUE
    { C(24, 24, 32), C(70, 70, 80), C(110, 110, 120), C(150, 150, 160) },       // GREY
    { C(24, 24, 32), C(60, 60, 70), C(140, 140, 150), C(255, 255, 255) },       // S1 (scenes set these)
    { C(24, 24, 32), C(60, 60, 70), C(140, 140, 150), C(255, 255, 255) } };     // S2
static const u16 OBP[8][4] = {
    { 0, C(200, 255, 200), C(40, 190, 60), C(10, 40, 10) },        // green marker
    { 0, C(255, 200, 200), C(220, 40, 40), C(50, 10, 10) },        // red
    { 0, C(170, 210, 255), C(50, 90, 230), C(10, 15, 40) },        // blue
    { 0, C(255, 255, 255), C(255, 200, 40), C(20, 20, 20) },       // gold (power marker, coins)
    { 0, C(20, 20, 20), C(170, 170, 170), C(255, 255, 255) },      // letters as sprites: white (index 3)
    { 0, C(255, 255, 255), C(170, 170, 170), C(20, 20, 20) },
    { 0, C(255, 255, 255), C(170, 170, 170), C(20, 20, 20) },
    { 0, C(255, 255, 255), C(170, 170, 170), C(20, 20, 20) } };
void uiPalettes(void) {
    BGP_REG = 0xE4;
    if (!isCGB) return;
    // on the Color the text is drawn light on dark: index 0 (paper) is the dark colour, 3 the ink.
    // (The grey Game Boy shows the same tiles dark on white: its palette is set in BGP_REG.)
    set_bkg_palette(0, 8, &BGP[0][0]);
    set_sprite_palette(0, 8, &OBP[0][0]);
}

// ── sprites ───────────────────────────────────────────────────────────────
void spr(s16 x, s16 y, u8 tile, u8 attr) {
    if (nSpr >= 40) return;
    x += 8; y += 16;
    if ((u16)x >= 168 || (u16)y >= 160 || !x || !y) return;       // (off screen: x 0..167, y 0..159 shown)
    u8 *o = &shadow_OAM[nSpr++].y;
    *o++ = (u8)y; *o++ = (u8)x; *o++ = tile; *o = attr;
}
void sprText(s16 x, s16 y, const char *s, u8 attr) {
    while (*s) { u8 c = (u8)*s++; if (c >= 'a' && c <= 'z') c -= 32; if (c != ' ') spr(x, y, CH(c), attr); x += 8; }
}
void spr16(s16 cx, s16 cy, u8 t, u8 attr) {
    // four 8x8s; a flipped picture swaps its halves
    s16 x0 = cx - 8, y0 = cy - 8, x1 = cx, y1 = cy;
    if (attr & 0x20) { x1 = x0; x0 = cx; }
    if (attr & 0x40) { y1 = y0; y0 = cy; }
    spr(x0, y0, t, attr); spr(x1, y0, t + 1, attr); spr(x0, y1, t + 2, attr); spr(x1, y1, t + 3, attr);
}
// the angle -> one of the 5 drawn angles (0, 22.5, 45, 67.5, 90 degrees) and the flips
static u8 angSel(u8 a, u8 *flags) {
    u8 f = 0, q = a;
    if (a > 64 && a <= 128) { q = 128 - a; f = 0x20; }          // mirrored left-right
    else if (a > 128 && a <= 192) { q = a - 128; f = 0x60; }    // turned half round
    else if (a > 192) { q = 0 - a; f = 0x40; }                  // mirrored top-bottom
    *flags = f;
    return (u8)((q + 8) >> 4);                                   // 0..4
}
void marker(s16 cx, s16 cy, u8 col, u8 ang) {
    u8 f, k = angSel(ang, &f);
    u8 base = col == 2 ? ST_MARK_BLUE : ST_MARK;
    u8 pal = isCGB ? col : (col == 0 ? 0 : 0x10);
    spr16(cx, cy, base + k * 4, f | pal);
}
// kind 0 green, 1 red/pink, 2 yellow, 3 blue: slim / slim / slim (2nd set) / fat
static const u8 MINI_SET[4] = { 0, 0, 1, 2 }, MINI_CPAL[4] = { OP_GREEN, OP_RED, OP_GOLD, OP_BLUE }, MINI_DPAL[4] = { 0, 0x10, 0, 0x10 };
void miniMarker(s16 cx, s16 cy, u8 kind, u8 ang) {
    u8 f, k = angSel(ang, &f);
    kind &= 3;
    spr(cx - 4, cy - 4, ST_MINI + MINI_SET[kind] * 5 + k, f | (isCGB ? MINI_CPAL[kind] : MINI_DPAL[kind]));
}
void powerMarker(s16 x0, s16 y0, u8 ang, u8 len, u8 fill) {
    // beads every 4 px from the back, the cap block at the front; the beads behind 'fill' are lit
    s16 dx = COSB(ang), dy = SINB(ang);          // *127
    u8 nb = len >> 2; if (nb < 2) nb = 2;
    u8 lit = (u8)(((u16)nb * fill) >> 8);
    u8 pal = isCGB ? OP_GOLD : 0;
    s16 x = x0 + (s16)((dx * (s16)len) >> 7), y = y0 + (s16)((dy * (s16)len) >> 7);
    spr(x - 4, y - 4, ST_PWR + 2, pal);                          // the cap
    for (u8 i = 0; i < nb; i++) {
        s16 l = (s16)i * 4;
        spr(x0 + (s16)((dx * l) >> 7) - 4, y0 + (s16)((dy * l) >> 7) - 4, ST_PWR + (i < lit ? 1 : 0), pal);
    }
}

// ── maths ─────────────────────────────────────────────────────────────────
const s8 SINT[256] = {
    0,3,6,9,12,16,19,22,25,28,31,34,37,40,43,46,49,51,54,57,60,63,65,68,71,73,76,78,81,83,85,88,
    90,92,94,96,98,100,102,104,106,107,109,111,112,113,115,116,117,118,120,121,122,122,123,124,125,125,126,126,126,127,127,127,
    127,127,127,127,126,126,126,125,125,124,123,122,122,121,120,118,117,116,115,113,112,111,109,107,106,104,102,100,98,96,94,92,
    90,88,85,83,81,78,76,73,71,68,65,63,60,57,54,51,49,46,43,40,37,34,31,28,25,22,19,16,12,9,6,3,
    0,-3,-6,-9,-12,-16,-19,-22,-25,-28,-31,-34,-37,-40,-43,-46,-49,-51,-54,-57,-60,-63,-65,-68,-71,-73,-76,-78,-81,-83,-85,-88,
    -90,-92,-94,-96,-98,-100,-102,-104,-106,-107,-109,-111,-112,-113,-115,-116,-117,-118,-120,-121,-122,-122,-123,-124,-125,-125,-126,-126,-126,-127,-127,-127,
    -127,-127,-127,-127,-126,-126,-126,-125,-125,-124,-123,-122,-122,-121,-120,-118,-117,-116,-115,-113,-112,-111,-109,-107,-106,-104,-102,-100,-98,-96,-94,-92,
    -90,-88,-85,-83,-81,-78,-76,-73,-71,-68,-65,-63,-60,-57,-54,-51,-49,-46,-43,-40,-37,-34,-31,-28,-25,-22,-19,-16,-12,-9,-6,-3 };
// atan(t) for t = 0..1 in 32 steps, in 256ths of a turn (32 = 45 degrees)
static const u8 ATAN[33] = { 0,1,3,4,5,6,8,9,10,11,12,13,15,16,17,18,19,20,21,22,23,24,25,25,26,27,28,29,29,30,31,31,32 };
u8 atan2i(s16 y, s16 x) {
    u16 ax = x < 0 ? (u16)-x : (u16)x, ay = y < 0 ? (u16)-y : (u16)y;
    if (!ax && !ay) return 0;
    u8 a = ax >= ay ? ATAN[(u16)(((u32)ay * 32) / ax)] : 64 - ATAN[(u16)(((u32)ax * 32) / ay)];
    if (x < 0) a = 128 - a;
    if (y < 0) a = 0 - a;
    return a;
}
u16 isqrt32(u32 v) {
    u32 r = 0, bit = (u32)1 << 30;
    while (bit > v) bit >>= 2;
    while (bit) { if (v >= r + bit) { v -= r + bit; r = (r >> 1) + bit; } else r >>= 1; bit >>= 2; }
    return (u16)r;
}
u16 rnd16(void) { return randw(); }
u8 rnd8(void) { return rand(); }
s16 rndr(s16 lo, s16 hi) { u16 span = (u16)(hi - lo); if (!span) return lo; return lo + (s16)(randw() % span); }

// ── a list of choices (menus) ─────────────────────────────────────────────
s8 menuList(u8 x, u8 y, u8 n, const char * const *items, u8 *sel, u8 step) {
    if (*sel >= n) *sel = 0;
    u8 old = *sel;
    if (kDown & J_DOWN) { *sel = (*sel + 1) % n; }
    if (kDown & J_UP) { *sel = (*sel + n - 1) % n; }
    if (entering || old != *sel) {
        for (u8 i = 0; i < n; i++) {
            put(x, y + i * step, i == *sel ? UI_CURSOR : BLANK, PAL_GOLD);
            txt(x + 2, y + i * step, items[i], i == *sel ? PAL_GOLD : PAL_TEXT);
        }
        if (old != *sel) sfx(SFX_MOVE);
    }
    if (kDown & J_A) { sfx(SFX_SELECT); return (s8)*sel; }
    if (kDown & J_B) return -2;
    return -1;
}

// ── what every arcade game shares ─────────────────────────────────────────
void screenFresh(void) { lcdOff(); uiPalettes(); scroll(0, 0); clearBkg(BLANK, PAL_TEXT); winAt(255, 0); nSpr = 0; frameEnd(); }
static u8 pausedNow;
u8 pauseCheck(void) {
    if (!pausedNow) {
        if (!(kDown & J_START)) return 0;
        pausedNow = 1; sfx(SFX_SELECT);
        fillWin(0, 0, 20, 6, BLANK, PAL_TEXT);
        wtxt(7, 1, "PAUSED", PAL_GOLD); wtxt(2, 3, "START   RESUME", PAL_TEXT); wtxt(2, 4, "SELECT  QUIT", PAL_TEXT);
        winAt(7, 56);
        return 1;
    }
    if (kDown & J_SELECT) { pausedNow = 0; winAt(255, 0); goScreen(S_ARCADE); return 1; }
    if (kDown & (J_START | J_A)) { pausedNow = 0; winAt(255, 0); return 2; }
    return 1;
}
// the end of a game: a fresh screen with the result lines, then AGAIN / ARCADE (returns 0 / 1 when picked)
static const char * const OVER_ITEMS[2] = { "PLAY AGAIN", "ARCADE" };
static u8 overSel, overFirst;
void overDraw(const char *title, const char *l1, const char *l2, const char *l3) {
    screenFresh();
    txtC(2, title, PAL_GOLD);
    if (l1) txtC(5, l1, PAL_TEXT);
    if (l2) txtC(7, l2, PAL_GREEN);
    if (l3) txtC(9, l3, PAL_GOLD);
    overSel = 0; overFirst = 1;
    lcdOn();
}
s8 overInput(void) {
    u8 e = entering; if (overFirst) { entering = 1; overFirst = 0; }
    s8 h = menuList(4, 13, 2, OVER_ITEMS, &overSel, 2);
    entering = e;
    if (h == -2) h = 1;
    return h;
}
char sbuf[32];
// "label N" into sbuf
char *lbl(const char *a, s32 v) { char t[12]; strcpy(sbuf, a); itoa10(v, t); strcat(sbuf, t); return sbuf; }
