// flip.c — QU33PH FLIP (the website's flip.html): flip the marker from pad to pad.
// The GBA's course building, chairs that launch you several pads ahead, jagged red ground that
// tips you over, 33 levels graded RED / GREEN / BLUE, ENDLESS and TIMED; bare bones: the pads
// are tiles (lined up to the 8-pixel grid), seen from the side, scrolling along.
// Units: Game Boy pixels (3/8 of the DS's), the marker's position in 1/256 pixels.
#pragma bank 255
#include "qu.h"
#include "res_flip.inc"

#define GQ 66                          // gravity, 1/256 px a step a step
#define MH 12                          // the marker's length (px)
#define CHAIR_H 15
#define MAXP 48
#define T_JAG (SCENE_T + 9)
typedef struct { s16 x, w; u8 y, uneven, hazard, chair, chairHit, graded, color; } Pad;
static Pad P[MAXP]; static u8 nP, lastFlat, stairLeft; static s8 stairStep;
static struct { s32 x, y; s16 vx, vy; u16 rot, spin; u8 pIdx, tipT; s8 skipTo; } mk;
enum { M_LEVELS, M_ENDLESS, M_TIMED };
enum { ST_MENU, ST_LEVELS, ST_READY, ST_FLYING, ST_BOOST, ST_TIP, ST_OVER };
static u8 flMode, levelIdx, st, combo, settle, won, timerOn, upright = 1, sel, overTier, overN, overFirst, charging, ph, power;
static s16 score, gradePts, overMax, coinsWon, camX, colNext; static u16 timeLeft;
static s8 aim; static u8 lift = 128;
static struct { s16 x, y; u8 life; char t[7]; } pops[2];

typedef struct { s8 g, w, d; u8 u, c; } PadSpec;
typedef struct { const char *name; u8 n; PadSpec p[10]; } Level;
static const Level LEVELS[11] = {
    { "FIRST FLIPS", 5, { {12,35,0,0,0}, {12,35,0,0,0}, {13,33,0,0,0}, {13,33,0,0,0}, {14,31,0,0,0} } },
    { "UP THE STAIRS", 6, { {12,31,0,0,0}, {12,29,-6,0,0}, {12,29,-6,0,0}, {12,29,-6,0,0}, {12,29,-6,0,0}, {14,33,0,0,0} } },
    { "RED TAPE", 7, { {12,31,0,0,0}, {12,21,0,1,0}, {12,31,0,0,0}, {12,19,0,0,0}, {12,31,0,0,0}, {12,21,0,1,0}, {13,33,0,0,0} } },
    { "HIGH ROAD", 8, { {12,29,0,0,0}, {12,27,-7,0,0}, {12,27,-7,0,0}, {12,27,-7,0,0}, {13,29,0,0,0}, {13,27,9,0,0}, {13,27,9,0,0}, {14,33,0,0,0} } },
    { "LAUNCH PAD", 8, { {12,31,0,0,0}, {12,29,0,0,1}, {12,27,0,0,0}, {12,21,0,1,0}, {12,29,0,0,0}, {12,27,-7,0,0}, {12,27,-7,0,0}, {14,33,0,0,0} } },
    { "THE CLIMB", 10, { {12,29,0,0,0}, {12,25,-7,0,0}, {12,25,-7,0,0}, {12,19,0,1,0}, {12,25,-6,0,0}, {12,25,-6,0,0}, {12,25,0,0,0}, {12,27,7,0,0}, {12,27,7,0,0}, {14,33,0,0,0} } },
    { "DOWN AND OUT", 7, { {12,31,0,0,0}, {12,29,6,0,0}, {12,29,6,0,0}, {12,29,6,0,0}, {12,27,6,0,0}, {13,31,0,0,0}, {13,31,0,0,0} } },
    { "ZIGZAG", 8, { {12,29,0,0,0}, {12,27,-7,0,0}, {12,27,7,0,0}, {12,27,-7,0,0}, {12,27,7,0,0}, {12,27,-7,0,0}, {13,31,0,0,0}, {13,31,7,0,0} } },
    { "GREEN MILE", 8, { {12,25,0,0,0}, {12,23,0,0,0}, {12,23,0,0,0}, {12,23,0,0,0}, {12,23,0,0,0}, {12,23,0,0,0}, {13,29,0,0,0}, {13,31,0,0,0} } },
    { "GAUNTLET", 9, { {12,29,0,0,0}, {12,19,0,1,0}, {12,27,0,0,0}, {12,19,0,0,0}, {12,27,0,0,0}, {12,19,0,1,0}, {12,27,0,0,0}, {12,19,0,0,0}, {13,33,0,0,0} } },
    { "SKY STEPS", 10, { {12,29,0,0,0}, {12,25,-7,0,0}, {12,25,-7,0,0}, {12,25,-7,0,0}, {12,25,-7,0,0}, {12,25,-7,0,0}, {12,25,0,0,0}, {12,27,9,0,0}, {12,27,9,0,0}, {14,33,0,0,0} } } };
#define LEVEL_COUNT 33
static u8 tierOf(u8 i) { return (u8)(sv.flipTiers[i / 16] >> ((i % 16) * 2)) & 3; }
static void setTier(u8 i, u8 t) { if (tierOf(i) >= t) return; sv.flipTiers[i / 16] = (sv.flipTiers[i / 16] & ~(3UL << ((i % 16) * 2))) | ((u32)t << ((i % 16) * 2)); }

// ── building the course (the website's, on the 8-pixel grid) ─────────────
static s16 snap8(s16 v) { return (v + 4) & ~7; }
static u8 rnd100(void) { return (u8)(rnd16() % 100); }
// how far a hard flip reaches when the next pad is dy pixels lower
static s16 maxReach(s16 dy) {
    s32 d = 1401L * 1401L + 2L * GQ * ((s32)dy << 8); if (d < 1) d = 1;
    s32 T = (1401 + (s32)isqrt32((u32)d)) / GQ;               // steps
    return (s16)((541 * T) >> 8);
}
static u8 clampY(s16 y) { y = snap8(y); return y < 64 ? 64 : y > 112 ? 112 : (u8)y; }
static void addPad(s16 x, u8 y, s16 w, u8 uneven, u8 chair) {
    if (nP >= MAXP) return;
    Pad *p = &P[nP++]; p->x = x; p->y = y; p->w = w; p->uneven = p->hazard = uneven; p->chair = chair;
    p->chairHit = p->graded = 0; p->color = (u8)(rnd16() % 3);
}
static void place(s16 x, s16 y, s16 w, u8 uneven, u8 chair) {   // a pad after the last, kept reachable
    Pad *last = &P[nP - 1];
    u8 yy = clampY(y);
    w = snap8(w); if (w < 16) w = 16;
    x = snap8(x);
    if (!uneven) {
        Pad *lf = &P[lastFlat]; s16 lim = (s16)(((s32)maxReach((s16)yy - lf->y) * 220) >> 8);
        if (x - lf->x > lim) x = (lf->x + lim) & ~7;
    }
    if (x < last->x + last->w + 8) x = last->x + last->w + 8;
    addPad(x, yy, w, uneven, chair);
    if (!uneven) lastFlat = nP - 1;
}
static void addPlatform(void) {
    Pad *last = &P[nP - 1]; u8 n = nP, hard = n > 25; s16 d = hard ? ((n - 25) * 256 / 40 > 256 ? 256 : (n - 25) * 256 / 40) : 0;
    if (hard && stairLeft == 0 && rnd100() < 24) { stairLeft = 3 + rnd8() % 3; stairStep = (rnd8() & 1 ? -1 : 1) * (s8)rndr(4, 8); }
    u8 uneven = !last->uneven && n > 6 && rnd100() < (hard ? 10 + (d * 15 >> 8) : 5);
    s16 w = uneven ? rndr(15, 23) : hard ? rndr(23, 33) - (d >> 6) : rndr(29, 39);
    s16 gap = uneven ? rndr(10, 15) : hard ? rndr(13, 21) + (d >> 5) : rndr(11, 17);
    s16 y = last->y;
    if (stairLeft) { stairLeft--; y += stairStep; } else y += hard ? rndr(-7, 8) : rndr(-3, 4);
    place(last->x + last->w + gap, y, w, uneven, !uneven && n > 3 && rnd100() < 15);
}
static void startPad(void) { nP = 0; addPad(8, 104, 40, 0, 0); lastFlat = 0; stairLeft = 0; stairStep = 0; }
static void buildLevel(u8 i) {
    startPad();
    if (i < 11) {
        const Level *L = &LEVELS[i];
        for (u8 k = 0; k < L->n; k++) { const PadSpec *s = &L->p[k]; Pad *last = &P[nP - 1];
            place(last->x + last->w + s->g, (s16)last->y + s->d, s->w, s->u, s->c); }
    } else for (u8 k = 0; k < 10 + i && nP < MAXP; k++) addPlatform();
    P[nP - 1].uneven = P[nP - 1].hazard = 0;
}
static void trimEndless(void) {                     // forget pads far behind (and slide the world back now and then)
    s8 drop = (s8)mk.pIdx - 4; if (drop <= 0 || flMode == M_LEVELS) return;
    memmove(P, P + drop, sizeof(Pad) * (nP - drop)); nP -= drop; lastFlat = lastFlat > (u8)drop ? lastFlat - drop : 0;
    mk.pIdx -= drop; if (mk.skipTo >= 0) mk.skipTo -= drop;
    if (camX > 16384) {                                 // (a multiple of the 256-pixel map: the picture doesn't move)
        for (u8 i = 0; i < nP; i++) P[i].x -= 8192;
        camX -= 8192; colNext -= 1024; mk.x -= 8192L * 256;
        for (u8 i = 0; i < 2; i++) pops[i].x -= 8192;
    }
}

// ── the picture: columns of tiles drawn as they scroll in ────────────────
static void drawCol(s16 c) {
    u8 bc = (u8)c & 31; s16 px = c * 8;
    fillBkg(bc, 0, 1, 16, BLANK, PAL_S1);
    for (u8 i = 0; i < nP; i++) { Pad *p = &P[i];
        if (px < p->x || px >= p->x + p->w) continue;
        u8 t = p->uneven ? T_JAG : SCENE_T + p->color * 3 + (px == p->x ? 0 : px + 8 >= p->x + p->w ? 2 : 1);
        put(bc, p->y >> 3, t, PAL_S1);
    }
}
static void hud(void) {
    fillWin(0, 0, 20, 2, BLANK, PAL_TEXT);
    wtxt(0, 0, lbl("", score), PAL_TEXT); wtxt((u8)strlen(sbuf) + 1, 0, "PTS", PAL_GREY);
    if (flMode == M_LEVELS) { wtxt(13, 0, lbl("LEVEL ", levelIdx + 1), PAL_GOLD); wtxt(0, 1, levelIdx < 11 ? LEVELS[levelIdx].name : "BUILT FOR YOU", PAL_GREY); }
    else if (flMode == M_TIMED) wtxt(12, 0, lbl("TIME ", (timeLeft + 59) / 60), timeLeft < 600 ? PAL_RED : PAL_GOLD);
    else wtxt(12, 0, lbl("BEST ", sv.flipBest), PAL_GOLD);
    if (flMode != M_LEVELS) wtxt(0, 1, upright ? "SELECT: UPRIGHT" : "SELECT: FLAT", PAL_GREY);
}
static void course(void) {
    screenFresh();
    loadBkgTiles(SCENE_T, 10, flip_bg);
    static const u16 SKY[4] = { RGB8(150, 200, 240), RGB8(230, 60, 60), RGB8(50, 170, 70), RGB8(50, 90, 220) };
    setBkgPal(PAL_S1, SKY);
    if (!isCGB) BGP_REG = 0xE4;
    camX = (s16)(mk.x >> 8) - 24; if (camX < 0) camX = 0;
    for (s16 c = camX >> 3; c < (camX >> 3) + 22; c++) drawCol(c);
    colNext = (camX >> 3) + 22;
    hud(); winAt(7, 128);
    scroll((u8)camX, 0);
    lcdOn();
}
static void startRun(void) {
    score = 0; combo = 0; settle = 0; won = 0; gradePts = 0; pops[0].life = pops[1].life = 0;
    mk.x = ((s32)P[0].x + P[0].w / 2) << 8; mk.y = (s32)P[0].y << 8; mk.vx = mk.vy = 0; mk.rot = mk.spin = 0; mk.pIdx = 0; mk.skipTo = -1;
    st = ST_READY; charging = 0; timeLeft = 45 * 60; timerOn = 0;
    course();
}
static void startMode(u8 m) {
    flMode = m;
    if (m == M_LEVELS) buildLevel(levelIdx); else { startPad(); for (u8 i = 0; i < 10; i++) addPlatform(); }
    startRun();
}

// ── the website's flip(), chairLaunch(), land() and step() ─────────────────
static void popAdd(s32 x, u8 y, const char *t) {
    u8 i = pops[0].life <= pops[1].life ? 0 : 1;
    pops[i].x = (s16)(x >> 8); pops[i].y = y; pops[i].life = 44; strncpy(pops[i].t, t, 6); pops[i].t[6] = 0;
}
static s16 flipVX(u8 p, s8 am) { s16 a = am + 64; s16 fac = 141 + (a > 0 ? (a * 3) >> 1 : 0); return (s16)(((s32)(197 + ((344 * (u16)p) >> 8)) * fac) >> 8); }
static s16 flipVY(u8 p, u8 lf) { return -(s16)(((s32)(958 + ((442 * (u16)p) >> 8)) * lf) >> 7); }
static void flip(void) {
    sfx(SFX_FLIP);
    mk.vx = flipVX(power, aim); mk.vy = flipVY(power, lift);
    u8 turns = 1 + (((u16)power * 2 + 128) >> 8);
    mk.spin = (u16)((2162688UL * turns) / (u16)(-mk.vy)); mk.rot = 0;
    st = ST_FLYING; timerOn = 1;
}
static void chairLaunch(u8 idx) {
    u8 target = idx + 3 + rnd8() % 3;
    if (flMode != M_LEVELS) while (nP <= target + 10 && nP < MAXP) addPlatform();
    if (target > nP - 1) target = nP - 1;
    Pad *t = &P[target];
    if (t->uneven) { t->uneven = 0; if (target > lastFlat) lastFlat = target; }
    t->chair = 0;
    s32 dy = ((s32)t->y << 8) - mk.y; mk.vy = -1622;
    s32 d = 1622L * 1622L + 2L * GQ * dy; if (d < 1) d = 1;
    s16 T = (s16)((1622 + (s32)isqrt32((u32)d)) / GQ); if (T < 1) T = 1;
    mk.vx = (s16)(((((s32)t->x + t->w / 2) << 8) - mk.x) / T);
    mk.spin = (u16)(262144UL / (u16)T); mk.skipTo = (s8)target; st = ST_BOOST;
    popAdd(mk.x, (u8)(mk.y >> 8) - 24, "CHAIR!");
    sfx(SFX_GOOD);
}
static void endGame(const char *title, u8 win) {
    st = ST_OVER; timerOn = 0; won = win;
    if (!win) sfx(SFX_BAD);
    if (mk.pIdx > sv.flipBestP) sv.flipBestP = mk.pIdx;
    if (score > (s16)sv.flipBest) sv.flipBest = score;
    if (score > sv.arcadeBest[ARC_FLIP]) sv.arcadeBest[ARC_FLIP] = score;
    sv.arcadePlays[ARC_FLIP]++;
    s16 c = score / 5; if (c > 20) c = 20;
    coinsWon = c; if (c > 0) addCoins(c);
    saveWrite();
    char l1[21], l2[21], l3[21];
    if (win && flMode == M_LEVELS) {
        strcpy(l1, lbl("", gradePts < overMax ? gradePts : overMax)); strcat(l1, " / "); strcat(l1, lbl("", overMax)); strcat(l1, " PTS");
        static const char * const T[4] = { "", "RED MARKER", "GREEN MARKER", "BLUE MARKER" }; strcpy(l2, T[overTier]);
    } else { strcpy(l1, lbl("", score)); strcat(l1, " PTS  "); strcat(l1, lbl("", mk.pIdx)); strcat(l1, " PADS"); strcpy(l2, lbl("BEST ", sv.flipBest)); }
    strcpy(l3, "+"); itoa10(coinsWon, l3 + 1); strcat(l3, " COINS");
    overDraw(title, l1, l2, l3);
    overN = (win && flMode == M_LEVELS && levelIdx < LEVEL_COUNT - 1) ? 3 : 2; sel = 0; overFirst = 1;
}
static void finishLevel(void) {
    if (levelIdx + 1 > sv.flipDone) sv.flipDone = levelIdx + 1;
    s16 maxPts = 0; for (u8 k = 1; k < nP; k++) if (!P[k].hazard) maxPts += P[k].color + 1;
    s16 got = gradePts < maxPts ? gradePts : maxPts;
    overTier = (s32)got * 10 >= (s32)maxPts * 9 ? 3 : (s32)got * 10 >= (s32)maxPts * 6 ? 2 : 1; overMax = maxPts; setTier(levelIdx, overTier);
    sfx(SFX_GOOD);
    endGame("LEVEL CLEAR", 1);
}
static void land(u8 i) {
    Pad *p = &P[i];
    mk.y = (s32)p->y << 8; mk.vx = mk.vy = 0; mk.rot = 0; mk.skipTo = -1;
    if (p->uneven) { st = ST_TIP; mk.tipT = 0; sfx(SFX_BAD); return; }
    mk.pIdx = i; combo++;
    u8 pts = p->color + 1;
    if (!p->graded) { p->graded = 1; gradePts += pts; }
    score += pts;
    char t[4] = { '+', '0' + pts, 0, 0 };
    popAdd(mk.x, p->y - 20, t);
    sfx(SFX_PLOP);
    st = ST_READY; settle = 9;
    if (flMode == M_LEVELS) { if (i >= nP - 1) { finishLevel(); return; } }
    else { while (nP < mk.pIdx + 11 && nP < MAXP) addPlatform(); trimEndless(); }
    hud();
}
static void step(void) {
    if (st == ST_TIP) { mk.tipT++; mk.rot += 1147; if (mk.tipT > 26) endGame("TIPPED OVER", 0); return; }
    if (st == ST_FLYING || st == ST_BOOST) {
        s32 prevY = mk.y;
        mk.x += mk.vx; mk.vy += GQ; mk.y += mk.vy; mk.rot += mk.spin;
        s16 x = (s16)(mk.x >> 8), y = (s16)(mk.y >> 8);
        if (st == ST_FLYING)
            for (u8 i = 0; i < nP; i++) { Pad *p = &P[i]; if (!p->chair || p->chairHit) continue;
                s16 cx = p->x + p->w / 2;
                if (x > cx - 8 && x < cx + 8 && y > (s16)p->y - CHAIR_H && y < (s16)p->y + 3) { p->chairHit = 1; chairLaunch(i); break; } }
        if (mk.vy > 0) {
            if (st == ST_BOOST) { s8 i = mk.skipTo; if (i >= 0 && i < (s8)nP && x >= P[i].x && x <= P[i].x + P[i].w && prevY <= ((s32)P[i].y << 8) && mk.y >= ((s32)P[i].y << 8)) land((u8)i); }
            else for (u8 i = 0; i < nP; i++) { Pad *p = &P[i]; if (x >= p->x && x <= p->x + p->w && prevY <= ((s32)p->y << 8) && mk.y >= ((s32)p->y << 8)) { land(i); break; } }
        }
        if (st != ST_OVER && mk.y > 180L * 256) endGame("OFF THE EDGE", 0);
    }
}
static void frameStep(void) {
    if (settle) settle--;
    if (flMode == M_TIMED && timerOn) {
        if (timeLeft) timeLeft--;
        if ((timeLeft % 60) == 59) hud();
        if (!timeLeft) { endGame("TIME UP", 0); return; }
    }
    step(); if (st == ST_FLYING || st == ST_BOOST || st == ST_TIP) step();    // flights run at double speed
    if (st == ST_OVER) return;
    s16 tc = (s16)(mk.x >> 8) - 24;
    if (tc > camX) camX += (tc - camX + 7) >> 3;
    while (colNext <= (camX >> 3) + 21) drawCol(colNext++);
    for (u8 i = 0; i < 2; i++) if (pops[i].life) { pops[i].life--; if (!(pops[i].life & 3)) pops[i].y--; }
}
static void drawSprites(void) {
    s16 x = (s16)(mk.x >> 8) - camX, y = (s16)(mk.y >> 8);
    u8 base = upright ? 64 : 0;
    s16 cy = upright ? y - 8 : y - 4;
    if (st == ST_TIP) cy += mk.tipT >> 2;
    marker(x, cy - (settle > 4 ? 1 : 0), 0, base + (u8)(mk.rot >> 8));
    for (u8 i = 0; i < nP; i++) { Pad *p = &P[i]; if (!p->chair || p->chairHit) continue;
        s16 sx = p->x + p->w / 2 - camX; if (sx < -8 || sx > 168) continue;
        spr16(sx, p->y - 8, ST_CHAIR, isCGB ? OP_RED : 0); }
    if (st == ST_READY) {                                  // where it'll go
        u8 p = charging ? power : 128;
        static u8 lp = 255, la, ll; static s16 dx[13], dy[13];          // the dots: worked out again only when the aim changes
        if (p != lp || (u8)aim != la || lift != ll) {
            lp = p; la = (u8)aim; ll = lift;
            s16 vx3 = (flipVX(p, aim) * 3) >> 4, vy = flipVY(p, lift), rx = 0, ry = 0;   // (1/16 pixel; 3 steps at a time)
            for (u8 j = 0; j < 13; j++) { rx += vx3; ry += (vy * 3 + GQ * 6) >> 4; vy += GQ * 3; dx[j] = rx >> 4; dy[j] = ry >> 4; }
        }
        s16 x0 = (s16)(mk.x >> 8) - camX - 4, y0 = (s16)(mk.y >> 8) - (MH >> 1) - 4; u8 pal = isCGB ? (charging ? OP_RED : OP_GOLD) : 0;
        for (u8 j = 0; j < 13; j++) spr(x0 + dx[j], y0 + dy[j], UI_DOT, pal);
        if (charging) powerMarker(x, y - 22, 0, 6 + (power >> 4), power);
    }
    for (u8 i = 0; i < 2; i++) if (pops[i].life) sprText(pops[i].x - camX - 8, pops[i].y, pops[i].t, isCGB ? OP_WHITE : 0);
}

static void levelScreen(void) {
    screenFresh(); txtC(0, "FLIP LEVELS", PAL_GOLD);
    txtC(2, lbl("", sv.flipDone), PAL_TEXT); txt(9 + (u8)strlen(sbuf) / 2, 2, "/33 CLEARED", PAL_GREY);
    for (u8 i = 0; i < LEVEL_COUNT; i++) {                  // numbered keys, coloured by the marker earned
        u8 t = tierOf(i), open = i <= sv.flipDone;
        num(1 + (i % 6) * 3, 5 + (i / 6) * 2, i + 1, 2, !open ? PAL_GREY : t == 3 ? PAL_BLUE : t == 2 ? PAL_GREEN : t == 1 ? PAL_RED : PAL_TEXT);
    }
    txtC(17, "A PLAY   B BACK", PAL_GREY);
    lcdOn();
}
static void levelCursor(u8 on) { put((levelIdx % 6) * 3, 5 + (levelIdx / 6) * 2, on ? UI_CURSOR : BLANK, PAL_GOLD);
    fillBkg(0, 15, 20, 1, BLANK, PAL_TEXT); if (on) txtC(15, levelIdx < 11 ? LEVELS[levelIdx].name : "BUILT FOR YOU", PAL_TEXT); }
static const char * const MENU_ITEMS[4] = { "LEVELS", "ENDLESS", "TIMED", "BACK" };
void flipEnter(void) BANKED { }
void flipUpdate(void) BANKED {
    if (entering) {
        st = ST_MENU; sel = 0;
        screenFresh(); txtC(0, "QU33PH FLIP", PAL_GOLD);
        static const char * const L[7] = { "FLIP PAD TO PAD.", "LEFT/RIGHT: HOW FAR", "UP/DOWN: HOW HIGH", "HOLD A FOR POWER.", "RED 1 GREEN 2 BLUE 3", "CHAIRS LAUNCH YOU;", "RED SPIKES TIP YOU." };
        for (u8 i = 0; i < 7; i++) txt(0, 2 + i, L[i], i == 4 ? PAL_GOLD : i == 6 ? PAL_RED : PAL_TEXT);
        strcpy(sbuf, "LEVELS "); itoa10(sv.flipDone, sbuf + 7); strcat(sbuf, "/33"); txt(0, 16, sbuf, PAL_GREY);
        txt(0, 17, lbl("BEST ", sv.flipBest), PAL_GREY);
        lcdOn();
    }
    music(MUS_FLIP);
    if (st == ST_MENU) {
        s8 h = menuList(10, 10, 4, MENU_ITEMS, &sel, 1);
        if (h == 0) { st = ST_LEVELS; levelIdx = sv.flipDone < LEVEL_COUNT ? sv.flipDone : LEVEL_COUNT - 1; levelScreen(); levelCursor(1); }
        else if (h == 1) startMode(M_ENDLESS); else if (h == 2) startMode(M_TIMED);
        else if (h == 3 || h == -2) goScreen(S_ARCADE);
        return;
    }
    if (st == ST_LEVELS) {
        u8 old = levelIdx, top = sv.flipDone < LEVEL_COUNT - 1 ? sv.flipDone : LEVEL_COUNT - 1;
        if ((kDown & J_RIGHT) && levelIdx < top) levelIdx++;
        if ((kDown & J_LEFT) && levelIdx) levelIdx--;
        if ((kDown & J_DOWN) && levelIdx + 6 <= top) levelIdx += 6;
        if ((kDown & J_UP) && levelIdx >= 6) levelIdx -= 6;
        if (old != levelIdx) { u8 n = levelIdx; levelIdx = old; levelCursor(0); levelIdx = n; levelCursor(1); sfx(SFX_MOVE); }
        if (kDown & J_A) { sfx(SFX_SELECT); startMode(M_LEVELS); }
        else if (kDown & J_B) goScreen(S_FLIP);
        return;
    }
    if (st == ST_OVER) {
        static const char * const O3[3] = { "NEXT LEVEL", "RETRY", "MENU" };
        u8 e = entering; if (overFirst) { entering = 1; overFirst = 0; }
        s8 h = menuList(4, 13, overN, O3 + (overN == 2), &sel, 2);
        entering = e;
        if (h >= 0 && overN == 2) h++;
        if (h == 0) { levelIdx++; startMode(M_LEVELS); }
        else if (h == 1) startMode(flMode);
        else if (h == 2 || h == -2) goScreen(S_FLIP);
        return;
    }
    u8 p = pauseCheck(); if (p == 1) { charging = 0; return; }
    if (p == 2) winAt(7, 128);
    if (kDown & J_SELECT) { upright = !upright; hud(); }
    if (st == ST_READY) {
        if ((kHeld & J_LEFT) && aim > -126) aim -= 2;
        if ((kHeld & J_RIGHT) && aim < 126) aim += 2;
        if ((kHeld & J_UP) && lift < 172) lift += 2;
        if ((kHeld & J_DOWN) && lift > 46) lift -= 2;
        if (kDown & J_A) { charging = 1; ph = 0; }
        if (charging) {
            ph++; u8 t = ph % 44; power = t < 22 ? t * 11 + 4 : (44 - t) * 11 + 4; if (power < 26) power = 26;
            if (kDown & J_B) charging = 0;
            else if (kUp & J_A) { charging = 0; flip(); }
        }
    } else charging = 0;
    frameStep();
    if (st == ST_OVER) return;
    scroll((u8)camX, 0);
    drawSprites();
}
