// sound.c — the Game Boy's own sound chip: short effects on channels 1 (tone) and 4 (noise),
// and a little two-voice music player (channel 2 the tune, channel 3 the bass) running in the
// vertical blank so it never stutters.
#include "qu.h"
#include "res_music.h"

// ── effects ───────────────────────────────────────────────────────────────
// an effect is a few steps, one every 'gap' frames: tone steps set channel 1's pitch,
// noise steps channel 4's
typedef struct { u8 kind, a, b, c; } Step;          // kind 1 tone (a duty|len, b envelope, c note), 2 noise (a envelope, b poly), 3 sweep tone (a sweep, b envelope, c note)
static const Step SFXD[SFX_N][5] = {
    [SFX_THROW]  = { { 2, 0xA1, 0x52, 0 }, { 2, 0x61, 0x40, 0 } },
    [SFX_PLOP]   = { { 3, 0x1D, 0xC1, 40 } },
    [SFX_PEEF]   = { { 1, 0x80, 0xC2, 36 }, { 1, 0x80, 0xA2, 31 }, { 1, 0x80, 0x82, 26 } },
    [SFX_HIT]    = { { 2, 0x91, 0x23, 0 } },
    [SFX_COIN]   = { { 1, 0x80, 0xB1, 59 }, { 1, 0x80, 0xB2, 64 } },
    [SFX_SELECT] = { { 1, 0x80, 0x91, 55 }, { 1, 0x80, 0x91, 62 } },
    [SFX_MOVE]   = { { 1, 0x40, 0x61, 52 } },
    [SFX_WALL]   = { { 2, 0x81, 0x55, 0 } },
    [SFX_PIN]    = { { 2, 0xB1, 0x34, 0 }, { 2, 0x71, 0x46, 0 } },
    [SFX_JUMP]   = { { 3, 0x26, 0xA1, 43 } },
    [SFX_FLIP]   = { { 3, 0x24, 0xB1, 48 } },
    [SFX_BAD]    = { { 1, 0xC0, 0xA2, 20 }, { 1, 0xC0, 0xA2, 18 } },
    [SFX_GOOD]   = { { 1, 0x80, 0xB1, 48 }, { 1, 0x80, 0xB1, 52 }, { 1, 0x80, 0xB1, 55 }, { 1, 0x80, 0xC2, 60 } },
};
// note n (0 = C2) -> the chip's 11-bit pitch: 2048 - 131072 / Hz
static const u16 FREQ[72] = {
    44,156,263,363,457,547,631,711,786,856,923,986,1046,1102,1155,1205,1253,1297,1339,1379,1417,1452,1486,1517,
    1547,1575,1602,1627,1650,1673,1694,1714,1732,1750,1767,1783,1798,1812,1825,1837,1849,1860,1871,1881,1890,1899,1907,1915,
    1923,1930,1936,1943,1949,1954,1959,1964,1969,1974,1978,1982,1985,1989,1992,1995,1998,2001,2004,2006,2009,2011,2013,2015 };
static u8 fxId = 255, fxStep, fxT;
static void fxPlay(const Step *s) {
    if (s->kind == 2) { NR41_REG = 0x3F; NR42_REG = s->a; NR43_REG = s->b; NR44_REG = 0x80; return; }
    u16 f = FREQ[s->c < 72 ? s->c : 71];
    NR10_REG = s->kind == 3 ? s->a : 0x00;
    NR11_REG = s->kind == 3 ? 0x80 : s->a; NR12_REG = s->b;
    NR13_REG = (u8)f; NR14_REG = 0x80 | (u8)(f >> 8);
}
void sfx(u8 w) {
    if (!sv.sfxOn || w >= SFX_N) return;
    fxId = w; fxStep = 0; fxT = 0;
}

// ── music ─────────────────────────────────────────────────────────────────
// each track: two voices of (note + 1, frames) pairs; 0 = rest, 255 = loop to the start
static u8 musTrack = 255, musOn;
static const u8 *vp[2]; static const u8 *vstart[2]; static u8 vt[2];
static const u8 WAVE[16] = { 0x01, 0x23, 0x45, 0x67, 0x89, 0xAB, 0xCD, 0xEF, 0xFE, 0xDC, 0xBA, 0x98, 0x76, 0x54, 0x32, 0x10 };
static void voiceNote(u8 v, u8 n) {
    if (v == 0) {
        if (!n) { NR22_REG = 0x00; NR24_REG = 0x80; return; }
        u16 f = FREQ[n <= 72 ? n - 1 : 71];
        NR21_REG = 0x80; NR22_REG = 0x73; NR23_REG = (u8)f; NR24_REG = 0x80 | (u8)(f >> 8);
    } else {
        if (!n) { NR32_REG = 0x00; return; }
        u16 f = FREQ[n <= 72 ? n - 1 : 71];
        NR30_REG = 0x80; NR32_REG = 0x40; NR33_REG = (u8)f; NR34_REG = 0x80 | (u8)(f >> 8);
    }
}
void music(u8 t) {
    if (t == musTrack && musOn) return;
    musTrack = t; musOn = 0;
    if (t >= MUSIC_TRACKS) return;
    vstart[0] = vp[0] = MUSIC_V0[t]; vstart[1] = vp[1] = MUSIC_V1[t]; vt[0] = vt[1] = 1;
    musOn = 1;
}
void musicStop(void) { musOn = 0; musTrack = 255; NR22_REG = 0; NR24_REG = 0x80; NR32_REG = 0; }

void soundInit(void) {
    NR52_REG = 0x80; NR50_REG = 0x77; NR51_REG = 0xFF;
    NR30_REG = 0x00;
    for (u8 i = 0; i < 16; i++) (&AUD3WAVE[0])[i] = WAVE[i];
    NR30_REG = 0x80;
}
void soundTick(void) {
    // effects: a step every 4 frames
    if (fxId != 255) {
        if (fxT == 0) {
            const Step *s = &SFXD[fxId][fxStep];
            if (fxStep >= 5 || !s->kind) fxId = 255;
            else { fxPlay(s); fxStep++; }
        }
        if (++fxT >= 4) fxT = 0;
    }
    // music (the music data lives in the always-there bank)
    if (!musOn || !sv.musicOn) return;
    for (u8 v = 0; v < 2; v++) {
        if (--vt[v]) continue;
        if (vp[v][0] == 255) vp[v] = vstart[v];
        voiceNote(v, vp[v][0]); vt[v] = vp[v][1]; vp[v] += 2;
    }
}
