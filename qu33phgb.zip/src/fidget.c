#pragma bank 255
#include "qu.h"
void fidgetEnter(void) BANKED { }
void fidgetUpdate(void) BANKED { if (entering) { lcdOff(); uiPalettes(); scroll(0,0); clearBkg(BLANK, PAL_TEXT); txtC(8, "COMING SOON", PAL_GOLD); lcdOn(); } if (kDown & J_B) goScreen(S_TITLE); }
