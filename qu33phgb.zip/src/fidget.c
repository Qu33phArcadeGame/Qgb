// fidget.c — FIDGET QU33PH (the website's fidget.html): spinner air hockey.
// The DS's tall field (your half at the bottom) on its side like the GBA's: you on the left, the
// CPU on the right. Knock the ball off the far end to score; first to 3, 5 or 7. The physics are
// the website's, in its own units (the DS's 256 x 384 field), in whole numbers:
// spinners in 1/16 pixels, the ball in 1/256 pixels.
#pragma bank 255
#include "qu.h"
#include "res_fidget.inc"

#define FW (256 * 16)
#define FH (384 * 16)
#define FCY (192 * 16)
#define R_BALL 213                    // 256 * 0.052, in 1/16
#define R_SPIN 532                    // 256 * 0.13
#define RR 650                        // R_BALL + R_SPIN * 0.82
#define SPIN_T ST_GAME                // 6 turns x 9 tiles
#define BALL_T (ST_GAME + 54)         // 2 x 4
enum { ST_MENU, ST_PLAY, ST_GOAL, ST_OVER };
typedef struct { s16 x, y, px, py, vx, vy; u16 spin; u8 touching; } Spin;
static Spin s1, s2;
static struct { s32 x, y; s16 vx, vy; u16 rot; } ball;
static u8 st, goalT, f1, f2, winGoals = 3, c1, sel, drawnScore;
static const char *msg;

static void resetPositions(void) {
    ball.x = (s32)(FW / 2) << 4; ball.y = (s32)FCY << 4; ball.vx = ball.vy = 0;
    s1.x = s1.px = FW / 2; s1.y = s1.py = FH * 4 / 5; s1.vx = s1.vy = 0; s1.touching = 0;
    s2.x = s2.px = FW / 2; s2.y = s2.py = FH / 5; s2.vx = s2.vy = 0; s2.touching = 0;
}
static s16 clampS(s16 v, s16 a, s16 b) { return v < a ? a : v > b ? b : v; }
static void place(Spin *sp, s16 x, s16 y, u8 bottom) {
    sp->x = clampS(x, R_SPIN, FW - R_SPIN);
    sp->y = bottom ? clampS(y, FCY + 319, FH - R_SPIN) : clampS(y, R_SPIN, FCY - 319);
}
static s16 absS(s16 v) { return v < 0 ? -v : v; }
static void collide(Spin *sp, u8 mine) {
    s16 dx = (s16)(ball.x >> 4) - sp->x, dy = (s16)(ball.y >> 4) - sp->y;
    if (absS(dx) >= RR || absS(dy) >= RR) { sp->touching = 0; return; }
    s32 d2 = (s32)dx * dx + (s32)dy * dy;
    if (d2 >= (s32)RR * RR || d2 == 0) { sp->touching = 0; return; }
    if (!sp->touching) { sp->touching = 1; sfx(mine ? SFX_HIT : SFX_WALL); }
    s16 d = (s16)isqrt32((u32)d2);
    s16 nx = (s16)(((s32)dx << 8) / d), ny = (s16)(((s32)dy << 8) / d);          // 1/256
    ball.x = ((s32)sp->x << 4) + (((s32)nx * RR) >> 4); ball.y = ((s32)sp->y << 4) + (((s32)ny * RR) >> 4);
    s16 relv = (s16)(((s32)sp->vx * nx + (s32)sp->vy * ny) >> 8); if (relv < 0) relv = 0;   // 1/16 px a frame
    s16 kick = relv * 16 + 655;                                                    // 1/256
    s16 vx = (s16)(((s32)nx * kick) >> 8) + sp->vx * 10, vy = (s16)(((s32)ny * kick) >> 8) + sp->vy * 10;
    s32 s2_ = (s32)vx * vx + (s32)vy * vy;
    if (s2_ > 4915L * 4915L) { s16 s = (s16)isqrt32((u32)s2_); vx = (s16)((s32)vx * 4915 / s); vy = (s16)((s32)vy * 4915 / s); }
    ball.vx = vx; ball.vy = vy;
}
static void drawScore(void) {
    fillBkg(0, 0, 20, 2, BLANK, PAL_TEXT);
    txt(1, 0, "YOU", c1 ? PAL_BLUE : PAL_GREEN);
    sbuf[0] = '0' + f1; strcpy(sbuf + 1, " - "); sbuf[4] = '0' + f2; sbuf[5] = 0; txt(7, 0, sbuf, PAL_TEXT);
    txt(16, 0, "CPU", c1 ? PAL_GREEN : PAL_BLUE);
    strcpy(sbuf, "FIRST TO "); sbuf[9] = '0' + winGoals; sbuf[10] = 0; txtC(1, sbuf, PAL_GREY);
}
static void gameOver(void) {
    u8 won = f1 >= winGoals;
    sv.arcadePlays[ARC_FIDGET]++;
    s16 coins = 0;
    if (won) { sv.arcadeBest[ARC_FIDGET]++; coins = winGoals; addCoins(coins); }
    saveWrite();
    char l1[12]; l1[0] = '0' + f1; strcpy(l1 + 1, " - "); l1[4] = '0' + f2; l1[5] = 0;
    char l3[20]; strcpy(l3, "+"); itoa10(coins, l3 + 1); strcat(l3, " COINS");
    char l2[20]; strcpy(l2, lbl("WINS VS CPU ", sv.arcadeBest[ARC_FIDGET]));
    st = ST_OVER;
    sfx(won ? SFX_GOOD : SFX_BAD);
    overDraw(won ? "YOU WIN!" : "CPU WINS", l1, l2, l3);
}
static void scoreGoal(u8 who) {
    sfx(SFX_PEEF);
    if (who == 1) { f1++; msg = "GOAL!"; } else { f2++; msg = "CPU SCORES"; }
    drawScore();
    if (f1 >= winGoals || f2 >= winGoals) { gameOver(); return; }
    st = ST_GOAL; goalT = 70;
}
static s16 spd(const Spin *s) { return absS(s->vx) + absS(s->vy); }
static void step(void) {
    s1.spin += 7824 + (u16)spd(&s1) * 40; s2.spin += 7824 + (u16)spd(&s2) * 40;
    if (st == ST_GOAL) { if (--goalT == 0) { resetPositions(); st = ST_PLAY; } return; }
    s1.vx = s1.x - s1.px; s1.vy = s1.y - s1.py; s1.px = s1.x; s1.py = s1.y;
    {                                                       // the website's CPU
        s16 bx = (s16)(ball.x >> 4), by = (s16)(ball.y >> 4), tx, ty;
        if (by < FCY) { tx = bx; ty = by - 372; } else { tx = FW / 2 + ((bx - FW / 2) >> 1); ty = 860; }
        s16 adx = tx - s2.x, ady = ty - s2.y;
        s32 ad2 = (s32)adx * adx + (s32)ady * ady;
        s2.px = s2.x; s2.py = s2.y;
        if (ad2 > 0) {
            s16 ad = (s16)isqrt32((u32)ad2);
            if (ad <= 43) { s2.x = tx; s2.y = ty; }
            else { s2.x += (s16)((s32)adx * 43 / ad); s2.y += (s16)((s32)ady * 43 / ad); }
        }
        place(&s2, s2.x, s2.y, 0);
        s2.vx = s2.x - s2.px; s2.vy = s2.y - s2.py;
    }
    ball.x += ball.vx; ball.y += ball.vy; ball.rot += (u16)(absS(ball.vx) + absS(ball.vy)) >> 2;
    // ×0.99 a frame, and a nudge to a stop once it's crawling
    s16 d = ball.vx >> 7; if (!d && ball.vx) d = ball.vx > 0 ? 1 : -1; ball.vx -= d; if (absS(ball.vx) < 8) ball.vx = 0;
    d = ball.vy >> 7; if (!d && ball.vy) d = ball.vy > 0 ? 1 : -1; ball.vy -= d; if (absS(ball.vy) < 8) ball.vy = 0;
    if (ball.x < (s32)R_BALL << 4) { ball.x = (s32)R_BALL << 4; ball.vx = absS(ball.vx) - (absS(ball.vx) >> 3); sfx(SFX_WALL); }
    if (ball.x > (s32)(FW - R_BALL) << 4) { ball.x = (s32)(FW - R_BALL) << 4; ball.vx = -(absS(ball.vx) - (absS(ball.vx) >> 3)); sfx(SFX_WALL); }
    if (ball.y < (s32)R_BALL << 4) { scoreGoal(1); return; }               // off the far end: you score
    if (ball.y > (s32)(FH - R_BALL) << 4) { scoreGoal(2); return; }        // off your end: they score
    collide(&s1, 1); collide(&s2, 0);
}
// the DS's (x, y) on the turned screen: x across 0..160 = 384..0 down the field, y 20..127 = 0..256
static s16 scx(s16 y) { return (s16)(((u16)((FH - y) >> 3) * 53) >> 8); }
static s16 scy(s16 x) { return 20 + (s16)(((u16)(x >> 3) * 53) >> 8); }
static void spinnerAt(s16 x, s16 y, u16 spin, u8 pal) {
    x -= 12; y -= 12;
    u8 t = SPIN_T + (u8)(((u32)spin * 6) >> 16) * 9;
    for (u8 j = 0; j < 3; j++) for (u8 i = 0; i < 3; i++) spr(x + i * 8, y + j * 8, t++, pal);
}
static void drawSprites(void) {
    s16 bx = scx((s16)(ball.y >> 4)), by = scy((s16)(ball.x >> 4));
    spr16(bx, by, BALL_T + ((ball.rot >> 10) & 1) * 4, isCGB ? OP_WHITE : 0);
    spinnerAt(scx(s1.y), scy(s1.x), s1.spin, isCGB ? (c1 ? OP_BLUE : OP_GREEN) : 0);
    spinnerAt(scx(s2.y), scy(s2.x), s2.spin, isCGB ? (c1 ? OP_GREEN : OP_BLUE) : 0x10);
    if (st == ST_GOAL) sprText(80 - (s16)strlen(msg) * 4, 60, msg, isCGB ? OP_WHITE : 0);
}
static void rink(void) {
    screenFresh();
    loadBkgTiles(SCENE_T, 6, fid_bg);
    loadSprTiles(ST_GAME, FID_SPR_N, fid_spr);
    static const u16 ICE[4] = { RGB8(220, 235, 245), RGB8(160, 190, 210), RGB8(90, 110, 130), RGB8(30, 35, 45) };
    static const u16 ENDS_G[4] = { RGB8(220, 235, 245), RGB8(160, 190, 210), RGB8(60, 190, 80), RGB8(70, 120, 230) };
    static const u16 ENDS_B[4] = { RGB8(220, 235, 245), RGB8(160, 190, 210), RGB8(70, 120, 230), RGB8(60, 190, 80) };
    setBkgPal(PAL_S1, ICE); setBkgPal(PAL_S2, c1 ? ENDS_B : ENDS_G);
    fillBkg(0, 2, 20, 1, SCENE_T + 1, PAL_S1);
    fillBkg(0, 3, 20, 12, SCENE_T, PAL_S1);
    fillBkg(0, 15, 20, 1, SCENE_T + 2, PAL_S1);
    fillBkg(10, 3, 1, 12, SCENE_T + 3, PAL_S1);                       // the centre line
    fillBkg(0, 3, 1, 12, SCENE_T + 4, PAL_S2); fillBkg(19, 3, 1, 12, SCENE_T + 5, PAL_S2);   // the ends
    fillBkg(0, 16, 20, 2, BLANK, PAL_TEXT);
    txtC(17, "D-PAD MOVES", PAL_GREY);
    drawScore();
    lcdOn();
}
static void start(void) { f1 = f2 = 0; resetPositions(); st = ST_PLAY; rink(); }

static const char * const MENU_ITEMS[4] = { "FIRST TO 3", "PLAY GREEN", "PLAY BLUE", "BACK" };
void fidgetEnter(void) BANKED { }
void fidgetUpdate(void) BANKED {
    if (entering) {
        st = ST_MENU; sel = 1;
        screenFresh(); txtC(0, "FIDGET QU33PH", PAL_GOLD); loadSprTiles(ST_GAME, FID_SPR_N, fid_spr);
        txt(0, 2, "SPINNER AIR HOCKEY.", PAL_TEXT);
        txt(0, 3, "KNOCK THE BALL OFF", PAL_TEXT);
        txt(0, 4, "THE FAR END (RIGHT)", PAL_TEXT);
        txt(0, 5, "TO SCORE.", PAL_TEXT);
        txt(0, 7, "D-PAD MOVES YOURS.", PAL_GREY);
        txtC(16, lbl("WINS VS CPU ", sv.arcadeBest[ARC_FIDGET]), PAL_GOLD);
        lcdOn();
    }
    music(MUS_FIDGET);
    if (st == ST_MENU) {
        static char first[12]; strcpy(first, "FIRST TO "); first[9] = '0' + winGoals; first[10] = 0;
        static const char *items[4]; items[0] = first; items[1] = MENU_ITEMS[1]; items[2] = MENU_ITEMS[2]; items[3] = MENU_ITEMS[3];
        if (kDown & J_B) { goScreen(S_ARCADE); return; }
        s8 h = menuList(3, 9, 4, items, &sel, 1);
        if (h == 0) { winGoals = winGoals == 3 ? 5 : winGoals == 5 ? 7 : 3; first[9] = '0' + winGoals; txt(5, 9, first, PAL_GOLD); }
        else if (h == 1 || h == 2) { c1 = (u8)h - 1; start(); }
        else if (h == 3 || h == -2) goScreen(S_ARCADE);
        if (st == ST_MENU) {
            static u16 a; a += 3000;
            spinnerAt(142, 82, a, isCGB ? OP_GREEN : 0);
            spinnerAt(142, 110, -a, isCGB ? OP_BLUE : 0x10);
        }
        return;
    }
    if (st == ST_OVER) { s8 h = overInput(); if (h == 0) start(); else if (h == 1) goScreen(S_ARCADE); return; }
    u8 p = pauseCheck(); if (p == 1) return;
    if (st == ST_PLAY || st == ST_GOAL) {                   // screen up = smaller DS x, screen right = smaller DS y
        s16 dx = 0, dy = 0;
        if (kHeld & J_UP) dx -= 64;
        if (kHeld & J_DOWN) dx += 64;
        if (kHeld & J_LEFT) dy += 64;
        if (kHeld & J_RIGHT) dy -= 64;
        if (dx || dy) place(&s1, s1.x + dx, s1.y + dy, 1);
    }
    step();
    if (st == ST_OVER) return;
    drawSprites();
}
